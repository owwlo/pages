#ifndef CSERVERIPINPUT_H
#define CSERVERIPINPUT_H

#include <QDialog>
#include "ui_cserveripinput.h"

class CServerIpInput : public QDialog
{
	Q_OBJECT

public:
	CServerIpInput(QWidget *parent = 0);
	~CServerIpInput();

private:
	Ui::CServerIpInput ui;
};

#endif // CSERVERIPINPUT_H
