#include "StdAfx.h"
#include "mclient.h"
#include <QList>
#include <QMutex>
#include <QDir>
#include <QFileInfoList>
#include <QFileInfo>
#include <QDebug>
#include "mfileitem.h"
#include "logindialog.h"
#include "masaka.h"
#include "mglobalconfig.h"
#include "ctransferclient.h"

QList<LivePeerItem*> mClient::mConnectedClientList;
QList<LivePeerItem*> mClient::mConnectedServerList;
mClient * mClient::me;

mClient::mClient(QObject *parent)
	: QThread(parent)
{
	me = this;
	
	//û�㶮�������飡û�㶮�������飡û�㶮�������飡û�㶮�������飡û�㶮�������飡û�㶮�������飡
	qRegisterMetaType<SOCKET>("SOCKET");

	connect(this,SIGNAL(Signal_ShowLoginFrame(SOCKET)),Masaka::GetInstance(),SLOT(ShowLoginFrame(SOCKET)));
	connect(this,SIGNAL(Signal_ShowSearchResultFrame()),Masaka::GetInstance(),SLOT(OnSearchResultUpdate()));
	connect(Masaka::GetInstance(),SIGNAL(Signal_LoginReturn(SOCKET,QString,QString)),this,SLOT(SendLoginMessageToServer(SOCKET,QString,QString)));
	connect(Masaka::GetInstance(),SIGNAL(Signal_AddDownload(p2pFileMetaItem *)),this,SLOT(OnAddDownload(p2pFileMetaItem *)));

	//�����ļ��У���ʱ��������Ҫ�޸ģ���Ҫ�޸ģ���Ҫ�޸ģ���Ҫ�޸ģ���Ҫ�޸ģ���Ҫ�޸ģ���Ҫ�޸ģ�
	//qDebug()<<mGlobalConfig::getKeyValue("SharePath");
	UpdateMySharedFilesListFromPath(mGlobalConfig::getKeyValue("Masaka/SharePath"));

}

mClient::~mClient()
{

}

void mClient::run()
{
	LivePeerItem * curr = new LivePeerItem;
	curr->type = "server";
	curr->ip = mGlobalConfig::getKeyValue("ServerIP");
	mConnectedServerList.push_back(curr);
	//mConnectedServerListLock.unlock();
	StandardConnectionThread *sct = new StandardConnectionThread(curr);
	sct->start();
	mActiveConnectionList.push_back(sct);
}

void mClient::UpdateMySharedFilesListFromPath( QString path)
{
	QList<mFileItem *> allFiles = LookThroughPath(path);
	mMySharedFilesList.clear();
	mMySharedFilesList += allFiles;
}

//�ݹ���Ŀ¼
QList<mFileItem*> mClient::LookThroughPath( QString path )
{
	QList<mFileItem *> rtn;
	QDir _src(path);
	if(!_src.exists())
		return rtn;
	_src.setFilter(QDir::Dirs|QDir::Files);
	_src.setSorting(QDir::DirsFirst);
	QFileInfoList list = _src.entryInfoList();
	int i=0;
	do{
		QFileInfo fileInfo = list.at(i);
		if(fileInfo.fileName()=="."|fileInfo.fileName()=="..")
		{
			i++;
			continue;
		}
		bool isDir=fileInfo.isDir();
		if(isDir)
		{
			rtn += LookThroughPath(_src.path()+"/"+fileInfo.fileName());
		}
		else
		{
			mFileItem *fi = new mFileItem(0);
			fi->mFileName = fileInfo.fileName();
			fi->mFileSize = fileInfo.size();
			fi->mFileHash = HashFile(fileInfo.absoluteFilePath());

			rtn.push_back(fi);
		}
		i++;
	}while(i<list.size());
	return rtn;
}

//�õ��ļ���Hashֵ
QString mClient::HashFile( QString strPath)
{
	QFile file(strPath);
	file.open(QIODevice::ReadOnly);
	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextStream stream(&file);
	stream.setCodec(codec);
	QByteArray bytes = stream.readAll().toAscii();
	QString strMd5 =  QCryptographicHash::hash(bytes,QCryptographicHash::Md5).toHex();
	return strMd5;
}

//���ر�ʵ��ָ��
mClient * mClient::GetInstance()
{
	return me;
}

//��mServer�̷߳��Ͳ�ѯ�ļ�����
void mClient::SendSearchOrderToServer( QString s )
{
	mConnectedServerListLock.lock();
	
	QList<StandardConnectionThread *>::iterator i = mActiveConnectionList.begin();
	for(;i != mActiveConnectionList.end(); i++)
	{
		if((*i)->lpi->type == "server")
		{
			(*i)->sendCommend("SRCH" + s);
		}
	}

	mConnectedServerListLock.unlock();
}

void mClient::ServerNeedLogin( SOCKET s)
{
	emit Signal_ShowLoginFrame(s);
}

//��socket����¼��Ϣ
void mClient::SendLoginMessageToServer( SOCKET s,QString username,QString password )
{
	QString md5;
	QByteArray bb;  
	bb = QCryptographicHash::hash ( password.toAscii(), QCryptographicHash::Md5 );  
	md5.append(bb.toHex());

	QString msg = "LGIN" + username + "#" + md5;

	qDebug()<<"Send Login Message To "<<s<<" : "<<msg;

	send(s,msg.toLocal8Bit(),msg.toLocal8Bit().length(),0);
}

int mClient::GetActiveConnectionNumber()
{
	return mActiveConnectionList.size();
}

int mClient::GetServerConnectionNumber()
{
	return mConnectedServerList.size();
}

void mClient::EmitSearchResultUpdate()
{
	emit Signal_ShowSearchResultFrame();
}

void mClient::OnAddDownload( p2pFileMetaItem * i)
{
	QString downloadPath = mGlobalConfig::getKeyValue("Masaka/DownloadPath");

	qDebug()<<"Download "<<i->fileItem->mFileName<<" from "<<i->ipList.toList().at(0);
	CTransferClient * tc = CTransferClient::GetInstance();

	QDir downloadDir(downloadPath);
	if (!downloadDir.exists())
		downloadDir.mkpath(downloadPath);

	tc->AddDownloadTask(i->fileItem->mFileName,i->ipList.toList().at(0),downloadPath +"/"+ i->fileItem->mFileName);
}


//Ϊÿ��socket�����Ĵ����̣߳�����������Ϣ
void mClient::StandardConnectionThread::run()
{
	WSAData wsaData;
	int flag = WSAStartup(MAKEWORD(2,2),&wsaData);
	if(flag != 0)
	{
		DWORD err = WSAGetLastError();
		return;
	}
	client = socket(AF_INET,SOCK_STREAM,0);
	SOCKADDR_IN clientAddr;
	clientAddr.sin_addr.S_un.S_addr = inet_addr(lpi->ip.toLocal8Bit());
	clientAddr.sin_family = AF_INET;
	clientAddr.sin_port = htons(23125);
	qDebug()<<"Connecting to "<<lpi->ip;
	int isRight = ::connect(client,(const sockaddr*)&clientAddr,sizeof(clientAddr));
	if(isRight == SOCKET_ERROR)
	{
		DWORD err0 = WSAGetLastError();
		return;
	}

	while (1)
	{
		char buf[RCVBUFFER_LENGTH];
		ZeroMemory(buf,sizeof(buf));
		int err5 = ::recv(client,buf,RCVBUFFER_LENGTH,0);
		if (err5 == SOCKET_ERROR)
		{
			qDebug()<<"recv error and close socket:"<<client;
			closesocket(client);
			break;
		}
		OrderDispatcher(QString::fromLocal8Bit(buf));

	}
	
}

mClient::StandardConnectionThread::StandardConnectionThread( LivePeerItem * i)
{
	lpi = i;
}

//��ǰ����peer������
void mClient::StandardConnectionThread::sendCommend( QString order)
{
	int len = order.toLocal8Bit().length();
	int sendData = ::send(client,order.toLocal8Bit(),len,0);

	//Sleep(100);
}

mClient::StandardConnectionThread::~StandardConnectionThread()
{
	qDebug()<<client<<" client thread exit";
	closesocket(client);
}

//��peer��mServer�̷߳��ͱ��������ļ��б�
void mClient::StandardConnectionThread::SendMyShareFilesListToServer()
{
	QString sendStr;
	mClient * parent = mClient::GetInstance();
	QList<mFileItem *>::iterator i;
	for(i=parent->mMySharedFilesList.begin(); i!=parent->mMySharedFilesList.end(); ++i)
	{
		qDebug() << (*i)->toString();
		sendStr.append((*i)->toString() + "#");
		//*i = (*i) * 10;
	}
	
	sendStr = "SHRE" + sendStr;
	
	send(client,sendStr.toLocal8Bit(),sendStr.toLocal8Bit().length(),0);
	
}

/************************************************************************/
/* SRHR����������ʽ�ο�
"TestAESCipher.rar@209737@702ee5b6aa55709f324b39d86e6319c1@192.168.71.1!#TestAES
Cipher.rar@209737@702ee5b6aa55709f324b39d86e6319c1@192.168.71.1!#TestAESCipher.r
ar@209737@702ee5b6aa55709f324b39d86e6319c1@192.168.71.1!#TestAESCipher.rar@20973
7@702ee5b6aa55709f324b39d86e6319c1@192.168.71.1!#TestAESCipher.rar@209737@702ee5
b6aa55709f324b39d86e6319c1@192.168.71.1!#TestAESCipher.rar@209737@702ee5b6aa5570
9f324b39d86e6319c1@192.168.71.1!#TestAESCipher.rar@209737@702ee5b6aa55709f324b39
d86e6319c1@192.168.71.1!#TestAESCipher.rar@209737@702ee5b6aa55709f324b39d86e6319
c1@192.168.71.1!#"
/************************************************************************/

void mClient::StandardConnectionThread::OrderDispatcher( QString s )
{
	qDebug()<<s;
	
	//�õ�����Ϣ�С��������ֶ�
	QString action = s.left(4);
	//��Ϣ�С��������ֶ�
	QString args = s.mid(4);

	//����������������ļ��б�
	if (action == "SRHR")
	{
		QList<p2pFileMetaItem*> *rtn = new QList<p2pFileMetaItem*>;
		//qDebug()<<args;
		QStringList fileList = args.split("#");
		QStringList::iterator i = fileList.begin();
		for (;i != fileList.end(); i++)
		{
			QString currentFileString = *i;
			
			if (currentFileString.length() < 2)
				continue;

			QStringList fileInfo = currentFileString.split("@");
			QStringList::iterator j = fileInfo.begin();
			p2pFileMetaItem * pFile = new p2pFileMetaItem;
			for (;j != fileInfo.end(); j++)
			{
				mFileItem * fi = new mFileItem(0);
				fi->mFileName = fileInfo.at(0);
				fi->mFileSize = fileInfo.at(1).toLong();
				fi->mFileHash = fileInfo.at(2);
				QStringList ipList = fileInfo.at(3).split("!");
				QStringList::iterator k = ipList.begin();
				for (; k != ipList.end(); k++)
				{
					QString ipString = *k;
					if (ipString.length() < 2)
						continue;
					pFile->ipList += ipString;
				}
				pFile->fileItem = fi;
			}
			rtn->push_back(pFile);
			
		}
		//SearchResultFrame * srf = SearchResultFrame::GetInstance();
		//srf->AddResultFromP2pFileList(rtn);
		//ResultWindowHelper *rwh = ResultWindowHelper::GetInstance();
		//rwh->AddResultList(rtn);
		mGlobalConfig::SetSearchResult(rtn);
		mClient::GetInstance()->EmitSearchResultUpdate();
	}
	//������Ҫ��¼������
	else if(action == "RQLI")
	{
		/*loginDialog ld(Masaka::GetInstance());
		if(ld.exec())
		{
			qDebug()<<"loginDone";
		}*/
		//connect(this,SIGNAL(Signal_AskForLogin()),Masaka::GetInstance(),SLOT(ShowLoginFrame());
		mClient::GetInstance()->ServerNeedLogin(client);
	}
	//��¼�ɹ�
	else if (action == "LRES")
	{
		SendMyShareFilesListToServer();
	}
}
