#include "StdAfx.h"
#include "usermanager.h"
#include <QtSql>
#include <QFile>

UserManager * UserManager::me;
bool UserManager::isAuthOn;

UserManager::UserManager(QObject *parent)
	: QObject(parent)
{

}

UserManager::~UserManager()
{
	
}

UserManager::AuthenticateState UserManager::Authenticate( QString username,QString password )
{
	if ( !isAuthOn )
		return CONGRATULATION;

	static QSqlDatabase dbconn = QSqlDatabase::addDatabase("QSQLITE");
	dbconn.setDatabaseName("users.db");

	if(!dbconn.open())
		return DB_NOT_CONNECTED;
	
	QSqlQuery query;
	QString queryStr = "select * from users where username = '"+username+"' and password = '"+password+"';";
	query.exec(queryStr);
	
	if(!query.first())
		return AUTHEN_FAILED;
	else
		return CONGRATULATION;
}



UserManager * UserManager::GetInstance()
{
	if (!me)
	{
		me = new UserManager(0);
		
		//���user.db�ļ���������Ĭ�ϲ���Ҫ��֤���ɵ�¼������
		QFile dbFile("users.db");
		isAuthOn = dbFile.exists();

		qDebug()<<"Is Auth On: "<<isAuthOn;
	}

	return me;
}

bool UserManager::isAuthNeeded()
{
	return isAuthOn;
}
