#ifndef MFILEITEM_H
#define MFILEITEM_H

#include <QObject>
#include <QString>

class mFileItem : public QObject
{
	Q_OBJECT

public:
	mFileItem(QObject *parent);
	~mFileItem();
	QString toString();
	long mFileSize;
	QString mFileName;
	QString mFileHash;
private:

};

#endif // MFILEITEM_H
