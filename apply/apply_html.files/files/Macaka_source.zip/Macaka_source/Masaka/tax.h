#ifndef TAX_H
#define TAX_H

#include "tax_global.h"

class TAX_EXPORT Tax
{
public:
	Tax();
	~Tax();
	int aaa();

private:

};

#endif // TAX_H
