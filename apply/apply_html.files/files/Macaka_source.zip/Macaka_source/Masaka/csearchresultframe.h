#ifndef CSEARCHRESULTFRAME_H
#define CSEARCHRESULTFRAME_H

#include <QDialog>
#include "ui_csearchresultframe.h"
#include "mclient.h"
#include <QStandardItemModel>

class CSearchResultFrame : public QDialog
{
	Q_OBJECT

public:
	CSearchResultFrame(QWidget *parent = 0);
	~CSearchResultFrame();
	void AddResultFromP2pFileList(QList<p2pFileMetaItem*> *);
	static CSearchResultFrame * GetInstance();
	p2pFileMetaItem * GetSelectFileItem();

public slots:
	void OnDoubleClickItem(QModelIndex);
	void UpdateResultList();

private:
	QList<p2pFileMetaItem*> resultList;
	Ui::CSearchResultFrame ui;
	QStandardItemModel *model;
	static CSearchResultFrame * me;
	p2pFileMetaItem * selectItem;
};

#endif // CSEARCHRESULTFRAME_H
