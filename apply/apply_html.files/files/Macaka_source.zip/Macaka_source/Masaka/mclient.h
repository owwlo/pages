#ifndef MCLIENT_H
#define MCLIENT_H

#include <QThread>
#include "Winsock2.h"
#include "mfileitem.h"

//�������������С
#define RCVBUFFER_LENGTH 1024*10

//�������meta�ṹ��
struct LivePeerItem
{
	QString ip;
	QString type;

	//�����ʱ��
	long	lastCheckTime;
};
struct p2pFileMetaItem
{
	mFileItem*		fileItem;
	QSet<QString>	ipList;
};

class mClient : public QThread
{
	Q_OBJECT

public:
	mClient(QObject *parent);
	~mClient();
	void SendSearchOrderToServer(QString s);
	virtual void run();
	void UpdateMySharedFilesListFromPath(QString);
	void ServerNeedLogin(SOCKET);
	int GetActiveConnectionNumber();
	int GetServerConnectionNumber();
	void EmitSearchResultUpdate();

	//friend class StandardConnectionThread;
	class StandardConnectionThread : public QThread
	{
	public:
		StandardConnectionThread(LivePeerItem *);
		virtual void run();
		void sendCommend(QString);
		~StandardConnectionThread();
		void SendMyShareFilesListToServer();
		LivePeerItem * lpi;

	private:
		void OrderDispatcher(QString s);
		SOCKET client;
	};

	static mClient * GetInstance();

	//��ǰ���������
	QList<StandardConnectionThread *>			mActiveConnectionList;

public slots:
	void SendLoginMessageToServer(SOCKET,QString,QString);
	void OnAddDownload(p2pFileMetaItem *);

signals:
	void Signal_ShowLoginFrame(SOCKET);
	void Signal_ShowSearchResultFrame();

private:
	static mClient * me;
	QList<mFileItem*> LookThroughPath(QString path);
	QString HashFile(QString);
	
	//ConnectedServerList�Ķ�д��
	QMutex										mConnectedServerListLock;

	//��ǰ����server������
	static QList<LivePeerItem*>					mConnectedServerList;

	//��ǰ����client������
	static QList<LivePeerItem*>					mConnectedClientList;

	//ConnectionNumberGuard�Ĵ�����
	QTimer										mConnectionNumberGuardTriger;

	//���������ļ�����
	QList<mFileItem *>							mMySharedFilesList;
};

#endif // MCLIENT_H
