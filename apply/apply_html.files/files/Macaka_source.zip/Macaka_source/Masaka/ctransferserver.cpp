#include "StdAfx.h"
#include "ctransferserver.h"
#include "mglobalconfig.h"

CTransferServer * CTransferServer::me;

CTransferServer::CTransferServer(QObject *parent)
	: QThread(parent)
{

}

CTransferServer::~CTransferServer()
{

}

CTransferServer * CTransferServer::GetInstance()
{
	if(!me)
		me = new CTransferServer(0);
	return me;
}

void CTransferServer::run()
{
	int iServerSock;
	sockaddr_in ServerAddr;
	WSADATA WSAData;
	if( WSAStartup( MAKEWORD( 2, 2 ), &WSAData ) )
	{
		WSACleanup( );
	}

	if( ( iServerSock = socket( AF_INET, SOCK_STREAM, 0 ) ) == INVALID_SOCKET )
	{
		WSACleanup( );
	}
	ServerAddr.sin_family = AF_INET;
	ServerAddr.sin_port = htons( 28269 );
	ServerAddr.sin_addr.s_addr = INADDR_ANY;
	memset( & ( ServerAddr.sin_zero ), 0, sizeof( ServerAddr.sin_zero ) );
	if( bind( iServerSock, ( struct sockaddr * )&ServerAddr, sizeof( struct sockaddr ) ) == -1 )
	{
		WSACleanup( );
	}

	if( listen( iServerSock, 10 ) == -1 )
	{
		WSACleanup( );
	}
	qDebug()<<"CTransferServer Begin to Listen";
	while( TRUE )
	{
		sockaddr_in ClientAddr;
		int sin_size = sizeof( struct sockaddr_in );

		int iClientSock = accept( iServerSock, ( struct sockaddr * )&ClientAddr, &sin_size );

		if( iClientSock == -1 )
		{
			WSACleanup( );
		}

		qDebug()<<"Client "<<iClientSock<<" Require File!";

		//�½�һ���̴߳���accept��socket
		FileServerThreadForClient *stfc = new FileServerThreadForClient(iClientSock, ClientAddr);

		stfc->start();

	}
	qDebug()<<"Exit Server!";
	WSACleanup();
}

CTransferServer::FileServerThreadForClient::FileServerThreadForClient( int clientSock,struct sockaddr_in clientAddr )
{
	mClientAddr = clientAddr;
	mClientSock = clientSock;
}

void CTransferServer::FileServerThreadForClient::run()
{
	char nameBuffer[256];
	ZeroMemory(nameBuffer,sizeof(char)*256);
	recv(mClientSock,nameBuffer,sizeof(char)*256,0);
	QString mFileName = QString::fromLocal8Bit(nameBuffer);

	QFile file(mGlobalConfig::getKeyValue("Masaka/SharePath")+"/"+mFileName);  
	file.open(QIODevice::ReadOnly);  
	QDataStream in(&file);
	char * buffer =(char*)malloc(sizeof(char)*1024);
	
	qint64 fileSize = file.bytesAvailable();
	qint64 currentPos = 0;

	//�����ļ���С
	send(mClientSock,(char*)&fileSize,sizeof(fileSize),0);

	while (currentPos < fileSize)
	{
		in.readRawData(buffer,1024);
		currentPos += 1024;
		in.device()->seek(currentPos);

		int sendData = ::send(mClientSock,buffer,sizeof(char)*1024,0);
		if(sendData == SOCKET_ERROR)
		{
			DWORD err6 = WSAGetLastError();
			closesocket(mClientSock);
			WSACleanup();
		}
	}
	qDebug()<<"done!!!!!!";
}

void CTransferServer::FileServerThreadForClient::SendMessage( QString s )
{

}

void CTransferServer::FileServerThreadForClient::OrderDispatcher( QString s)
{
	send(mClientSock,s.toLocal8Bit(),s.toLocal8Bit().length(),0);
}
