#ifndef MLIVECHECKER_H
#define MLIVECHECKER_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include "mclient.h"
#include <QMap>

class mLiveChecker : public QObject
{
	Q_OBJECT

public:
	mLiveChecker(QObject *parent);
	~mLiveChecker();

	class CheckerServer : public QThread
	{
		virtual void run();

	};
	
	class CheckerClient : public QThread
	{
		virtual void run();
	};
	
	//��ǰ���������ڴ�������б�
	//QList<LivePeerItem*> mLivePeerList;
	QMap<QString,int>	mDelayList;
	QList<LivePeerItem*> GetPeerList();
	static mLiveChecker* GetInstance();
	QTime	timer;
private:
	QMutex	mLivePeerListMutex;
	CheckerServer* cs;
	CheckerClient* cl;
	static mLiveChecker * me; 
	void UpdateLivePeerList(LivePeerItem *);
};

#endif // MLIVECHECKER_H
