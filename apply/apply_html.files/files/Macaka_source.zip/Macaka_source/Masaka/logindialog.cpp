#include "StdAfx.h"
#include "logindialog.h"

loginDialog::loginDialog(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

loginDialog::~loginDialog()
{

}
