#ifndef TAX_GLOBAL_H
#define TAX_GLOBAL_H

#include <QtCore/qglobal.h>

#ifdef TAX_LIB
# define TAX_EXPORT Q_DECL_EXPORT
#else
# define TAX_EXPORT Q_DECL_IMPORT
#endif

#endif // TAX_GLOBAL_H
