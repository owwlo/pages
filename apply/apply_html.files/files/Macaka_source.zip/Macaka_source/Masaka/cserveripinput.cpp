#include "StdAfx.h"
#include "cserveripinput.h"

CServerIpInput::CServerIpInput(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

CServerIpInput::~CServerIpInput()
{

}
