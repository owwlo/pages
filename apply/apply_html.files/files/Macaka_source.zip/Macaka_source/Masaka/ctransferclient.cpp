#include "StdAfx.h"
#include "ctransferclient.h"
#include <QDir>
#include "masaka.h"
#include "mlivechecker.h"

CTransferClient * CTransferClient::me;

CTransferClient::CTransferClient(QObject *parent)
	: QThread(parent)
{
	mDownloadIndex = 0;
}

CTransferClient::~CTransferClient()
{

}

CTransferClient * CTransferClient::GetInstance()
{
	if(!me)
		me = new CTransferClient(0);
	return me;
}

void CTransferClient::run()
{
	//(new FileClientThread("a.zip","192.168.71.1","c:\\a.zip"))->start();
}

void CTransferClient::AddDownloadTask( QString fileName,QString peerIP,QString pathDest )
{
	(new FileClientThread(fileName,peerIP,pathDest,mDownloadIndex))->start();
	mDownloadIndex++;
}

void CTransferClient::FileClientThread::OrderDispatcher( QString )
{

}

void CTransferClient::FileClientThread::SendMessage( QString s )
{

}

void CTransferClient::FileClientThread::run()
{
	WSAData wsaData;
	int flag = WSAStartup(MAKEWORD(2,2),&wsaData);
	if(flag != 0)
	{
		DWORD err = WSAGetLastError();
		return;
	}
	mClientSock = socket(AF_INET,SOCK_STREAM,0);
	mClientAddr.sin_addr.S_un.S_addr = inet_addr(mPeerIP.toLocal8Bit());
	mClientAddr.sin_family = AF_INET;
	mClientAddr.sin_port = htons(28269);
	int isRight = ::connect(mClientSock,(const sockaddr*)&mClientAddr,sizeof(mClientAddr));
	if(isRight == SOCKET_ERROR)
	{
		DWORD err0 = WSAGetLastError();
		return;
	}

	char nameBuffer[256];
	ZeroMemory(nameBuffer,sizeof(char)*256);
	memcpy(nameBuffer,mFileName.toLocal8Bit(),mFileName.toLocal8Bit().length());
	send(mClientSock,nameBuffer,sizeof(char)*256,0);

	//QDir downloadDir("\\MasakaDownload\\");
	//if(!downloadDir.exists())
	//	downloadDir.mkdir("MasakaDownload");

	QFile file(mPathDest);
	file.open(QIODevice::WriteOnly);
	QDataStream out(&file);

	qint64 fileSize;
	qint64 currentSize = 0;
	recv(mClientSock,(char*)&fileSize,sizeof(fileSize),0);

	qDebug()<<"Downloading from "<<mPeerIP;

	Masaka * ma = Masaka::GetInstance();

	while (currentSize < fileSize)
	{
		ma->SetDownloadInfo(mIndex,mFileName,fileSize,currentSize,mLiveChecker::GetInstance()->mDelayList.value(mPeerIP));
		char buf[1024];
		ZeroMemory(buf,sizeof(buf));
		int err5 = ::recv(mClientSock,buf,sizeof(char)*1024,0);
		if (err5 == SOCKET_ERROR)
		{
			qDebug()<<"recv error and close socket:"<<mClientSock;
			closesocket(mClientSock);
			break;
		}
		out.writeRawData(buf,(fileSize-currentSize>=1024?1024:fileSize-currentSize));
		currentSize += 1024;
		out.device()->seek(currentSize);
	}
	file.close();
}

CTransferClient::FileClientThread::FileClientThread( QString fileName,QString peerIP,QString pathDest,int index )
{
	mFileName = fileName;
	mPathDest = pathDest;
	mPeerIP = peerIP;
	mIndex = index;
}
