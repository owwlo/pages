#include "stdafx.h"
#include "masaka.h"
#include "mclient.h"
#include "logindialog.h"
#include <QDialog>
#include "mglobalconfig.h"
#include <Windows.h>
#include <Psapi.h>
#include <tlhelp32.h>
#include <QDebug>
#include "csearchresultframe.h"

Masaka * Masaka::me;
BOOL WINAPI GetProcessMemoryInfo(
								 HANDLE Process,
								 PPROCESS_MEMORY_COUNTERS ppsmemCounters,
								 DWORD cb
								 );

Masaka::Masaka(QWidget *parent, Qt::WFlags flags)
	: QMainWindow(parent, flags)
{
	me = this;

	ui.setupUi(this);
	
	//�������
	setWindowFlags(windowFlags()& ~Qt::WindowMaximizeButtonHint);  
	//���ô�С����
	setFixedSize(this->width(), this->height());
	//��ȫ͸��Ŷ�ף�
	setAttribute(Qt::WA_TranslucentBackground, true);
	setWindowFlags(Qt::FramelessWindowHint);
	
	ui.tableWidget->setColumnCount(5);
	ui.tableWidget->setRowCount(3);  
	QStringList headers;
	headers << "State" << "File" << "Size" << "Percent" << "Delay";
	ui.tableWidget->setHorizontalHeaderLabels(headers); 
	ui.tableWidget->setColumnWidth(0,50);
	ui.tableWidget->setColumnWidth(1,450);
	ui.tableWidget->setColumnWidth(2,70);
	ui.tableWidget->setColumnWidth(3,70);
	ui.tableWidget->setColumnWidth(4,70);

	//QStandardItemModel *model = new QStandardItemModel;
	//model->setColumnCount(4);
	//model->setHeaderData(0,Qt::Horizontal,tr("File"));
	//model->setHeaderData(1,Qt::Horizontal,tr("Size"));
	//model->setHeaderData(2,Qt::Horizontal,tr("Percent"));
	//model->setHeaderData(3,Qt::Horizontal,tr("Speed"));
	//ui.tableWidget->setItem(0,1, new QTableWidgetItem("��Ԥ��Ƭ3������������.the.avengers.hr-hdtv.˫����Ч��Ļ-����Ӱ��Ԥ��Ƭ��.mkv"));
	//ui.tableWidget->setItem(0,2, new QTableWidgetItem("128.23MB"));
	//ui.tableWidget->setItem(0,3, new QTableWidgetItem("0.0%"));
	//ui.tableWidget->setItem(0,4, new QTableWidgetItem("3:48MB/s"));
	//ui.tableWidget->setItem(1,1, new QTableWidgetItem("��Ԥ��Ƭ3������������.the.avengers.hr-hdtv.˫����Ч��Ļ-����Ӱ��Ԥ��Ƭ��.mkv"));
	//ui.tableWidget->setItem(1,2, new QTableWidgetItem("128.23MB"));
	//ui.tableWidget->setItem(1,3, new QTableWidgetItem("0.0%"));
	//ui.tableWidget->setItem(1,4, new QTableWidgetItem("3:48MB/s"));
	//item2->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
	//item3->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
	//item4->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
	//QList<QStandardItem*> item;
	//item << item1 << item2 << item3 << item4;
	//model->appendRow(item);
	//QStandardItem* item11 = new QStandardItem(tr("Windows8-ConsumerPreview-32bit-English.iso"));
	//QStandardItem* item12 = new QStandardItem(tr("4.23GB"));
	//QStandardItem* item13 = new QStandardItem(tr("0.0%"));
	//QStandardItem* item14 = new QStandardItem(tr("1:42MB/s"));
	//QList<QStandardItem*> item111;
	//item12->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
	//item13->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
	//item14->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);

	//item111 << item11 << item12 << item13 << item14;
	//model->appendRow(item111);
	//ui.tableView->setModel(model);

	//ui.tableView->setColumnWidth(0, 480);
	//ui.tableView->setColumnWidth(1, 70);
	//ui.tableView->setColumnWidth(2, 50);
	////ui.tableView->setColumnWidth(3, 50);

	QStandardItemModel *standardItemModel= new QStandardItemModel(this);  
	QStandardItem *item222 = new QStandardItem("Downloading");
	QStandardItem *item333 = new QStandardItem("Finished");  
	standardItemModel->appendRow(item222);
	//standardItemModel->appendRow(item333);
	ui.listView->setModel(standardItemModel);
	ui.stackedWidget->setCurrentIndex(0);

	connect(&dataUpdateTimer,SIGNAL(timeout()),this,SLOT(DataUpdate()));
	connect(ui.listView,SIGNAL(clicked(QModelIndex)),this,SLOT(OnCategoryClicked(QModelIndex)));

	dataUpdateTimer.start(1000);
	
	//ui.runningInfoPage->layout()->addWidget()
}

Masaka::~Masaka()
{

}

void Masaka::mousePressEvent( QMouseEvent *event )
{
	if (event->button() == Qt::LeftButton)
	{
		dragPosition = event->globalPos() - frameGeometry().topLeft();
		event->accept();
	}
}

void Masaka::mouseMoveEvent( QMouseEvent *event )
{
	//�����������������ʱ��
	if (event->buttons() == Qt::LeftButton) 
	{
		//�ƶ�����
		move(event->globalPos() - dragPosition);
		event->accept();
	}
}

void Masaka::AddNewDownloadTask()
{
	
}

void Masaka::ShowPeerInfo()
{
	ui.stackedWidget->setCurrentIndex(2);
}

void Masaka::ShowRunningInfo()
{
	ui.stackedWidget->setCurrentIndex(1);
}

void Masaka::SearchIt()
{
	QString searchStr = ui.lineEdit->text();

	mClient * mc = mClient::GetInstance();
	//��peer���Ͳ�������
	mc->SendSearchOrderToServer(searchStr);

	//ResultWindowHelper *rwh = ResultWindowHelper::GetInstance();
	//rwh->AddResultList(resultsFromMe);
}

QRect Masaka::GetSearchFieldGeometry()
{
	return ui.lineEdit->geometry();
}

Masaka * Masaka::GetInstance()
{
	if(!me)
		me = new Masaka;

	return me;
}

//��д����д����д����д����д����д����д����д����д����д����д����д����д����д��
void Masaka::ShowLoginFrame( SOCKET s)
{
	loginDialog ld(this);
	if(ld.exec() == QDialog::Accepted)
	{
		QLineEdit *usernameEdit = qobject_cast<QLineEdit *>(ld.findChild<QLineEdit*>("lineEdit"));
		QLineEdit *passwordEdit = qobject_cast<QLineEdit *>(ld.findChild<QLineEdit*>("lineEdit_2"));

		emit Signal_LoginReturn(s,usernameEdit->text(),passwordEdit->text());
	}
}

void Masaka::DataUpdate()
{
	int currentPage = ui.stackedWidget->currentIndex();
	//qDebug()<<"currentPage: "<<currentPage;
	switch (currentPage)
	{
		case 0:
			UpdateData_taskListPage();
			break;
		case 1:
			UpdateData_runningInfoPage();
			break;
		case 2:
			UpdateData_peersInfoPage();
			break;
	}
}

void Masaka::UpdateData_taskListPage()
{

}

void Masaka::UpdateData_runningInfoPage()
{
	mClient *		mc = mClient::GetInstance();

	ui.label_6->setText(QString::number(mGlobalConfig::GetRunningTime()/1000) + "s");
	
	QString currentIPs;
	QList<QString> ipL = mGlobalConfig::GetMyIPs();
	QList<QString>::iterator i = ipL.begin();
	for(; i != ipL.end(); i++)
	{
		currentIPs += *i + " ; ";
	}
	ui.label_7->setText(currentIPs);

	ui.label_14->setText(QString::number(mc->GetActiveConnectionNumber()));

	ui.label_15->setText(QString::number(mc->GetServerConnectionNumber()));

	ui.label_16->setText("0 KB/s");

	ui.label_17->setText((mGlobalConfig::getKeyValue("isServer") == "1"?"Server":"Client"));

	PROCESS_MEMORY_COUNTERS  pmc;
	HANDLE handle = GetCurrentProcess(); 
	GetProcessMemoryInfo(handle,&pmc,sizeof(pmc));
	unsigned long usedMemory = pmc.WorkingSetSize;
	ui.label_18->setText(QString::number((double)(usedMemory/1024)/1024.0) + "MB");

	HANDLE hProcessSnap;
	PROCESSENTRY32 pe32;
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	pe32.dwSize = sizeof(PROCESSENTRY32);
	Process32Next(hProcessSnap, &pe32);
	ui.label_20->setText(QString::number((int)pe32.cntThreads));
	CloseHandle(hProcessSnap);
}

void Masaka::UpdateData_peersInfoPage()
{
	
}

void Masaka::OnSearchResultUpdate()
{
	CSearchResultFrame srf(this);
	QRect searchFieldGeometry = Masaka::GetInstance()->GetSearchFieldGeometry();
	searchFieldGeometry.setLeft(searchFieldGeometry.left()-85);
	srf.setGeometry(searchFieldGeometry);
	srf.AddResultFromP2pFileList(mGlobalConfig::GetSearchResult());

	if(srf.exec() == QDialog::Accepted)
	{
		emit Signal_AddDownload(srf.GetSelectFileItem());
	}
}

void Masaka::OnCategoryClicked( QModelIndex )
{
	ui.stackedWidget->setCurrentIndex (0);
}

void Masaka::SetDownloadInfo( int index,QString fileName,long fileSize,long downloadSize,int delay )
{
	if (!downloadInfoLock.tryLock())
		return;

	ui.tableWidget->setRowCount(ui.tableWidget->rowCount()>=(index+1)?ui.tableWidget->rowCount():(index+1));

	ui.tableWidget->setItem(index,1, new QTableWidgetItem(fileName));
	ui.tableWidget->setItem(index,2, new QTableWidgetItem(QString::number(fileSize) + "Bytes"));
	
	double percent = (double)downloadSize/(double)fileSize;

	if (percent>0.95f)
		percent = 1;

	ui.tableWidget->setItem(index,3, new QTableWidgetItem(QString::number(percent).left(4)));
	ui.tableWidget->setItem(index,4, new QTableWidgetItem(QString::number(delay)));

	downloadInfoLock.unlock();
}
