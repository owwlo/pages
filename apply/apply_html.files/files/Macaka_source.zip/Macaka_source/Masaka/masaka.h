#ifndef MASAKA_H
#define MASAKA_H

#include <QtGui/QMainWindow>
#include "ui_masaka.h"
#include "Winsock2.h"
#include "mclient.h"
#include <QModelIndex>

class Masaka : public QMainWindow
{
	Q_OBJECT

public:
	~Masaka();
	static Masaka * GetInstance();
	
	//�õ�SearchField��λ����Ϣ
	QRect GetSearchFieldGeometry();
	void SetDownloadInfo(int index,QString fileName,long fileSize,long downloadSize,int delay);

public slots:
	void AddNewDownloadTask();
	void ShowPeerInfo();
	void ShowRunningInfo();
	void SearchIt();
	void ShowLoginFrame(SOCKET);
	void DataUpdate();
	void OnSearchResultUpdate();
	void OnCategoryClicked(QModelIndex);

signals:
	void Signal_LoginReturn(SOCKET,QString,QString);
	void Signal_AddDownload(p2pFileMetaItem *);

protected:
	void mousePressEvent(QMouseEvent *);
	void mouseMoveEvent(QMouseEvent *);

private:
	Masaka(QWidget *parent = 0, Qt::WFlags flags = 0);
	void UpdateData_taskListPage();
	void UpdateData_runningInfoPage();
	void UpdateData_peersInfoPage();
	Ui::MasakaClass	ui;
	QPoint			dragPosition;
	static Masaka * me;
	QTimer			dataUpdateTimer;
	QMutex			downloadInfoLock;
};

#endif // MASAKA_H
