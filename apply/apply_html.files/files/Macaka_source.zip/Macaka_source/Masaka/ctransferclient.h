#ifndef CTRANSFERCLIENT_H
#define CTRANSFERCLIENT_H

#include <QThread>
#include <WinSock2.h>

class CTransferClient : public QThread
{
	Q_OBJECT

public:
	~CTransferClient();
	static CTransferClient * GetInstance();
	void AddDownloadTask(QString fileName,QString peerIP,QString pathDest);

	class FileClientThread:public QThread
	{
	public:
		FileClientThread(QString fileName,QString peerIP,QString pathDest,int index);
		virtual void run();
		void SendMessage(QString s);

	private:
		void OrderDispatcher(QString);

	private:
		int					mClientSock;
		int					mIndex;
		sockaddr_in		 	mClientAddr;
		QString				mFileName;
		QString				mPeerIP;
		QString				mPathDest;
	};

private:
	CTransferClient(QObject *parent);

	virtual void run();

	static CTransferClient * me;
	
	int mDownloadIndex;

};

#endif // CTRANSFERCLIENT_H
