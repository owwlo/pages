/********************************************************************************
** Form generated from reading UI file 'csearchresultframe.ui'
**
** Created: Sat May 5 18:16:44 2012
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CSEARCHRESULTFRAME_H
#define UI_CSEARCHRESULTFRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QTableView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CSearchResultFrame
{
public:
    QWidget *widget;
    QTableView *tableView;

    void setupUi(QDialog *CSearchResultFrame)
    {
        if (CSearchResultFrame->objectName().isEmpty())
            CSearchResultFrame->setObjectName(QString::fromUtf8("CSearchResultFrame"));
        CSearchResultFrame->resize(400, 300);
        widget = new QWidget(CSearchResultFrame);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(60, 30, 271, 231));
        widget->setAutoFillBackground(false);
        widget->setStyleSheet(QString::fromUtf8("#widget\n"
"{\n"
"	background-image: url(:/Masaka/Resources/searchResultFrameBackground.png);\n"
"	background-repeat:no-repeat;\n"
"	background-color:transparent;\n"
"}"));
        tableView = new QTableView(widget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(20, 30, 215, 165));
        QFont font;
        font.setPointSize(7);
        tableView->setFont(font);
        tableView->setStyleSheet(QString::fromUtf8("#tableView\n"
"{\n"
"	background-color:transparent;\n"
"}\n"
"QHeaderView::section\n"
"{\n"
"	background:#d5d5d5;\n"
"	border: 0px;\n"
"	border-right: 1px solid grey;\n"
"	height:20px\n"
"}\n"
"#tableView::item\n"
"{\n"
"	text-align: left;\n"
"	height:20px;\n"
"}\n"
"#tableView::item:selected {\n"
"	background-image: url(:/Masaka/Resources/tableSelectRowBackground.png);\n"
"	background-repeat: repeat-x;\n"
"	background-position: top;\n"
"	border:0px dashed #bbb;\n"
"	background-color: #458bff;\n"
"}"));
        tableView->setFrameShape(QFrame::NoFrame);
        tableView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setProperty("showDropIndicator", QVariant(false));
        tableView->setDragDropOverwriteMode(false);
        tableView->setAlternatingRowColors(true);
        tableView->setSelectionMode(QAbstractItemView::SingleSelection);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableView->setShowGrid(false);
        tableView->setGridStyle(Qt::DashLine);
        tableView->setWordWrap(false);
        tableView->setCornerButtonEnabled(false);
        tableView->horizontalHeader()->setCascadingSectionResizes(true);
        tableView->horizontalHeader()->setDefaultSectionSize(215);
        tableView->horizontalHeader()->setHighlightSections(false);
        tableView->horizontalHeader()->setMinimumSectionSize(20);
        tableView->horizontalHeader()->setStretchLastSection(true);
        tableView->verticalHeader()->setVisible(false);
        tableView->verticalHeader()->setDefaultSectionSize(20);
        tableView->verticalHeader()->setHighlightSections(false);

        retranslateUi(CSearchResultFrame);
        QObject::connect(tableView, SIGNAL(doubleClicked(QModelIndex)), CSearchResultFrame, SLOT(OnDoubleClickItem(QModelIndex)));

        QMetaObject::connectSlotsByName(CSearchResultFrame);
    } // setupUi

    void retranslateUi(QDialog *CSearchResultFrame)
    {
        CSearchResultFrame->setWindowTitle(QApplication::translate("CSearchResultFrame", "CSearchResultFrame", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CSearchResultFrame: public Ui_CSearchResultFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CSEARCHRESULTFRAME_H
