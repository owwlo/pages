/********************************************************************************
** Form generated from reading UI file 'masaka.ui'
**
** Created: Sat May 5 18:16:42 2012
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MASAKA_H
#define UI_MASAKA_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListView>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QStackedWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MasakaClass
{
public:
    QWidget *centralWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QLineEdit *lineEdit;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *widget_2;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_3;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_8;
    QWidget *widget_9;
    QLabel *label_2;
    QWidget *widget_10;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_5;
    QListView *listView;
    QWidget *widget_4;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_5;
    QLabel *label;
    QWidget *widget_7;
    QWidget *widget_6;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_4;
    QStackedWidget *stackedWidget;
    QWidget *taskListPage;
    QTableWidget *tableWidget;
    QWidget *runningInfoPage;
    QGroupBox *groupBox;
    QLabel *label_9;
    QLabel *label_17;
    QLabel *label_6;
    QLabel *label_10;
    QLabel *label_16;
    QLabel *label_14;
    QLabel *label_22;
    QLabel *label_15;
    QLabel *label_36;
    QLabel *label_13;
    QLabel *label_20;
    QLabel *label_18;
    QLabel *label_12;
    QLabel *label_7;
    QLabel *label_11;
    QLabel *label_23;
    QLabel *label_37;
    QLabel *label_21;
    QWidget *peersInfoPage;
    QTableWidget *tableWidget_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_8;

    void setupUi(QMainWindow *MasakaClass)
    {
        if (MasakaClass->objectName().isEmpty())
            MasakaClass->setObjectName(QString::fromUtf8("MasakaClass"));
        MasakaClass->setWindowModality(Qt::ApplicationModal);
        MasakaClass->resize(917, 615);
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        MasakaClass->setFont(font);
        MasakaClass->setAutoFillBackground(false);
        MasakaClass->setStyleSheet(QString::fromUtf8("#centralWidget {background-image: url(:/Masaka/Resources/background.png);}"));
        centralWidget = new QWidget(MasakaClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setAutoFillBackground(false);
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 911, 621));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(10, 10, 8, 20);
        widget = new QWidget(verticalLayoutWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        widget->setMinimumSize(QSize(0, 58));
        widget->setAutoFillBackground(false);
        widget->setStyleSheet(QString::fromUtf8("#widget{\n"
"	background: QLinearGradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 1 rgb(230,230,230), stop:0.5 rgb(235,235,235), stop: 0 rgb(245,245,245));\n"
"	border-bottom-width: 1px;\n"
"     border-bottom-style: solid;\n"
"     border-bottom-color: #aaa;\n"
"}"));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(620, 20, 185, 24));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(8);
        lineEdit->setFont(font1);
        lineEdit->setStyleSheet(QString::fromUtf8("#lineEdit {\n"
"	background-image: url(:/Masaka/Resources/searchBoxBackground.png);\n"
"	border:0px;\n"
"	background-repeat:no-repeat;\n"
"	background-color:transparent;\n"
"	padding:2px 26px 0px;\n"
"}\n"
"#lineEdit:focus {\n"
"    	background-image: url(:/Masaka/Resources/searchBoxBackgroundFocus.png);\n"
"}\n"
"\n"
"#lineEdit:edit-focus {\n"
"    \n"
"}\n"
""));
        lineEdit->setCursorMoveStyle(Qt::LogicalMoveStyle);
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(25, 15, 131, 31));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/Masaka/Resources/logo.png")));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(190, 10, 41, 41));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Masaka/Resources/round_plus.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon);
        pushButton_2->setIconSize(QSize(24, 24));
        pushButton_2->setFlat(true);
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(240, 10, 41, 41));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Masaka/Resources/users.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon1);
        pushButton_3->setIconSize(QSize(24, 24));
        pushButton_3->setFlat(true);
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(290, 10, 41, 41));
        pushButton_4->setLayoutDirection(Qt::LeftToRight);
        pushButton_4->setAutoFillBackground(false);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Masaka/Resources/info.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_4->setIcon(icon2);
        pushButton_4->setIconSize(QSize(24, 24));
        pushButton_4->setFlat(true);

        verticalLayout->addWidget(widget);

        widget_2 = new QWidget(verticalLayoutWidget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setStyleSheet(QString::fromUtf8("#widget_2{\n"
"background:rgb(245,245,245);\n"
"}"));
        horizontalLayoutWidget = new QWidget(widget_2);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 0, 901, 541));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 7, 8);
        widget_3 = new QWidget(horizontalLayoutWidget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget_3->sizePolicy().hasHeightForWidth());
        widget_3->setSizePolicy(sizePolicy1);
        widget_3->setMinimumSize(QSize(180, 0));
        widget_3->setStyleSheet(QString::fromUtf8("#widget_3\n"
"{\n"
"	background-image: url(:/Masaka/Resources/shadowRight.png);\n"
"	background-repeat: repeat-y;\n"
"	background-position: right;\n"
"	background-color:#2e2e2e;\n"
"	border-right:0px solid #111;\n"
"}"));
        verticalLayoutWidget_3 = new QWidget(widget_3);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(0, 0, 181, 531));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        widget_8 = new QWidget(verticalLayoutWidget_3);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        sizePolicy.setHeightForWidth(widget_8->sizePolicy().hasHeightForWidth());
        widget_8->setSizePolicy(sizePolicy);
        widget_8->setMinimumSize(QSize(0, 39));
        widget_8->setStyleSheet(QString::fromUtf8("#widget_8\n"
"{\n"
"	border-top-width: 1px;\n"
"    border-top-style: solid;\n"
"    border-top-color: #222;\n"
"	background-image: url(:/Masaka/Resources/shadow.png);\n"
"	background-repeat: repeat-x;\n"
"	background-position: top;\n"
"}"));

        verticalLayout_3->addWidget(widget_8);

        widget_9 = new QWidget(verticalLayoutWidget_3);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        sizePolicy.setHeightForWidth(widget_9->sizePolicy().hasHeightForWidth());
        widget_9->setSizePolicy(sizePolicy);
        widget_9->setMinimumSize(QSize(0, 28));
        widget_9->setStyleSheet(QString::fromUtf8("#widget_9\n"
"{\n"
"	background:#4a4a4a;\n"
"	border-bottom-width: 1px;\n"
"	border-top-width: 1px;\n"
"    border-bottom-style: solid;\n"
"    border-top-style: solid;\n"
"    border-bottom-color: #222;\n"
"    border-top-color: #656565;\n"
"}"));
        label_2 = new QLabel(widget_9);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 3, 61, 20));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(12);
        font2.setBold(false);
        font2.setWeight(50);
        label_2->setFont(font2);
        label_2->setStyleSheet(QString::fromUtf8("#label_2\n"
"{\n"
"color:#aaa;\n"
"}"));

        verticalLayout_3->addWidget(widget_9);

        widget_10 = new QWidget(verticalLayoutWidget_3);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        verticalLayoutWidget_5 = new QWidget(widget_10);
        verticalLayoutWidget_5->setObjectName(QString::fromUtf8("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(-1, -1, 181, 461));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        listView = new QListView(verticalLayoutWidget_5);
        listView->setObjectName(QString::fromUtf8("listView"));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(9);
        listView->setFont(font3);
        listView->setAutoFillBackground(true);
        listView->setStyleSheet(QString::fromUtf8("#listView\n"
"{\n"
"	background:transparent;\n"
"	border-right:1px solid #111;\n"
"}\n"
"QListView::item {\n"
"	padding-left: 30px;\n"
"	border: 0px solid #aaa;\n"
"	height:30px;\n"
"	color:#aaa;\n"
"	border-right:1px solid #111;\n"
"}\n"
"QListView::item:selected {\n"
"	background-image: url(:/Masaka/Resources/shadowRight.png);\n"
"	background-repeat: repeat-y;\n"
"	background-position: right;\n"
"	border:0px dashed #bbb;\n"
"	background-color: #458bff;\n"
"	color:#eee;\n"
"}\n"
"QListView::item:hover {\n"
"	background-image: url(:/Masaka/Resources/shadowRight.png);\n"
"	background-repeat: repeat-y;\n"
"	background-position: right;\n"
"    background-color: #66a0ff;\n"
"	color:#eee;\n"
"	border: 0px solid #aaa;\n"
"}"));
        listView->setFrameShape(QFrame::NoFrame);
        listView->setFrameShadow(QFrame::Plain);
        listView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        listView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        listView->setAlternatingRowColors(false);

        verticalLayout_5->addWidget(listView);


        verticalLayout_3->addWidget(widget_10);


        horizontalLayout->addWidget(widget_3);

        widget_4 = new QWidget(horizontalLayoutWidget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        verticalLayoutWidget_2 = new QWidget(widget_4);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 0, 721, 541));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 1, 9, 9);
        widget_5 = new QWidget(verticalLayoutWidget_2);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        sizePolicy.setHeightForWidth(widget_5->sizePolicy().hasHeightForWidth());
        widget_5->setSizePolicy(sizePolicy);
        widget_5->setMinimumSize(QSize(0, 38));
        widget_5->setStyleSheet(QString::fromUtf8("#widget_5\n"
"{\n"
"background:#dddddd;\n"
"    border-top-color: #000;\n"
"    border-top-width: 1px;\n"
"\n"
"\n"
"\n"
"}"));
        label = new QLabel(widget_5);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 0, 131, 41));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font4.setPointSize(14);
        font4.setBold(true);
        font4.setWeight(75);
        label->setFont(font4);
        label->setStyleSheet(QString::fromUtf8("#label\n"
"{\n"
"	color:#222;\n"
"}"));

        verticalLayout_2->addWidget(widget_5);

        widget_7 = new QWidget(verticalLayoutWidget_2);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        widget_6 = new QWidget(widget_7);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        widget_6->setGeometry(QRect(0, 0, 711, 28));
        sizePolicy.setHeightForWidth(widget_6->sizePolicy().hasHeightForWidth());
        widget_6->setSizePolicy(sizePolicy);
        widget_6->setMinimumSize(QSize(0, 28));
        widget_6->setStyleSheet(QString::fromUtf8("#widget_6\n"
"{\n"
"	background:#d5d5d5;\n"
"	border-bottom-width: 1px;\n"
"	border-top-width: 1px;\n"
"    border-bottom-style: solid;\n"
"    border-top-style: solid;\n"
"    border-bottom-color: #aaa;\n"
"    border-top-color: #eee;\n"
"\n"
"}"));
        verticalLayoutWidget_4 = new QWidget(widget_7);
        verticalLayoutWidget_4->setObjectName(QString::fromUtf8("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(-10, 0, 721, 501));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(10, 1, 0, 7);
        stackedWidget = new QStackedWidget(verticalLayoutWidget_4);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setAutoFillBackground(false);
        stackedWidget->setStyleSheet(QString::fromUtf8("#stackedWidget\n"
"{\n"
"	background:transparent;\n"
"}\n"
""));
        stackedWidget->setFrameShape(QFrame::NoFrame);
        stackedWidget->setFrameShadow(QFrame::Sunken);
        stackedWidget->setLineWidth(0);
        taskListPage = new QWidget();
        taskListPage->setObjectName(QString::fromUtf8("taskListPage"));
        tableWidget = new QTableWidget(taskListPage);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(0, 0, 711, 491));
        tableWidget->setAutoFillBackground(true);
        tableWidget->setStyleSheet(QString::fromUtf8("#tableWidget\n"
"{\n"
"	background:transparent;\n"
"}\n"
"QHeaderView::section\n"
"{\n"
"	background:#d5d5d5;\n"
"	border: 0px;\n"
"	border-right: 1px solid grey;\n"
"	height:26px\n"
"}\n"
"QTableWidget::item\n"
"{\n"
"	text-align: left;\n"
"}\n"
"QTableWidget::item:selected {\n"
"	background-image: url(:/Masaka/Resources/tableSelectRowBackground.png);\n"
"	background-repeat: repeat-x;\n"
"	background-position: top;\n"
"	border:0px dashed #bbb;\n"
"	background-color: #458bff;\n"
"}"));
        tableWidget->setFrameShape(QFrame::NoFrame);
        tableWidget->setFrameShadow(QFrame::Plain);
        tableWidget->setLineWidth(0);
        tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        tableWidget->setAutoScroll(false);
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setProperty("showDropIndicator", QVariant(false));
        tableWidget->setDragDropOverwriteMode(false);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableWidget->setShowGrid(false);
        tableWidget->setGridStyle(Qt::SolidLine);
        tableWidget->setSortingEnabled(false);
        tableWidget->setWordWrap(false);
        tableWidget->setCornerButtonEnabled(false);
        tableWidget->horizontalHeader()->setCascadingSectionResizes(true);
        tableWidget->horizontalHeader()->setHighlightSections(false);
        tableWidget->verticalHeader()->setVisible(false);
        tableWidget->verticalHeader()->setHighlightSections(false);
        stackedWidget->addWidget(taskListPage);
        runningInfoPage = new QWidget();
        runningInfoPage->setObjectName(QString::fromUtf8("runningInfoPage"));
        groupBox = new QGroupBox(runningInfoPage);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(20, 40, 671, 211));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: transparent;"));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(70, 20, 131, 20));
        label_9->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_17 = new QLabel(groupBox);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(210, 120, 441, 21));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(210, 20, 441, 21));
        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(70, 40, 131, 20));
        label_10->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_16 = new QLabel(groupBox);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(210, 100, 441, 21));
        label_14 = new QLabel(groupBox);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(210, 60, 441, 21));
        label_22 = new QLabel(groupBox);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(70, 120, 131, 20));
        label_22->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_15 = new QLabel(groupBox);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(210, 80, 441, 21));
        label_36 = new QLabel(groupBox);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(70, 160, 131, 20));
        label_36->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(70, 100, 131, 20));
        label_13->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_20 = new QLabel(groupBox);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(210, 160, 441, 21));
        label_18 = new QLabel(groupBox);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(210, 140, 441, 21));
        label_12 = new QLabel(groupBox);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(70, 80, 131, 20));
        label_12->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(210, 40, 441, 21));
        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(70, 60, 131, 20));
        label_11->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_23 = new QLabel(groupBox);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(70, 140, 131, 20));
        label_23->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_37 = new QLabel(groupBox);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(70, 180, 131, 20));
        label_37->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_21 = new QLabel(groupBox);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(210, 180, 441, 21));
        stackedWidget->addWidget(runningInfoPage);
        peersInfoPage = new QWidget();
        peersInfoPage->setObjectName(QString::fromUtf8("peersInfoPage"));
        tableWidget_2 = new QTableWidget(peersInfoPage);
        tableWidget_2->setObjectName(QString::fromUtf8("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(0, 140, 711, 351));
        label_4 = new QLabel(peersInfoPage);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 30, 101, 21));
        label_5 = new QLabel(peersInfoPage);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(70, 60, 101, 21));
        label_8 = new QLabel(peersInfoPage);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(70, 80, 101, 21));
        stackedWidget->addWidget(peersInfoPage);

        verticalLayout_4->addWidget(stackedWidget);


        verticalLayout_2->addWidget(widget_7);


        horizontalLayout->addWidget(widget_4);


        verticalLayout->addWidget(widget_2);

        MasakaClass->setCentralWidget(centralWidget);

        retranslateUi(MasakaClass);
        QObject::connect(pushButton_2, SIGNAL(clicked()), MasakaClass, SLOT(AddNewDownloadTask()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), MasakaClass, SLOT(ShowPeerInfo()));
        QObject::connect(pushButton_4, SIGNAL(clicked()), MasakaClass, SLOT(ShowRunningInfo()));
        QObject::connect(lineEdit, SIGNAL(returnPressed()), MasakaClass, SLOT(SearchIt()));

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MasakaClass);
    } // setupUi

    void retranslateUi(QMainWindow *MasakaClass)
    {
        MasakaClass->setWindowTitle(QApplication::translate("MasakaClass", "Masaka", 0, QApplication::UnicodeUTF8));
        lineEdit->setPlaceholderText(QApplication::translate("MasakaClass", "Search for files...", 0, QApplication::UnicodeUTF8));
        label_3->setText(QString());
        pushButton_4->setText(QString());
        label_2->setText(QApplication::translate("MasakaClass", "\345\210\206\347\261\273", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MasakaClass", "\346\255\243\345\234\250\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MasakaClass", "Infomation", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("MasakaClass", "\347\250\213\345\272\217\350\277\220\350\241\214\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        label_17->setText(QString());
        label_6->setText(QString());
        label_10->setText(QApplication::translate("MasakaClass", "\346\234\254\346\234\272IP\357\274\232", 0, QApplication::UnicodeUTF8));
        label_16->setText(QString());
        label_14->setText(QString());
        label_22->setText(QApplication::translate("MasakaClass", "\350\277\220\350\241\214\346\250\241\345\274\217\357\274\232", 0, QApplication::UnicodeUTF8));
        label_15->setText(QString());
        label_36->setText(QApplication::translate("MasakaClass", "\346\200\273\347\272\277\347\250\213\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("MasakaClass", "\345\215\263\346\227\266\351\200\237\345\272\246\357\274\232", 0, QApplication::UnicodeUTF8));
        label_20->setText(QString());
        label_18->setText(QString());
        label_12->setText(QApplication::translate("MasakaClass", "\346\234\215\345\212\241\347\253\257\350\277\236\346\216\245\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        label_7->setText(QString());
        label_11->setText(QApplication::translate("MasakaClass", "P2P\350\277\236\346\216\245\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        label_23->setText(QApplication::translate("MasakaClass", "\345\206\205\345\255\230\345\215\240\347\224\250\357\274\232", 0, QApplication::UnicodeUTF8));
        label_37->setText(QApplication::translate("MasakaClass", "\345\275\223\345\211\215\345\205\261\344\272\253\347\233\256\345\275\225\357\274\232", 0, QApplication::UnicodeUTF8));
        label_21->setText(QString());
        label_4->setText(QApplication::translate("MasakaClass", "\345\267\262\347\237\245\350\212\202\347\202\271\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MasakaClass", "\345\267\262\350\277\236\346\216\245\350\212\202\347\202\271\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("MasakaClass", "\346\234\252\350\277\236\346\216\245\350\212\202\347\202\271\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MasakaClass: public Ui_MasakaClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MASAKA_H
