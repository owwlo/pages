/********************************************************************************
** Form generated from reading UI file 'cserveripinput.ui'
**
** Created: Sat May 5 18:16:44 2012
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CSERVERIPINPUT_H
#define UI_CSERVERIPINPUT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_CServerIpInput
{
public:
    QLabel *label;
    QLineEdit *lineEdit;

    void setupUi(QDialog *CServerIpInput)
    {
        if (CServerIpInput->objectName().isEmpty())
            CServerIpInput->setObjectName(QString::fromUtf8("CServerIpInput"));
        CServerIpInput->resize(300, 81);
        label = new QLabel(CServerIpInput);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 30, 91, 20));
        lineEdit = new QLineEdit(CServerIpInput);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(100, 30, 171, 20));

        retranslateUi(CServerIpInput);
        QObject::connect(lineEdit, SIGNAL(returnPressed()), CServerIpInput, SLOT(accept()));

        QMetaObject::connectSlotsByName(CServerIpInput);
    } // setupUi

    void retranslateUi(QDialog *CServerIpInput)
    {
        CServerIpInput->setWindowTitle(QApplication::translate("CServerIpInput", "CServerIpInput", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CServerIpInput", "Server IP:", 0, QApplication::UnicodeUTF8));
        lineEdit->setText(QApplication::translate("CServerIpInput", "127.0.0.1", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CServerIpInput: public Ui_CServerIpInput {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CSERVERIPINPUT_H
