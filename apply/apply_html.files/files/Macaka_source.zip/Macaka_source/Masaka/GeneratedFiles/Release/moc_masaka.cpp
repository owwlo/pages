/****************************************************************************
** Meta object code from reading C++ file 'masaka.h'
**
** Created: Sun May 6 12:44:55 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "StdAfx.h"
#include "../../masaka.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'masaka.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Masaka[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,    8,    7,    7, 0x05,
      54,    7,    7,    7, 0x05,

 // slots: signature, parameters, type, tag, flags
      91,    7,    7,    7, 0x0a,
     112,    7,    7,    7, 0x0a,
     127,    7,    7,    7, 0x0a,
     145,    7,    7,    7, 0x0a,
     156,    7,    7,    7, 0x0a,
     179,    7,    7,    7, 0x0a,
     192,    7,    7,    7, 0x0a,
     215,    7,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Masaka[] = {
    "Masaka\0\0,,\0Signal_LoginReturn(SOCKET,QString,QString)\0"
    "Signal_AddDownload(p2pFileMetaItem*)\0"
    "AddNewDownloadTask()\0ShowPeerInfo()\0"
    "ShowRunningInfo()\0SearchIt()\0"
    "ShowLoginFrame(SOCKET)\0DataUpdate()\0"
    "OnSearchResultUpdate()\0"
    "OnCategoryClicked(QModelIndex)\0"
};

void Masaka::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Masaka *_t = static_cast<Masaka *>(_o);
        switch (_id) {
        case 0: _t->Signal_LoginReturn((*reinterpret_cast< SOCKET(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 1: _t->Signal_AddDownload((*reinterpret_cast< p2pFileMetaItem*(*)>(_a[1]))); break;
        case 2: _t->AddNewDownloadTask(); break;
        case 3: _t->ShowPeerInfo(); break;
        case 4: _t->ShowRunningInfo(); break;
        case 5: _t->SearchIt(); break;
        case 6: _t->ShowLoginFrame((*reinterpret_cast< SOCKET(*)>(_a[1]))); break;
        case 7: _t->DataUpdate(); break;
        case 8: _t->OnSearchResultUpdate(); break;
        case 9: _t->OnCategoryClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Masaka::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Masaka::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Masaka,
      qt_meta_data_Masaka, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Masaka::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Masaka::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Masaka::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Masaka))
        return static_cast<void*>(const_cast< Masaka*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Masaka::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Masaka::Signal_LoginReturn(SOCKET _t1, QString _t2, QString _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Masaka::Signal_AddDownload(p2pFileMetaItem * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
