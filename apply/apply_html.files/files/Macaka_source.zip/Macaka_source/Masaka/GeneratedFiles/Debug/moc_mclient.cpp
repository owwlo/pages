/****************************************************************************
** Meta object code from reading C++ file 'mclient.h'
**
** Created: Sun May 6 01:20:01 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "StdAfx.h"
#include "../../mclient.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_mClient[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x05,
      39,    8,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
      73,   70,    8,    8, 0x0a,
     122,    8,    8,    8, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_mClient[] = {
    "mClient\0\0Signal_ShowLoginFrame(SOCKET)\0"
    "Signal_ShowSearchResultFrame()\0,,\0"
    "SendLoginMessageToServer(SOCKET,QString,QString)\0"
    "OnAddDownload(p2pFileMetaItem*)\0"
};

void mClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        mClient *_t = static_cast<mClient *>(_o);
        switch (_id) {
        case 0: _t->Signal_ShowLoginFrame((*reinterpret_cast< SOCKET(*)>(_a[1]))); break;
        case 1: _t->Signal_ShowSearchResultFrame(); break;
        case 2: _t->SendLoginMessageToServer((*reinterpret_cast< SOCKET(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 3: _t->OnAddDownload((*reinterpret_cast< p2pFileMetaItem*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData mClient::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject mClient::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_mClient,
      qt_meta_data_mClient, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &mClient::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *mClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *mClient::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_mClient))
        return static_cast<void*>(const_cast< mClient*>(this));
    return QThread::qt_metacast(_clname);
}

int mClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void mClient::Signal_ShowLoginFrame(SOCKET _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void mClient::Signal_ShowSearchResultFrame()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
