#include "StdAfx.h"
#include "mlivechecker.h"
#include "mglobalconfig.h"
#include "WinSock2.h"
#include <QTime>
#include <QList>

mLiveChecker* mLiveChecker::me;

mLiveChecker::mLiveChecker(QObject *parent)
	: QObject(parent)
{
	//��Ƕ����׼������Χ���ָ��
	me = this;

	timer.start();

	//����㲥
	cs = new CheckerServer();

	//����Ӧ��
	cl = new CheckerClient();

	cs->start();
	cl->start();
}

mLiveChecker::~mLiveChecker()
{

}

void mLiveChecker::UpdateLivePeerList( LivePeerItem * lpi)
{
	long currentTime = GetTickCount();
	lpi->lastCheckTime = currentTime;
	bool found = false;
}

QList<LivePeerItem*> mLiveChecker::GetPeerList()
{
	QList<LivePeerItem*> rtn;
	
	return rtn;
}

mLiveChecker* mLiveChecker::GetInstance()
{
	return me;
}

void mLiveChecker::CheckerServer::run()
{
	QString checkInterval;
	checkInterval = mGlobalConfig::getKeyValue("checkInterval");
	
	//�㲥ɨ����ʱ
	unsigned long checkIntervalTime = 5000;
	if(checkInterval != NULL && checkInterval.length() > 1)
		checkIntervalTime = checkInterval.toLong();

	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if(iResult != NO_ERROR)
	{
		printf("Error at WSAStartup()\n");
		return;
	}
	SOCKET socket1;
	struct sockaddr_in server;
	int len =sizeof(server);
	server.sin_family=AF_INET;
	server.sin_port=htons(18763); 
	server.sin_addr.s_addr=htonl(INADDR_BROADCAST);

	socket1=socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
	
	//setsockopt(socket1,SOL_SOCKET,SO_BROADCAST,&myint,4)
	bool opt = true;   
	setsockopt(socket1, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<char FAR *>(&opt), sizeof(opt));   

	while (1)
	{
		char buffer[50];

		//�㲥���ݣ�Server��ӦMasakaServer��Client��ӦMasakaClient
		ZeroMemory(buffer,sizeof(char)*50);
		QString sendStr = "REQ" + QString::number(mLiveChecker::GetInstance()->timer.elapsed());
		memcpy(buffer,sendStr.toLocal8Bit(),sendStr.toLocal8Bit().length());
		if(sendto(socket1,buffer,50,0,(struct sockaddr*)&server,len)==SOCKET_ERROR) 
		{ 
			//::closesocket(socket1); 
			qDebug()<<"faild";

		} 
		//qDebug()<<"Broadcast!";
		Sleep(2000);
	}
}

void mLiveChecker::CheckerClient::run()
{
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if(iResult != NO_ERROR)
	{
		printf("Error at WSAStartup()\n");
		return;
	}
	SOCKET socket1;
	
	SOCKADDR_IN addrSrv ;
	addrSrv.sin_addr.S_un.S_addr = INADDR_ANY ;//inet_addr(mGlobalConfig::getKeyValue("myIP").toLocal8Bit());
	addrSrv.sin_family = AF_INET ;
	addrSrv.sin_port = htons(18763) ;

	socket1=socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);

	bind( socket1 , (SOCKADDR*)&addrSrv , sizeof(addrSrv) ) ;

	while (1)
	{
		char buffer[50];
		ZeroMemory(buffer,sizeof(buffer));
		SOCKADDR_IN addrClient ;
		int len = sizeof(addrClient) ;
		recvfrom(socket1,buffer,50,0,(sockaddr*)&addrClient,&len) ;
		
		QString peerIP = inet_ntoa(addrClient.sin_addr);

		if(mGlobalConfig::IsMyIP(peerIP))
			continue;

		QString rcvstr = QString::fromLocal8Bit(buffer);
		if(rcvstr.left(3) == "ACK")
		{
			long time = rcvstr.mid(3).toLong();
			int delay = mLiveChecker::GetInstance()->timer.elapsed() - time;
			qDebug()<<peerIP<<" "<<delay;
			mLiveChecker::GetInstance()->mDelayList[peerIP] = delay;
		} 
		else if(rcvstr.left(3)=="REQ")
		{
			memcpy(buffer,"ACK",3);
			QString   strIP=inet_ntoa(addrClient.sin_addr);
			qDebug()<<strIP;
			/*
			SOCKET s2 = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);
			bool opt = true;   
			setsockopt(s2, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<char FAR *>(&opt), sizeof(opt));   */

			SOCKET socketc=::socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
			sockaddr_in addr;
			addr.sin_addr.S_un.S_addr=inet_addr(strIP.toLocal8Bit());
			addr.sin_family=AF_INET;
			addr.sin_port=ntohs(18763);
			int len2=sizeof(sockaddr);
			Sleep(100);
			sendto(socketc,buffer,50,0,(SOCKADDR*)&addr,len2);
			//sendto(socket1,buffer,50,0,(sockaddr*)&addrClient,sizeof(addrSrv));
		}
	}
}
