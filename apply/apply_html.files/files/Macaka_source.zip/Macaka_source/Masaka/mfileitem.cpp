#include "StdAfx.h"
#include "mfileitem.h"

mFileItem::mFileItem(QObject *parent)
	: QObject(parent)
{

}

mFileItem::~mFileItem()
{

}

QString mFileItem::toString()
{
	return mFileName + "@" + QString::number(mFileSize) + "@" + mFileHash;
}