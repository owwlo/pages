#include "StdAfx.h"
#include "csearchresultframe.h"
#include "mglobalconfig.h"

CSearchResultFrame * CSearchResultFrame::me;

CSearchResultFrame::CSearchResultFrame(QWidget *parent)
	: QDialog(parent)
{
	me = this;

	ui.setupUi(this);
	setWindowFlags(windowFlags()& ~Qt::WindowMaximizeButtonHint);
	setFixedSize(this->width(), this->height());
	setAttribute(Qt::WA_TranslucentBackground, true);
	setWindowFlags(Qt::FramelessWindowHint);

	model = new QStandardItemModel;
	model->setColumnCount(2);
	model->setHeaderData(0,Qt::Horizontal,tr("FileName"));
	model->setHeaderData(1,Qt::Horizontal,tr("Size"));

	//QStandardItem* item1 = new QStandardItem(tr("Windows8-ConsumerPreview-32bit-English.iso"));
	//QStandardItem* item2 = new QStandardItem(tr("4.23GB"));

	//QList<QStandardItem*> item;

	//item<<item1<<item2;
	//model->appendRow(item);
	ui.tableView->setModel(model);

	ui.tableView->setColumnWidth(0, 170);
	ui.tableView->setColumnWidth(1, 45);
}

CSearchResultFrame::~CSearchResultFrame()
{

}
void CSearchResultFrame::AddResultFromP2pFileList( QList<p2pFileMetaItem*> * list)
{
	resultList = *list;
	if(resultList.size()>0)
		UpdateResultList();
}
void CSearchResultFrame::UpdateResultList()
{
	model->removeRows(0,model->rowCount());

	//ResultWindowHelper * r = ResultWindowHelper::GetInstance();
	QList<p2pFileMetaItem*> * list = (mGlobalConfig::GetSearchResult());
	QList<p2pFileMetaItem*>::iterator i = list->begin();
	for (; i != list->end(); i++ )
	{
		p2pFileMetaItem* pfi = *i;
		QStandardItem* item1 = new QStandardItem(pfi->fileItem->mFileName);
		QStandardItem* item2 = new QStandardItem(QString::number(pfi->fileItem->mFileSize));
		QList<QStandardItem*> item;
		item<<item1<<item2;
		model->appendRow(item);
	}
}
void CSearchResultFrame::OnDoubleClickItem( QModelIndex index )
{
	//this->setVisible(false);
	selectItem = resultList.at(index.row());
	resultList.clear();
	this->accept();
	//move(500,500);
}

CSearchResultFrame * CSearchResultFrame::GetInstance()
{
	return me;
}

p2pFileMetaItem * CSearchResultFrame::GetSelectFileItem()
{
	return selectItem;
}
