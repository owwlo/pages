#ifndef CTRANSFERSERVER_H
#define CTRANSFERSERVER_H

#include <QThread>
#include <WinSock2.h>

class CTransferServer : public QThread
{
	Q_OBJECT

public:
	~CTransferServer();
	static CTransferServer * GetInstance();

	class FileServerThreadForClient:public QThread
	{
	public:
		FileServerThreadForClient(int clientSock,struct sockaddr_in clientAddr);
		virtual void run();
		void SendMessage(QString s);

	private:
		void OrderDispatcher(QString);

	private:
		int mClientSock;
		sockaddr_in		 	mClientAddr;
	};

private:
	CTransferServer(QObject *parent);

	virtual void run();

	static CTransferServer * me;
	
};

#endif // CTRANSFERSERVER_H
