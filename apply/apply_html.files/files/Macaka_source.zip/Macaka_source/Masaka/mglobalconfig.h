#ifndef MGLOBALCONFIG_H
#define MGLOBALCONFIG_H

#include <QObject>
#include "mclient.h"

class mGlobalConfig : public QObject
{
	Q_OBJECT

public:
	mGlobalConfig(QObject *parent);
	~mGlobalConfig();
	static QString			getKeyValue(QString _key);
	static void				setKeyValue(QString _key,QString _value);
	static void				AddToMyIPList(QString ip);
	static bool				IsMyIP(QString ip);
	static void				StartRunningTime();
	static long				GetRunningTime();
	static QList<QString>	GetMyIPs();
	static QString			GetLocalSharePath();
	static void				SetLocalSharePath(QString path);
	static void				init();
	static QList<p2pFileMetaItem*> * GetSearchResult();
	static void SetSearchResult(QList<p2pFileMetaItem*> *);
private:
	static QHash<QString,QString>	mConfigDictionary;
	static QVector<QString>			myIPList;
	static QTime	runningTime;
	static QString	sharePath;
	static QList<p2pFileMetaItem*> * mSearchResult;	
};

#endif // MGLOBALCONFIG_H
