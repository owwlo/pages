#include "StdAfx.h"
#include "mglobalconfig.h"
#include <QSettings>

QHash<QString,QString>	mGlobalConfig::mConfigDictionary;
QVector<QString>		mGlobalConfig::myIPList;
QTime					mGlobalConfig::runningTime;
QString					mGlobalConfig::sharePath;

mGlobalConfig::mGlobalConfig(QObject *parent)
	: QObject(parent)
{

}

mGlobalConfig::~mGlobalConfig()
{

}

QString mGlobalConfig::getKeyValue( QString _key )
{
	return mConfigDictionary[_key];
}

void mGlobalConfig::setKeyValue( QString _key,QString _value )
{
	mConfigDictionary[_key] = _value;
}

bool mGlobalConfig::IsMyIP( QString ip )
{
	return myIPList.contains(ip);
}

void mGlobalConfig::AddToMyIPList( QString ip )
{
	myIPList.append(ip);
}

long mGlobalConfig::GetRunningTime()
{
	return runningTime.elapsed();
}

void mGlobalConfig::StartRunningTime()
{
	runningTime.start();
}

QList<QString> mGlobalConfig::GetMyIPs()
{
	return myIPList.toList();
}

void mGlobalConfig::SetLocalSharePath( QString path )
{
	sharePath = path;
}

QString mGlobalConfig::GetLocalSharePath()
{
	return sharePath;
}

void mGlobalConfig::init()
{
	QSettings *ConfigIni = new QSettings(QApplication::applicationDirPath() + "/conf.ini",QSettings::IniFormat,0); 
	QStringList keyList = ConfigIni->allKeys();
	for each(QString k in keyList)
	{
		setKeyValue(k,ConfigIni->value(k).toString());
	}
	delete ConfigIni;  
}
