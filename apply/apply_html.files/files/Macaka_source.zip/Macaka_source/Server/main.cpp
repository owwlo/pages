#include "stdafx.h"
#include <QtGui/QApplication>
#include <qlocale.h>
#include <QDebug>
#include <QPluginLoader>
#include "mserver.h"
#include "usermanager.h"
#include "mglobalconfig.h"
#include "WinSock2.h"


QString pr(QString s)
{
	return QTime::currentTime().toString()+" "+s;
}

//�õ�������IP��
void GetMyIPs()
{
	WSADATA wsaData;
	char name[255];
	char *ip;
	PHOSTENT hostinfo;
	if ( WSAStartup( MAKEWORD(2,2), &wsaData ) == 0 ) {
		if( gethostname ( name, sizeof(name)) == 0) {
			if((hostinfo = gethostbyname(name)) != NULL) {

				int i = 0;
				while(hostinfo->h_addr_list[i])
				{
					ip = inet_ntoa (*(IN_ADDR*)hostinfo->h_addr_list[i]); 
					qDebug()<<QString::fromLocal8Bit(ip);
					mGlobalConfig::AddToMyIPList(ip);
					i++;
				}
			}}}
}

int main(int argc, char *argv[])
{
	//QCoreApplication a(argc, argv);
	QApplication a(argc, argv);

	mGlobalConfig::init();
	mGlobalConfig::StartRunningTime();

	//���ó������
	QTextCodec *codec = QTextCodec::codecForName("System"); 
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);

	//�Ƿ�ΪServerMode����
	bool isServerMode = true;

	//�õ�����IP��
	GetMyIPs();

	//΢���źڡ�����Ȥζ����
	a.setFont(QFont("Microsoft YaHei",9));

	//mServer�̳߳�ʼ��
	MServer ms(&a);
	ms.InitMServer(isServerMode);
	ms.start();

	return a.exec();
	
}


/************************************************************************/
/* dll������ط��������ο�*/
/************************************************************************/
//IPingBoy * mPB;
//QPluginLoader pluginLoader("PingBoy.dll");
//QObject *plugin = pluginLoader.instance();
//mPB = (IPingBoy *)(plugin);
//mPB->InitPingBoy(true);

//QLibrary lib("PingBoy.dll");     
//if (lib.load())     
//{     
//	// �������е���������������ԭ��     
//	typedef IPingBoy* (*CreatePingBoyFunction)();     
//	typedef void (*ReleasePingBoyFunction)(IPingBoy* pingBoy);     

//	// ������������     
//	CreatePingBoyFunction createPingBoy =      
//		(CreatePingBoyFunction) lib.resolve("CreatePingBoy");     
//	ReleasePingBoyFunction releasePingBoy =      
//		(ReleasePingBoyFunction) lib.resolve("ReleasePingBoy");     

//	if (createPingBoy && releasePingBoy)     
//	{     
//		// ����Animal����     
//		IPingBoy * pingBoy = createPingBoy();     
//		if (pingBoy)     
//		{     
//			// ʹ�ò������     
//			pingBoy->InitPingBoy(true,false);
//			pingBoy->StartPingBoy();
//			//releasePingBoy(pingBoy);     
//		}     
//	}     
//	// ж�ز��     
//	//lib.unload();     
//}     

//Tax *taxObject;
//QPluginLoader pluginLoader("Tax.dll");
//QObject *plugin = pluginLoader.instance();
//taxObject= qobject_cast<Tax *>(plugin);
//qDebug()<<((Tax*)plugin)->aaa();
//return 0;