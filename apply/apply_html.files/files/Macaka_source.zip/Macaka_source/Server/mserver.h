#ifndef MSERVER_H
#define MSERVER_H

#include <QThread>
#include <list>
#include "mfileitem.h"
#include <QSet>
#include <WinSock2.h>

//���ջ�����Ĭ�ϴ�С
#define RCVBUFFER_LENGTH 1024*10

using namespace std ;

//p2p�ļ�����meta�ṹ��
struct p2pFileMetaItem
{
	mFileItem*		fileItem;
	QSet<QString>	ipList;
};

class MServer : public QThread
{
	Q_OBJECT

	class ServerThreadForClient;

public:
	MServer(QObject *parent);
	~MServer();

	//��ʼ��mServer�߳�
	void InitMServer(bool isPureServer = true ,int ServerPort = 23125);
	virtual void run();
	void PeerExit(ServerThreadForClient*);

	//�����ļ�
	QList<p2pFileMetaItem*>* SearchForFiles(QString s);
	static MServer* GetInstance();

private:
	void RenewServerKnownFilesList();
	static MServer *me;

	//���ÿһ�����ӵĴ����߳�
	class ServerThreadForClient:public QThread
	{
	public:
		ServerThreadForClient(int clientSock,struct sockaddr_in clientAddr);
		virtual void run();
		void updateClientFileList();
		QList<p2pFileMetaItem*>* GetSharedFilesList();
		void SendMessage(QString s);

	private:
		void OrderDispatcher(QString);
		void updateClientFileListFromString(QString);
		void SearchSharedFilesList(QString s);

	private:
		bool				isLogin;
		int mClientSock;
		QMutex				mClientFileListLock;
		sockaddr_in		 	mClientAddr;
		QList<mFileItem*>	mClientFileList;
	};

	//mServer�����Ķ˿ں�
	int mPort;

	//��ʶ�Ƿ�Ϊ��Server
	bool							mIsPureServer;

	QList<int>						mClientSockList;
	QList<struct sockaddr *>		mClientAddrPtrList;
	QList<ServerThreadForClient * >	mClientThreadList;
	QList<p2pFileMetaItem*>			mServerKnownFileList;
	QMutex							mServerKnownFileListLocker;
};

#endif // MSERVER_H
