#include "StdAfx.h"
#include <WinSock2.h>
#include "mserver.h"
#include <QString>
#include <QStringList>
#include "usermanager.h"
#include "mglobalconfig.h"

MServer* MServer::me;

MServer::MServer(QObject *parent)
	: QThread(parent)
{
	me = this;
}

MServer::~MServer()
{
	
}

void MServer::run()
{
	qDebug()<<"PureServerMode:\t"<<mIsPureServer<<"\tPort:\t"<<mPort;

	int iServerSock;
	sockaddr_in ServerAddr;
	WSADATA WSAData;
	if( WSAStartup( MAKEWORD( 2, 2 ), &WSAData ) )
	{
		WSACleanup( );
	}

	if( ( iServerSock = socket( AF_INET, SOCK_STREAM, 0 ) ) == INVALID_SOCKET )
	{
		WSACleanup( );
	}
	ServerAddr.sin_family = AF_INET;
	ServerAddr.sin_port = htons( mPort );
	ServerAddr.sin_addr.s_addr = INADDR_ANY;
	memset( & ( ServerAddr.sin_zero ), 0, sizeof( ServerAddr.sin_zero ) );
	if( bind( iServerSock, ( struct sockaddr * )&ServerAddr, sizeof( struct sockaddr ) ) == -1 )
	{
		WSACleanup( );
	}

	if( listen( iServerSock, 10 ) == -1 )
	{
		WSACleanup( );
	}
	qDebug()<<"Begin to Listen";
	while( TRUE )
	{
		//char *buf = "hello, world!/n";
		sockaddr_in ClientAddr;
		int sin_size = sizeof( struct sockaddr_in );

		int iClientSock = accept( iServerSock, ( struct sockaddr * )&ClientAddr, &sin_size );

		if( iClientSock == -1 )
		{
			WSACleanup( );
		}

		//socketѹ�뵱ǰclient��socket��
		mClientSockList.push_back(iClientSock);

		//��ַ��Ϣѹ��client�ĵ�ַ��
		mClientAddrPtrList.push_back(( struct sockaddr * )&ClientAddr);

		qDebug()<<"Client "<<iClientSock<<" has Joint server";
		
		//�½�һ���̴߳���accept��socket
		ServerThreadForClient *stfc = new ServerThreadForClient(iClientSock, ClientAddr);
	
		//�߳�ѹ�뵱ǰclient�̱߳�
		mClientThreadList.push_back(stfc);

		stfc->start();

	}
	qDebug()<<"Exit Server!";
	WSACleanup();
}

void MServer::InitMServer( bool isPureServer , int ServerPort  )
{
	mIsPureServer = isPureServer;

	mGlobalConfig::setKeyValue("isServer",(isPureServer?"1":"0"));

	mPort = ServerPort;
}

QList<p2pFileMetaItem*>* MServer::SearchForFiles( QString s )
{
	//��mServer��֪client���Ӹ���mServer��֪�����ļ���
	RenewServerKnownFilesList();

	mServerKnownFileListLocker.lock();

	QList<p2pFileMetaItem*> *rtnList = new QList<p2pFileMetaItem*>;

	QList<p2pFileMetaItem*>::iterator i = mServerKnownFileList.begin();
	for(;i != mServerKnownFileList.end(); i++)
	{
		if((*i)->fileItem->mFileName.toLower().indexOf(s.toLower()) != -1)
		{
			rtnList->push_back(*i);
		}
	}
	mServerKnownFileListLocker.unlock();

	return rtnList;
}

MServer* MServer::GetInstance()
{
	return me;
}

void MServer::RenewServerKnownFilesList()
{
	mServerKnownFileListLocker.lock();

	mServerKnownFileList.clear();

	QList<ServerThreadForClient * >::iterator i = mClientThreadList.begin();
	
	//����ÿ����֪ServerThreadForClient
	for (;i != mClientThreadList.end(); i++)
	{
		mServerKnownFileList += *((*i)->GetSharedFilesList());
	}
	
	mServerKnownFileListLocker.unlock();
}

void MServer::PeerExit( ServerThreadForClient* child )
{
	qDebug()<<"Clean for "<<child;
}

void MServer::ServerThreadForClient::run()
{
	qDebug()<<"Thread for client "<<mClientSock<<" start!";
	
	//Ĭ��δ��¼
	isLogin = false;

	//in_addr ip;
	//ip.S_un.S_addr = ( (sockaddr_in*)mClientAddr )->sin_addr.s_addr;    
	//char* clientIp = inet_ntoa( ip );
	//qDebug()<<clientIp;

	UserManager * um = UserManager::GetInstance();

	//�ж��Ƿ���Ҫ��֤
	if(um->isAuthNeeded())
		//���͵�¼��֤����
		SendMessage("RQLI");
	else
		isLogin = true;

	while (1)
	{
		char buf[RCVBUFFER_LENGTH];
		ZeroMemory(buf,sizeof(buf));
		int err5 = ::recv(mClientSock,buf,RCVBUFFER_LENGTH,0);
		//int sendData = ::send(s,"Hello!",sizeof("Hello!")+1,0);
		/*if(sendData == SOCKET_ERROR)
		{
			DWORD err6 = WSAGetLastError();
			closesocket(s);
			WSACleanup();
		}*/
		if (err5 == SOCKET_ERROR)
		{
			qDebug()<<"recv error :"<<mClientSock;
			
			MServer *ms = MServer::GetInstance();
			ms->PeerExit(this);

			closesocket(mClientSock);
			break;
		}
		OrderDispatcher(QString::fromLocal8Bit(buf));

		Sleep(500);
	}
}

MServer::ServerThreadForClient::ServerThreadForClient(int clientSock,sockaddr_in clientAddr )
{
	mClientAddr = clientAddr;
	mClientSock = clientSock;
}

void MServer::ServerThreadForClient::OrderDispatcher( QString s)
{
	qDebug()<<"Client "<<mClientSock<<" sends:\t"<<s;

	QString action,args;

	//��Ϣ�е�����
	action = s.left(4);
	//����Ĳ���
	args = s.mid(4);

	qDebug()<<"Action:"<<action<<"\tArgs:"<<args;

	//������֤��Ϣ
	if(action == "LGIN")
	{
		QStringList ql;
		QString username,password;
		//�õ�UserManagerʵ��
		UserManager * uerMgr = UserManager::GetInstance();

		ql = args.split("#");
		username = ql.at(0);
		password = ql.at(1);
		qDebug()<<"LoginUserName:"<<username<<"\tpassword:"<<password;
		if(uerMgr->Authenticate(username,password) == UserManager::CONGRATULATION)
		{
			qDebug()<<"LoginSuccess";

			//���ͻ�ӭ��Ϣ
			SendMessage("LRESLoginInSuccess!");
			isLogin = true;
		}
		else
		{
			qDebug()<<"LoginFail";

			//��ǸŶ�ף���¼ʧ�ܡ���
			SendMessage("EROR");
			closesocket(mClientSock);
		}
	}
	//���������ļ��б���Ϣ
	else if (action == "SHRE" && isLogin)
	{
		updateClientFileListFromString(args);
	}
	//���������ļ�������Ϣ
	else if (action == "SRCH" && isLogin)
	{
		SearchSharedFilesList(args);
	}
}
//Ҫ��ͻ��˷��͸����ļ��б�������
void MServer::ServerThreadForClient::updateClientFileList()
{
	send(mClientSock,"RNFL",sizeof("RNFL"),0);
}

/*
**	�����ļ��б���ʽ
**	SHRE1.zip@213123@dhu23eh#2.zip@3123@23422dea
*/
void MServer::ServerThreadForClient::updateClientFileListFromString( QString s)
{
	//���ԭ�����ļ��б�
	mClientFileList.clear();
	qDebug()<<"Got share-file-list from "<<mClientSock<<": "<<s;
	QStringList fileList;
	fileList = s.split("#");
	qDebug()<<"Got "<<fileList.size()<<" files from "<<mClientSock;

	//����client�����б��������µ�mClientFileList
	foreach(QString str,fileList)
	{
		if(str.length() < 2)
			continue;

		QStringList	 fileArgs;
		mFileItem	 *mfi = new mFileItem(0);

		fileArgs = str.split("@");
		mfi->mFileName = fileArgs.at(0);
		mfi->mFileSize = fileArgs.at(1).toLong();
		mfi->mFileHash = fileArgs.at(2);

		mClientFileList.push_back(mfi);
	}
}

QList<p2pFileMetaItem*> * MServer::ServerThreadForClient::GetSharedFilesList()
{
	QList<p2pFileMetaItem*> *rtn = new QList<p2pFileMetaItem*>;

	foreach(mFileItem* fi,mClientFileList)
	{
		p2pFileMetaItem* p2pfile = new p2pFileMetaItem;
		p2pfile->fileItem = fi;
		p2pfile->ipList += QString::fromLocal8Bit(inet_ntoa((mClientAddr).sin_addr));

		rtn->push_back(p2pfile);
	}

	return rtn;
}

void MServer::ServerThreadForClient::SearchSharedFilesList( QString s )
{
	MServer *ms = MServer::GetInstance();
	
	QList<p2pFileMetaItem*> *resultSet = ms->SearchForFiles(s);
	
	QString fStr;

	QList<p2pFileMetaItem*>::iterator i = resultSet->begin();
	for (; i != resultSet->end() ; i++)
	{
		p2pFileMetaItem* fi = *i;
		QString itemStr;
		QString ipListStr;
		
		QSet<QString>::iterator j = fi->ipList.begin();
		for (; j != fi->ipList.end() ; j++)
		{
			QString ip = *j;
			ipListStr += ip + "!";
		}

		itemStr = fi->fileItem->toString() + "@" + ipListStr;

		fStr += itemStr + "#";
	}
	fStr = "SRHR" + fStr;

	send(mClientSock,fStr.toLocal8Bit(),fStr.toLocal8Bit().length(),0);
}

//��mClient��������
void MServer::ServerThreadForClient::SendMessage( QString s )
{
	send(mClientSock,s.toLocal8Bit(),s.toLocal8Bit().length(),0);
}
