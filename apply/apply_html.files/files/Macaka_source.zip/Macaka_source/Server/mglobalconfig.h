#ifndef MGLOBALCONFIG_H
#define MGLOBALCONFIG_H

#include <QObject>

class mGlobalConfig : public QObject
{
	Q_OBJECT

public:
	mGlobalConfig(QObject *parent);
	~mGlobalConfig();
	static QString			getKeyValue(QString _key);
	static void				setKeyValue(QString _key,QString _value);
	static void				AddToMyIPList(QString ip);
	static bool				IsMyIP(QString ip);
	static void				StartRunningTime();
	static long				GetRunningTime();
	static QList<QString>	GetMyIPs();
	static QString			GetLocalSharePath();
	static void				SetLocalSharePath(QString path);
	static void				init();
private:
	static QHash<QString,QString>	mConfigDictionary;
	static QVector<QString>			myIPList;
	static QTime	runningTime;
	static QString	sharePath;
};

#endif // MGLOBALCONFIG_H
