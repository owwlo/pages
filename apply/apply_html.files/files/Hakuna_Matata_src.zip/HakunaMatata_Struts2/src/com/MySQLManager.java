package com;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class MySQLManager {
	private final String url = "jdbc:mysql://127.0.0.1:3306/hakuna_matata?characterEncoding=utf8";
	private final String user = "root";
	private final String password = "wwldesql";
	private Connection conn;
	private Statement statement;

	public MySQLManager() {
		try {
			conn = (Connection) DriverManager
					.getConnection(url, user, password);
			statement = (Statement) conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//formTest f=new formTest();
	}

	public void addFileItemInfoIntoSQL(String fileName, int uploadUser,
			String hash, String description, long fileSize, String uploadDate,
			String fileLocalURI, String extension) {
		String insql = "insert into files(fileName,uploadUser,hash,description,fileSize,uploadDate,fileLocalURI,extension) values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps;

		try {
			ps = conn.prepareStatement(insql);
			ps.setString(1, fileName);
			ps.setInt(2, uploadUser);
			ps.setString(3, hash);
			ps.setString(4, description);
			ps.setLong(5, fileSize);
			ps.setString(6, uploadDate);
			ps.setString(7, fileLocalURI);
			ps.setString(8, extension);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addUser(String userEmail, String password) {
		String insql = "insert into users(userEmail,password) values(?,?)";
		PreparedStatement ps;

		try {
			ps = conn.prepareStatement(insql);
			ps.setString(1, userEmail);
			ps.setString(2, password);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public LoginUserInfo loginValid(String userEmail, String password) {
		String rtnStr="-1";
		LoginUserInfo lui=new LoginUserInfo();
		lui.setToken(rtnStr);
		try {
			statement.setMaxRows(1);
			String sqla="update users set token=rand() where userEmail='"
					+ userEmail
					+ "' and password='"
					+ password+"'";
			statement.execute(sqla);
			ResultSet rs = statement
					.executeQuery("select * from users where userEmail='"
							+ userEmail + "' and password='" + password+"'");
			while (rs.next()) {
				rtnStr=rs.getString("token");
				lui.setToken(rtnStr);
				lui.setUserID(rs.getInt("id"));
				lui.setUserMail(userEmail);
				lui.setScore(rs.getInt("score"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lui;
	}
	public LoginUserInfo getUserInfoFromToken(String token)
	{
		String rtnStr="-1";
		LoginUserInfo lui=new LoginUserInfo();
		lui.setToken(rtnStr);
		try {
			statement.setMaxRows(1);
			ResultSet rs = statement
					.executeQuery("select * from users where token='"
							+ token + "'");
			while (rs.next()) {
				rtnStr=rs.getString("token");
				lui.setToken(rtnStr);
				lui.setUserID(rs.getInt("id"));
				lui.setUserMail(rs.getString("userEmail"));
				lui.setScore(rs.getInt("score"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lui;
	}
	public ArrayList<SearchResultItem> getFileSearchResults(String searchStr)
	{
		ArrayList<SearchResultItem> al=new ArrayList<SearchResultItem>();
		try {
			statement.setMaxRows(1000);
			ResultSet rs = statement
					.executeQuery("select * from files where fileName like '%"
							+ searchStr + "%'");
			while (rs.next()) {
				SearchResultItem item=new SearchResultItem();
				item.setFileName(rs.getString("fileName"));
				item.setDescription(rs.getString("description"));
				item.setExtension(rs.getString("extension"));
				item.setFileID(rs.getInt("id"));
				item.setFileSize(rs.getLong("fileSize"));
				item.setHash(rs.getString("hash"));
				item.setUploadDate(rs.getDate("uploadDate"));
				item.setUploadUser(rs.getInt("uploadUser"));
				item.setUri(rs.getString("fileLocalURI"));
				al.add(item);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return al;
	}
	public void addScoreFromToken(String token,int score)
	{
		if(token!=null && !token.equals("-1"))
			try {
				String sqla="update users set score=score+"+String.valueOf(score)+" where token='"
						+ token
						+ "'";
				statement.execute(sqla);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	public SearchResultItem getFileInfoFromID(int id)
	{
		SearchResultItem item=new SearchResultItem();
		try {
			statement.setMaxRows(1);
			ResultSet rs = statement
					.executeQuery("select * from files where id="
							+ id);
			while (rs.next()) {
				item=new SearchResultItem();
				item.setFileName(rs.getString("fileName"));
				item.setDescription(rs.getString("description"));
				item.setExtension(rs.getString("extension"));
				item.setFileID(rs.getInt("id"));
				item.setFileSize(rs.getLong("fileSize"));
				item.setHash(rs.getString("hash"));
				item.setUploadDate(rs.getDate("uploadDate"));
				item.setUploadUser(rs.getInt("uploadUser"));
				item.setUri(rs.getString("fileLocalURI"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return item;
	}
	public int createNewAccount(String userEmail, String password)
	{
		String insql = "insert into users(userEmail,password) values(?,?)";
		PreparedStatement ps;

		try {
			ps = conn.prepareStatement(insql);
			ps.setString(1, userEmail);
			ps.setString(2, password);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return 1;
	}
}
