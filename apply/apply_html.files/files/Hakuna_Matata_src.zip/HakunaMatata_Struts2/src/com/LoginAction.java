package com;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private String userEmail;
	private String password;
	private MySQLManager sql=SQL.sql;

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {

		if (!userEmail.equals("") && !password.equals("")) {
			LoginUserInfo lui=sql.loginValid(userEmail,password);
			if(!lui.getToken().equals("-1"))
			{
				Map hs=ActionContext.getContext().getSession();
				hs.put("userMail", lui.getUserMail());
				hs.put("userID", lui.getUserID());
				hs.put("token", lui.getToken());
				return Action.SUCCESS;
			}
			return Action.ERROR;
		} else {
			//super.addActionError(super.getText("login.message.failed"));
			return Action.ERROR;
		}
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

}
