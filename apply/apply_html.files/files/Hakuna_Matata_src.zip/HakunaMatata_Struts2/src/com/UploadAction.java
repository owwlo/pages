package com;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;
import org.apache.struts2.ServletActionContext;

public class UploadAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	
	private static final int BUFFER_SIZE = 16 * 1024 ;
	
	private MySQLManager sql=SQL.sql;
	private File myFile;
    private String contentType;
    private String fileName;
    
    private static void copy(File src, File dst) {
        try {
           InputStream in = null ;
           OutputStream out = null ;
            try {                
               in = new BufferedInputStream( new FileInputStream(src), BUFFER_SIZE);
               out = new BufferedOutputStream( new FileOutputStream(dst), BUFFER_SIZE);
                byte [] buffer = new byte [BUFFER_SIZE];
                while (in.read(buffer) > 0 ) {
                   out.write(buffer);
               } 
           } finally {
                if ( null != in) {
                   in.close();
               } 
                if ( null != out) {
                   out.close();
               } 
           } 
       } catch (Exception e) {
           e.printStackTrace();
       } 
   } 
    private String getExtention(String fileName)
	{
		int extStart=fileName.lastIndexOf(".");
		if(extStart!=-1)
		{
			return fileName.substring(extStart+1);
		}
		else
		{
			return "";
		}
	}

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		Map hs=ActionContext.getContext().getSession();
		if(hs.get("token")==null || hs.get("token").equals("-1"))
			return Action.ERROR;
		String FileName =String.valueOf((new Date()).getTime());
		//FileName=fileName;
        File file = new File("c:\\upload\\"+FileName);
        copy(myFile, file);
        
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1"); 
        FileInputStream in = new FileInputStream(file.getAbsolutePath()); 
        FileChannel ch = in.getChannel(); 
        MappedByteBuffer byteBuffer = ch.map(FileChannel.MapMode.READ_ONLY, 0, file.length()); 
        messageDigest.update(byteBuffer); 
        String date=(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(file.lastModified());
        String hash=String.valueOf(Hex.encodeHex(messageDigest.digest()));
        
        sql.addFileItemInfoIntoSQL(fileName,(int)hs.get("userID"), hash, "no", file.length(), date, file.getAbsolutePath(), getExtention(fileName));
        sql.addScoreFromToken(hs.get("token").toString(), 10);
        return SUCCESS;
	}

	public File getMyFile() {
		return myFile;
	}

	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setMyFileContentType(String contentType) {
        this .contentType = contentType;
   } 
   
    public void setMyFileFileName(String fileName) {
        this .fileName = fileName;
   } 
   
}
