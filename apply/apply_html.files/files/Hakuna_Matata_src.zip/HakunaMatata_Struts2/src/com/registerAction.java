package com;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class registerAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private String userEmail;
	private String password;
	private MySQLManager sql=SQL.sql;

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {

		if(sql.createNewAccount(userEmail,password)==1)
		{
			return Action.SUCCESS;
		}
		else
		{
			return Action.ERROR;
		}
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

}
