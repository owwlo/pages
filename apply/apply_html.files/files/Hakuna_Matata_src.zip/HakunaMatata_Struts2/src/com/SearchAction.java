package com;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class SearchAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private String searchStr;
	private MySQLManager sql=SQL.sql;

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {

		if (!searchStr.equals("")) {
			ActionContext.getContext().getSession().put("searchStr", searchStr);
			return Action.SUCCESS;
		} else {
			return Action.ERROR;
		}
	}

	public String getSearchStr() {
		return searchStr;
	}

	public void setSearchStr(String searchStr) {
		this.searchStr = searchStr;
	}

	

}
