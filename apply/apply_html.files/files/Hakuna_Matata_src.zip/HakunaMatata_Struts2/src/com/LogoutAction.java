package com;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LogoutAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {

		Map hs=ActionContext.getContext().getSession();
		hs.put("token", "-1");
		return Action.SUCCESS;
	}

}
