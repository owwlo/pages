package com;

import java.io.FileInputStream;
import java.io.InputStream;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;

public class FileDownload extends ActionSupport {

	private static final long serialVersionUID = 1L;
	
	private MySQLManager sql=SQL.sql;
	
	private String inputPath;
    private String contentType;
    private String filename;
    private String downid;
    
    public InputStream getInputStream() throws Exception {

        return new FileInputStream(inputPath); 
    }
    
	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		System.out.println("downID:"+downid);
		 SearchResultItem fi=sql.getFileInfoFromID(Integer.parseInt(downid));
		 
		 inputPath = fi.getUri();
		 System.out.println(inputPath);
	     filename = fi.getFileName();
	     contentType = "application/octet-stream;charset=utf8";
	     return SUCCESS;
	}

	public String getInputPath() {
		return inputPath;
	}

	public void setInputPath(String inputPath) {
		this.inputPath = inputPath;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getDownid() {
		return downid;
	}

	public void setDownid(String downid) {
		this.downid = downid;
	}

	
}
