package com;


public class SQL {
	public static MySQLManager sql=new MySQLManager();
}
