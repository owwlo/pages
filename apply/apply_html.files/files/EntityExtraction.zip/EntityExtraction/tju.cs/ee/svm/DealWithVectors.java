package ee.svm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 * @author owwlo
 * @version $Revision: 1.0 $, $Date: 2012/03/19 $
 * 
 *          处理并分解生成的向量文件。
 */
public class DealWithVectors {

	public static void main(String[] args) {
		try {
			StringBuilder sb1 = new StringBuilder();
			StringBuilder sb2 = new StringBuilder();
			
			BufferedReader br;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(
					"C:\\svmVectors.txt"), "utf8"));
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				String classNumStr = line.substring(0,2).trim();
				int classNum = Integer.parseInt(classNumStr);
				if(classNum == 8)
				{
					sb1.append(line+"\n");
				}
				else
				{
					sb2.append("42 " + line.substring(2).trim()+"\n");
				}
			}
			
			FileWriter fw1 = new FileWriter("c:\\classA.txt");
			BufferedWriter bw1 = new BufferedWriter(fw1);
			bw1.write(new String(sb1));
			bw1.flush();
			bw1.close();
			
			FileWriter fw2 = new FileWriter("c:\\classB.txt");
			BufferedWriter bw2 = new BufferedWriter(fw2);
			bw2.write(new String(sb2));
			bw2.flush();
			bw2.close();
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
