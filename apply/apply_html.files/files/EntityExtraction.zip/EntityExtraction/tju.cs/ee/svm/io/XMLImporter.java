package ee.svm.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.SAXReader;

/**
 * @author owwlo
 * @version $Revision: 1.0 $, $Date: 2012/02/25 $
 * 
 *          Import entity relation date from XML file.
 */
public class XMLImporter {
	
	private Document document;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		XMLImporter xi = new XMLImporter("c:\\entityRelation.txt");
		
	}
	/**
	 * 读取单个的xml文件
	 * @param filePath待读取xml的文件路径
	 */
	public XMLImporter(String filePath) {
		try {
			String xmlString = "";
			
			//以utf8读取xml
			FileInputStream fis=new FileInputStream(filePath);
			InputStreamReader isr=new InputStreamReader(fis,"UTF-8");
			BufferedReader br=new BufferedReader(isr);
			String line;
			while((line=br.readLine())!=null)
			{
				xmlString = xmlString + line ;
			}
			
			//xmlString = new String(xmlString.getBytes("GBK"),"UTF-8");
			
			//纠正xml格式
			xmlString = prepareRawXMLString(xmlString);
			
			System.out.println("rawStringText: "+xmlString);
			
			//String转换为document
			//SAXReader reader = new SAXReader();
			document = DocumentHelper.parseText(xmlString);
			
		} catch (DocumentException e) {
			System.err
					.println("unable to open xml file or unable to convert it to xml document.");
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.err.println("unable to open file");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/**
	 * 用来处理xml读入字符串，将xTYPE替换为TYPEx（xTYPE不符合xml规范）
	 * @param raw
	 * @return
	 */
	private String prepareRawXMLString(String raw)
	{
		//将xTYPE改为TYPEx
		for(int i=1; i<=9; i++)
		{
			raw = raw.replaceAll(i+"TYPE", "TYPE"+i);
		}
		
		if(raw.substring(0, 10).indexOf("<?xml") == -1)
		{
			raw = "<?xml version=\"1.0\"?><source_file><document>" + raw + "</document></source_file>";
		}
		
		return raw;
	}
	/**
	 * 返回xml生成的document
	 * @return
	 */
	public Document getDocument()
	{
		return document;
	}

}
