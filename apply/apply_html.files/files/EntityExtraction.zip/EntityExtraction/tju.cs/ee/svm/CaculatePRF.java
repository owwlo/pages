package ee.svm;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class CaculatePRF {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ArrayList<Integer> test = new ArrayList<>();
			ArrayList<Integer> result = new ArrayList<>();

			BufferedReader bra;
			bra = new BufferedReader(new InputStreamReader(new FileInputStream(
					"C:\\svm\\SvmTest.txt"), "utf8"));
			String line;
			while ((line = bra.readLine()) != null) {
				String classNumStr = line.substring(0, 2).trim();
				int classNum = Integer.parseInt(classNumStr);
				test.add(classNum);
			}
			
			BufferedReader brb;
			brb = new BufferedReader(new InputStreamReader(new FileInputStream(
					"C:\\svm\\result"), "utf8"));
			while ((line = brb.readLine()) != null) {
				//String classNumStr = line.substring(0, 2).trim();
				int classNum = (int)Double.parseDouble(line);
				result.add(classNum);
			}
			
			int ap1 = 0,ap2 = 0,ar1 = 0,ar2 = 0;
			int bp1 = 0,bp2 = 0,br1 = 0,br2 = 0;
			for(int i=0;i<test.size();i++)
			{
				int t = test.get(i);
				int r = result.get(i);
				if(t == r && t == 8)
					ap1++;
				if(r == 8)
					ap2++;
				if(t == 8)
					ar2++;
				
				if(t == r && t == 42)
					bp1++;
				if(r == 42)
					bp2++;
				if(t == 42)
					br2++;		
			}
			ar1 = ap1;
			br1 = bp1;
			
			int b = 1;
			double pa,ra,pb,rb;
			
			pa = (double)ap1/(double)ap2;
			pb = (double)bp1/(double)bp2;
			ra = (double)ar1/(double)ar2;
			rb = (double)br1/(double)br2;
			double fa = (b*b+1)*pa*ra/Math.pow(b, 2*pa)+ra;
			double fb = (b*b+1)*pb*rb/Math.pow(b, 2*pb)+rb;
			
			System.out.println("类8的PRF(f中b=1):");
			System.out.println("p:\t"+pa+"\tr:\t"+ra+"\tf:\t"+fa);
			
			System.out.println();
			
			System.out.println("类42的PRF(f中b=1):");
			System.out.println("p:\t"+pb+"\tr:\t"+rb+"\tf:\t"+fb);
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
