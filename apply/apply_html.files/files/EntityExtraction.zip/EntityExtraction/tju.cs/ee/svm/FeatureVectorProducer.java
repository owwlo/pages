package ee.svm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import ICTCLAS.I3S.AC.ICTCLAS50;

import ee.svm.io.XMLImporter;
import ee.type.AnalyzedSentenceBlock;

/**
 * @author owwlo
 * @version $Revision: 1.0 $, $Date: 2012/02/25 $
 * 
 *          Generate feature vectors for svm to train with.
 */
public class FeatureVectorProducer {

	public FeatureVectorProducer() {
		InitICTCLAS();
		FileHandler fileHandler;
		try {
			fileHandler = new FileHandler("SvmVectorLog.log");
			log.setLevel(Level.ALL);
			fileHandler.setFormatter(new MyLogHander());
			log.addHandler(fileHandler);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private ICTCLAS50 testICTCLAS50;

	// logger
	private static Logger log = Logger.getLogger(FeatureVectorProducer.class
			.getName());

	// 用来存储特征向量的二次索引哈希map……我了个擦！得吃多大内存啊！
	private HashMap<String, LinkedList<String>> vectorsMap = new HashMap<String, LinkedList<String>>();

	// 所有需要忽略的傅浩
	private static final String SYMBOLS = "，。、；‘【】、-=·！“”@#￥%……&*（）~—+｛｝|：:?><,,./><;'\":[]\\|}{+~!@#$%^&*()_+";

	// 标识橘子结束的傅浩
	private static final String SENTENCE_END_SYMBOLS = ".。？?!！;；";

	// 52个特征向量名称
	private String[] vectorName = { "sc1", "sc2", "sm1", "sm2", "sm12", "s1q1",
			"s1q2", "s2h1", "s2h2", "s1qz0", "s1qz1", "s2hz0", "s2hz1", "szf1",
			"szl1", "szqc", "szc1", "szmc", "stl1", "stl2", "stl3", "stl4",
			"stcl", "stcf", "s1bs2", "s2bs1", "s1fls2", "s1xls2", "STL1+S1BS2",
			"STL2+S1BS2", "STL3+S1BS2", "STL4+S1BS2", "STL1+S2BS1",
			"STL2+S2BS1", "STL3+S2BS1", "STL4+S2BS1", "STL1+S1XLS2",
			"STL2+S1XLS2", "STL3+S1XLS2", "STL4+S1XLS2", "STL1+S1FLS2",
			"STL2+S1FLS2", "STL3+S1FLS2", "STL4+S1FLS2", "SM12+S1BS2",
			"SM12+S2BS1", "SM12+S1XLS2", "SM12+S1FLS2", "S1LYCC", "S2LYCC",
			"STP", "STPC" };

	// 用户词典字符串
	private static String userDictString;

	// 14个关系索引
	private ArrayList<String> relationIndexFinder = new ArrayList<>();
	private String[] relationIndex = { "xiangjiao", "xiangjie", "baohan",
			"xibei", "youduyin", "youjingdu", "youweidu", "zhengfuzhudi",
			"guanxia", "lishu", "youlishiming", "youxianjinming",
			"youjiancheng", "youbieming" };
	
	private HashMap<String,Integer> relationStats = new HashMap<>();
	
	/**
	 * test function
	 */
	public static void main(String[] args) {

		FeatureVectorProducer fvp = new FeatureVectorProducer();
		fvp.generateModelFromDirectory("c:\\sm\\relation", "c:\\sm\\tagged",
				"c:\\svmVectors.txt");

	}

	public void generateModelFromDirectory(String relationTextDirPath,
			String taggedTextDirPath, String vectorsSavePath) {

		// 取得文件夹遍历文件列表
		ArrayList<String> fileList = refreshFileList(relationTextDirPath);

		System.out.println("Found " + fileList.size()
				+ " files in the directory.");

		// 创建特征向量map最外层名字索引（写入52个向量表头）
		generateAHugeOfVectorHashMap(vectorsMap);

		// 创建向量分类索引
		InitRelationIndexFinder();

		// 存储向量的StringBuilder
		StringBuilder sb = new StringBuilder();

		Iterator<String> it = fileList.iterator();
		while (it.hasNext()) {
			String relationFilePath = it.next();
			String relationFileName = relationFilePath
					.substring(relationFilePath.lastIndexOf("\\") + 1);
			String taggedFileName = relationFileName.substring(0,
					relationFileName.indexOf(".")) + ".txt";
			String taggedFilePath = taggedTextDirPath + "\\" + taggedFileName;

			System.out.println("当前文件:\t" + relationFilePath);

			// 导入当前xml文件
			XMLImporter xi = new XMLImporter(relationFilePath);
			// 得到xml文件对应的document
			Document doc = xi.getDocument();

			System.out.println("成功加载实体关系XML文件：\t" + relationFilePath);
			// System.out.println(doc.getRootElement().elements(arg0));
			List<? extends Node> relationList = doc.getRootElement()
					.element("document").elements("relation");
			List<? extends Node> entityList = doc.getRootElement()
					.element("document").elements("entity");
			System.out.println(relationList.size());
			Iterator nodeIt = relationList.iterator();
			while (nodeIt.hasNext()) {
				Element elem = (Element) nodeIt.next();
				String singleFeatureVector = getFeatherVectorFromXMLRelationNode(
						elem, entityList);
				if (singleFeatureVector != null
						&& singleFeatureVector.length() > 1) {
					sb.append(singleFeatureVector);
				}
			}
		}

		// 保存向量表
		try {
			String str = new String(sb);
			if (str.length() > 1) {
				FileWriter fw;
				fw = new FileWriter(vectorsSavePath);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(str);
				bw.flush();
				bw.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//输出最终的关系索引表
		System.out.println("最终关系索引表：");
		System.out.println(relationIndexFinder.toString());
		
		System.out.println(relationStats.toString());

	}

	private String getFeatherVectorFromXMLRelationNode(Element elem,
			List<? extends Node> entityList) {

		StringBuilder sb = new StringBuilder();

		List<? extends Node> relationMentionList = elem
				.elements("relation_mention");
		Iterator it = relationMentionList.iterator();
		while (it.hasNext()) {
			Element relationMentionSingleNode = (Element) it.next();
			String relationMentionVector = getFeatherVectorFromXMLRelationMentionNode(
					relationMentionSingleNode, elem.attributeValue("TYPE"),
					entityList);
			sb.append(relationMentionVector + "\n");
		}

		return new String(sb);
	}

	private String getFeatherVectorFromXMLRelationMentionNode(
			Element relationMentionSingleNode, String type,
			List<? extends Node> entityList) {

		// 当前关系提及的关系
		String mRelation;

		// 当前关系的“实体A”和“实体B”
		String mEntityA;
		String mEntityB;

		// 实体a和实体b在asblist里的index
		int mEntityAIndex = -1;
		int mEntityBIndex = -1;

		// 实体a和实体b的分类信息
		ArrayList<String> mEntityACategory;
		ArrayList<String> mEntityBCategory;

		// 当前关系的经分词标注器处理后的句子字符串
		String mTaggedExcharseq;

		// 当前关系的句子字符串
		String mExcharseq;

		// 句子对应的AnalyzedSentenceBlockList
		ArrayList<AnalyzedSentenceBlock> mASBL;

		// 特征向量的哈希表
		HashMap<String, Integer> featureVectorMap = new HashMap<>();

		mRelation = type;
		List<Element> el = relationMentionSingleNode
				.elements("relation_mention_argument");

		mEntityA = el.get(0).attributeValue("ROLE").indexOf("1") != -1 ? el
				.get(0).element("extent").element("charseq").getText() : el
				.get(1).element("extent").element("charseq").getText();
		mEntityB = el.get(0).attributeValue("ROLE").indexOf("2") != -1 ? el
				.get(0).element("extent").element("charseq").getText() : el
				.get(1).element("extent").element("charseq").getText();
		mExcharseq = relationMentionSingleNode.element("extent")
				.element("excharseq").getText();

		String refidA = el.get(0).attributeValue("ROLE").indexOf("1") != -1 ? el
				.get(0).attributeValue("REFID") : el.get(1).attributeValue(
				"REFID");
		String refidB = el.get(0).attributeValue("ROLE").indexOf("2") != -1 ? el
				.get(0).attributeValue("REFID") : el.get(1).attributeValue(
				"REFID");
		String idA = refidA.substring(0, refidA.indexOf("-"));
		String idB = refidB.substring(0, refidB.indexOf("-"));

		// 分词结果不包括实体A或B则将实体加入字典再分（写得恶心！很恶心！）
		mTaggedExcharseq = ICTCLAS_ParagraphProcess(mExcharseq);
		mASBL = getASBLFromTaggedExcharseq(mTaggedExcharseq);
		boolean isAExist = false;
		boolean isBExist = false;
		Iterator<AnalyzedSentenceBlock> it = mASBL.iterator();
		while (it.hasNext()) {
			AnalyzedSentenceBlock asb = it.next();
			if (asb.getPureTerm().equals(mEntityA))
				isAExist = true;
			if (asb.getPureTerm().equals(mEntityB))
				isBExist = true;
		}

		if (!isAExist) {
			System.out.println("Add " + mEntityA + " to UserDict.");
			addUserTermToUserDict(mEntityA + "@@ns");
			if (!isBExist) {
				addUserTermToUserDict(mEntityB + "@@ns");
				System.out.println("Add " + mEntityA + " to UserDict.");
			}
			mTaggedExcharseq = ICTCLAS_ParagraphProcess(mExcharseq);
			mASBL = getASBLFromTaggedExcharseq(mTaggedExcharseq);
		}

		// 干掉傅浩
		for (int i = 0; i < mASBL.size(); i++) {
			AnalyzedSentenceBlock asb = mASBL.get(i);
			if (SYMBOLS.indexOf(asb.getPureTerm()) >= 0) {
				mASBL.remove(asb);
				i--;
			}
		}

		// 得到两个实体的所引值
		/**
		 * 此处需要改写……临时方法，效果不好
		 */
		for (int i = 0; i < mASBL.size(); i++) {
			AnalyzedSentenceBlock asb = mASBL.get(i);
			if (asb.getPureTerm().equals(mEntityA) && mEntityAIndex == -1)
				mEntityAIndex = i;
			if (asb.getPureTerm().equals(mEntityB))
				mEntityBIndex = i;
		}

		// 找不到实体则输出error信息，继续
		if (mEntityAIndex == -1 || mEntityBIndex == -1) {
			System.err.println("未能找到 " + "\"" + mEntityA + "\"" + " 或 " + "\""
					+ mEntityB + "\"");
			System.err.println(mTaggedExcharseq);
			return "";
		}

		// 得到两个实体对应的分类
		Iterator its = entityList.iterator();
		mEntityACategory = new ArrayList<String>();
		mEntityBCategory = new ArrayList<String>();
		while (its.hasNext()) {
			Element elem = (Element) its.next();
			// System.out.println(elem.attributeValue("ID"));
			if (elem.attributeValue("ID").equals(idA))
				getEntityTypes(elem, mEntityACategory);
			else if (elem.attributeValue("ID").equals(idB))
				getEntityTypes(elem, mEntityBCategory);
		}

		System.out.println("实体A：\t" + mEntityA);
		System.out.println("实体B：\t" + mEntityB);
		System.out.println("实体AID：\t" + idA);
		System.out.println("实体BID：\t" + idB);
		System.out.println("关系类型：\t" + mRelation);
		System.out.println("标注后句子:\t" + mTaggedExcharseq);
		System.out.println("除符号后句子:\t" + mASBL.toString());

		String SM12 = mEntityA + "+" + mEntityB;
		featureVectorMap.put("sc1", getDimensional("sc1", mEntityA));
		featureVectorMap.put("sc2", getDimensional("sc2", mEntityB));
		featureVectorMap.put("sm1", getDimensional("sm1", mEntityA));
		featureVectorMap.put("sm2", getDimensional("sm2", mEntityB));
		featureVectorMap.put("sm12",
				getDimensional("sm12", mEntityA + "+" + mEntityB));

		// 如果存在s1q1
		int s1q1_Dep = mEntityAIndex - 1;
		int s1q2_Dep = s1q1_Dep - 1;
		if (s1q1_Dep >= 0) {
			featureVectorMap.put("s1q1",
					getDimensional("s1q1", mASBL.get(s1q1_Dep).getPureTerm()));

			// 如果存在s1q2
			if (s1q2_Dep >= 0)
				featureVectorMap.put(
						"s1q2",
						getDimensional("s1q2", mASBL.get(s1q2_Dep)
								.getPureTerm()));
		}

		// 如果存在s2h1
		int s2h1_Dep = mEntityBIndex + 1;
		int s2h2_Dep = s2h1_Dep + 1;
		if (s2h1_Dep < mASBL.size()) {
			featureVectorMap.put("s2h1",
					getDimensional("s2h1", mASBL.get(s2h1_Dep).getPureTerm()));

			// 如果存在s2h2
			if (s2h2_Dep < mASBL.size())
				featureVectorMap.put(
						"s2h2",
						getDimensional("s2h2", mASBL.get(s2h2_Dep)
								.getPureTerm()));
		}
		// S1QZ1和S1QZ0
		if (s1q1_Dep == 0)
			featureVectorMap.put("s1qz1", 1);
		else
			featureVectorMap.put("s1qz1", 0);
		if (s1q1_Dep < 0)
			featureVectorMap.put("s1qz0", 1);
		else
			featureVectorMap.put("s1qz0", 0);
		// S2HZ1和S2HZ0
		if (s2h1_Dep == mASBL.size() - 1)
			featureVectorMap.put("s2hz1", 1);
		else
			featureVectorMap.put("s2hz1", 0);
		if (s2h1_Dep > mASBL.size() - 1)
			featureVectorMap.put("s2hz0", 1);
		else
			featureVectorMap.put("s2hz0", 0);

		// SZMC、SZF1、SZL1、SZQC、SZC1
		int dep = Math.abs(mEntityAIndex - mEntityBIndex);
		if (dep == 1)
			featureVectorMap.put("szmc", 1);
		else {
			// 未考虑到SZQC不为空也就是有其他词的情况
			featureVectorMap.put("szmc", 0);
			// 中间有一个词的情况
			if (dep == 2) {
				featureVectorMap.put("szf1", 0);
				featureVectorMap.put("szl1", 0);
				featureVectorMap.put("szqc", 0);
				featureVectorMap.put(
						"szc1",
						getDimensional("szc1",
								mASBL.get((mEntityAIndex + mEntityBIndex) / 2)
										.getPureTerm()));
			}
			// 中间两个以上词情况
			else {
				int low, high;
				high = Math.max(mEntityAIndex, mEntityBIndex);
				low = Math.min(mEntityAIndex, mEntityBIndex);
				
				//处理同一个词的关系，跳过
				if(high==0)
					return "";
				
				featureVectorMap
						.put("szf1",
								getDimensional("szf1", mASBL.get(low + 1)
										.getPureTerm()));
				featureVectorMap.put(
						"szl1",
						getDimensional("szl1", mASBL.get(high - 1)
								.getPureTerm()));
				featureVectorMap.put("szqc", 0);
				featureVectorMap.put("szc1", 0);
			}
		}

		// STL1、STL2、STL3、STL4
		String STL1="", STL2="", STL3="", STL4="";
		try{
		STL1 = mEntityACategory.get(0) + mEntityBCategory.get(0);
		STL2 = mEntityACategory.get(1) + mEntityBCategory.get(1);
		STL3 = mEntityACategory.get(2) + mEntityBCategory.get(2);
		STL4 = mEntityACategory.get(3) + mEntityBCategory.get(3);
		}catch( java.lang.IndexOutOfBoundsException e)
		{
			//System.err.println("IDA:"+idA+" IDB:"+idB);
//			try {
				if(idA.equals(idB))
					System.err.println("IDA和IDB相同：\t"+idA);
				//System.in.read();
				return "";
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
		}
		featureVectorMap.put("stl1", getDimensional("stl1", STL1));
		featureVectorMap.put("stl2", getDimensional("stl2", STL2));
		featureVectorMap.put("stl3", getDimensional("stl3", STL3));
		featureVectorMap.put("stl4", getDimensional("stl4", STL4));

		/**
		 * 没加入stcl、stcf，论文里没有例子，不理解
		 */
		String STCL = "n", STCF = "n";

		// S1BS2、S2BS1、S1XLS2、S1FLS2
		String S1BS2 = "n", S2BS1 = "n", S1XLS2 = "n", S1FLS2 = "n";

		if (mEntityAIndex <= mEntityBIndex
				&& mEntityA.length() > mEntityB.length()) {
			S1BS2 = "y";
			featureVectorMap.put("s1bs2", getDimensional("s1bs2", "y"));
		}
		if (mEntityBIndex <= mEntityAIndex
				&& mEntityB.length() > mEntityA.length()) {
			S2BS1 = "y";
			featureVectorMap.put("s2bs1", getDimensional("s2bs1", "y"));
		}
		if (Math.abs(mEntityAIndex - mEntityBIndex) == 1) {
			S1XLS2 = "y";
			featureVectorMap.put("s1xls2", getDimensional("s1xls2", "y"));
		} else if (Math.abs(mEntityAIndex - mEntityBIndex) > 1) {
			S1FLS2 = "y";
			featureVectorMap.put("s1fls2", getDimensional("s1fls2", "y"));
		}

		// 那一坨+++++++++
		featureVectorMap.put("STL1+S1BS2",
				getDimensional("STL1+S1BS2", STL1 + S1BS2));
		featureVectorMap.put("STL2+S1BS2",
				getDimensional("STL2+S1BS2", STL2 + S1BS2));
		featureVectorMap.put("STL3+S1BS2",
				getDimensional("STL3+S1BS2", STL3 + S1BS2));
		featureVectorMap.put("STL4+S1BS2",
				getDimensional("STL4+S1BS2", STL4 + S1BS2));
		featureVectorMap.put("STL1+S2BS1",
				getDimensional("STL1+S2BS1", STL1 + S2BS1));
		featureVectorMap.put("STL2+S2BS1",
				getDimensional("STL2+S2BS1", STL2 + S2BS1));
		featureVectorMap.put("STL3+S2BS1",
				getDimensional("STL3+S2BS1", STL3 + S2BS1));
		featureVectorMap.put("STL4+S2BS1",
				getDimensional("STL4+S2BS1", STL4 + S2BS1));
		featureVectorMap.put("STL1+S1XLS2",
				getDimensional("STL1+S1XLS2", STL1 + S1XLS2));
		featureVectorMap.put("STL2+S1XLS2",
				getDimensional("STL2+S1XLS2", STL2 + S1XLS2));
		featureVectorMap.put("STL3+S1XLS2",
				getDimensional("STL3+S1XLS2", STL3 + S1XLS2));
		featureVectorMap.put("STL4+S1XLS2",
				getDimensional("STL4+S1XLS2", STL4 + S1XLS2));
		featureVectorMap.put("STL1+S1FLS2",
				getDimensional("STL1+S1FLS2", STL1 + S1FLS2));
		featureVectorMap.put("STL2+S1FLS2",
				getDimensional("STL2+S1FLS2", STL2 + S1FLS2));
		featureVectorMap.put("STL3+S1FLS2",
				getDimensional("STL3+S1FLS2", STL3 + S1FLS2));
		featureVectorMap.put("STL4+S1FLS2",
				getDimensional("STL4+S1FLS2", STL4 + S1FLS2));
		featureVectorMap.put("SM12+ S1BS2",
				getDimensional("SM12+S1BS2", SM12 + S1BS2));
		featureVectorMap.put("SM12+S2BS1",
				getDimensional("SM12+S2BS1", SM12 + S2BS1));
		featureVectorMap.put("SM12+S1XLS2",
				getDimensional("SM12+S1XLS2", SM12 + S1XLS2));
		featureVectorMap.put("SM12+S1FLS2",
				getDimensional("SM12+S1FLS2", SM12 + S1FLS2));

		// S1LYCC、S2LYCC
		int low = Math.min(mEntityAIndex, mEntityBIndex);
		int high = Math.max(mEntityBIndex, mEntityAIndex);
		int vCount = 0;
		String vTrem = "";
		while (low <= high) {
			AnalyzedSentenceBlock asb = mASBL.get(low);
			if (asb.getTermAttribute().indexOf("v") == 0) {
				vCount++;
				vTrem = asb.getPureTerm();
			}
			low++;
		}
		if (vCount == 1) {
			featureVectorMap.put(
					"S1LYCC",
					getDimensional("S1LYCC", mASBL.get(mEntityAIndex)
							.getTermAttribute() + vTrem));
			featureVectorMap.put(
					"S2LYCC",
					getDimensional("S2LYCC", mASBL.get(mEntityBIndex)
							.getTermAttribute() + vTrem));
		}

		/**
		 * STP、STPC论文中看不懂，未加
		 */

		return GenerateFeatureVectorTextLine(featureVectorMap, mRelation);
	}

	private void InitRelationIndexFinder() {
		for (int i = 0; i < relationIndex.length; i++) {
			relationIndexFinder.add(relationIndex[i]);
			relationStats.put(relationIndex[i], new Integer(0));
		}

	}

	private String GenerateFeatureVectorTextLine(
			HashMap<String, Integer> featureVectorMap, String mRelation) {
		// 当前向量分类
		int mClass;

		// 返回字符串
		StringBuilder rtn;

		mClass = relationIndexFinder.indexOf(mRelation);
		rtn = new StringBuilder();

		if (mClass < 0) {
			System.err.println("未能在分类器中找到关系：\t" + mRelation);
			relationIndexFinder.add(mRelation);
			relationStats.put(mRelation, new Integer(0));
			mClass = relationIndexFinder.indexOf(mRelation);
		}
		
		//类型统计+1
		relationStats.put(mRelation, relationStats.get(mRelation)+1);

		for (int i = 0; i < vectorName.length; i++) {
			Integer v = featureVectorMap.get(vectorName[i]);
			if (v == null || v == 0)
				continue;
			log.finest(mClass + " " + (vectorName[i] + ":" + v + " "));
			rtn.append(i + ":" + v + " ");
			
		}

		String vec = mClass + " " + new String(rtn);

		System.out.println("得到向量：");
		System.out.println(vec + "\n");
		// log.finer("maxM:"+Runtime.getRuntime().maxMemory()+" free:"+Runtime.getRuntime().);
		//log.finest(vec);

		return vec;
	}

	private void getEntityTypes(Element elem, ArrayList<String> mEntityCategory) {
		for (int i = 1; i <= 6; i++) {
			String mType = elem.attributeValue("TYPE" + i);
			if (mType != null && mType.length() > 1)
				mEntityCategory.add(mType);
			else
				mEntityCategory.add("N");
		}
	}

	private int getDimensional(String dimensionalName, String dimensionalValue) {
		System.out.println(dimensionalName + ":\t" + dimensionalValue);
		LinkedList<String> ll = vectorsMap.get(dimensionalName);
		if (ll.indexOf(dimensionalValue) == -1)
			ll.add(dimensionalValue);
		return ll.indexOf(dimensionalValue);
	}

	private ArrayList<AnalyzedSentenceBlock> getASBLFromTaggedExcharseq(
			String taggedExcharseq) {
		taggedExcharseq = taggedExcharseq.trim().replaceAll("  ", " ");
		ArrayList<AnalyzedSentenceBlock> mASBL = new ArrayList<>();
		String tmp[] = taggedExcharseq.split(" ");

		for (int i = 0; i < tmp.length; i++) {
			try {
				mASBL.add(new AnalyzedSentenceBlock(tmp[i]));
			} catch (StringIndexOutOfBoundsException e) {
				System.err.println(tmp[i]);
				System.err.println(taggedExcharseq);
			}

		}

		return mASBL;
	}

	private void InitICTCLAS() {
		try {
			testICTCLAS50 = new ICTCLAS50();
			String argu = ".";
			// 初始化
			if (testICTCLAS50.ICTCLAS_Init(argu.getBytes("GB2312")) == false) {
				System.out.println("标注器加载失败！");
				return;
			}

			// 设置词性标注集(0 计算所二级标注集，1 计算所一级标注集，2 北大二级标注集，3 北大一级标注集)
			testICTCLAS50.ICTCLAS_SetPOSmap(0);

			// 导入用户字典
			int nCount = 0;
			String usrdir = "userdict.txt"; // 用户字典路径
			byte[] usrdirb = usrdir.getBytes();// 将string转化为byte类型
			// 导入用户字典,返回导入用户词语个数第一个参数为用户字典路径，第二个参数为用户字典的编码类型
			nCount = testICTCLAS50.ICTCLAS_ImportUserDictFile(usrdirb, 0);
			System.out.println("导入用户词个数" + nCount);
			nCount = 0;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String ICTCLAS_ParagraphProcess(String sInput) {
		try {

			// 导入用户字典后再分词
			byte nativeBytes1[] = testICTCLAS50.ICTCLAS_ParagraphProcess(
					sInput.getBytes("GB2312"), 2, 1);
			// System.out.println(nativeBytes1.length);
			String nativeStr1 = new String(nativeBytes1, 0,
					nativeBytes1.length, "GB2312");
			// System.out.println("导入用户词典后的分词结果： " + nativeStr1);
			// 保存用户字典
			// testICTCLAS50.ICTCLAS_SaveTheUsrDic();
			// 释放分词组件资源
			// testICTCLAS50.ICTCLAS_Exit();
			return nativeStr1;
		} catch (Exception ex) {
		}
		return null;
	}

	/**
	 * 遍历文件夹得到文件目录
	 * 
	 * @param strPath
	 * @return
	 */
	private ArrayList<String> refreshFileList(String strPath) {
		File dir = new File(strPath);
		File[] files = dir.listFiles();
		ArrayList<String> filelist = new ArrayList<String>();
		if (files == null)
			return null;
		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				filelist.addAll(refreshFileList(files[i].getAbsolutePath()));
			} else {
				String strFileName = files[i].getAbsolutePath().toLowerCase();
				filelist.add(files[i].getAbsolutePath());
			}
		}
		return filelist;
	}

	private void generateAHugeOfVectorHashMap(
			HashMap<String, LinkedList<String>> hm) {
		for (int i = 0; i < vectorName.length; i++) {
			vectorsMap.put(vectorName[i], new LinkedList<String>() {
				{
					add("bottom");
				}
			});
		}
		System.out
				.println("添加 " + vectorName.length + " 个特征向量维度元数据到VectorMap!");
	}

	private void addUserTermToUserDict(String newTerm) {
		try {
			// 若首次执行先再如用户词典字符串
			if (userDictString == null) {

				BufferedReader br = new BufferedReader(new InputStreamReader(
						new FileInputStream("userdict.txt"), "utf8"));
				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}
				userDictString = new String(sb);
			}

			// 新单词加入用户词典
			if (userDictString.indexOf(newTerm) == -1) {
				userDictString += newTerm + "\n";
				saveUserDict();
			}

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void saveUserDict() {
//		try {
//			FileWriter fw = new FileWriter("userdict.txt");
//			BufferedWriter bw = new BufferedWriter(fw);
//
//			bw.write(userDictString);
//			bw.flush();
//			bw.close();
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

	class MyLogHander extends Formatter {
		@Override
		public String format(LogRecord record) {
			return record.getLevel() + ":" + record.getMessage() + "\n";
		}
	}
}
