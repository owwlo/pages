package ee.type;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 	@author owwlo
 *	@version $Revision: 1.0 $, $Date: 2012/02/12 $
 *	
 *	A data type to deal with block.  
 */
public class AnalyzedSentenceBlock {
	
	private String _blockString;
	private int _pureTermLength;
	
	public AnalyzedSentenceBlock(String initBlockString)
	{
		this.setBlockString(initBlockString);
	}
	public AnalyzedSentenceBlock()
	{
		this.setBlockString("");
	}
	/**
	 *	test function
	 */
	public static void main(String[] args) {
		AnalyzedSentenceBlock test=new AnalyzedSentenceBlock();
		test.setBlockString("[三千/m 余/n 年/t]SJ");
		test.setBlockString("[北京市/ns]DLST-RWDLST-XZQY-YJXZQY-YJXZQYCSX");
		//test.setBlockString("旧称/v");
		//test.setBlockString("[/w");
		//test.setBlockString("]/w");
		
		System.out.println("getPureTerm:      "+test.getPureTerm());
		System.out.println("getTermAttribute: "+test.getTermAttribute());
		System.out.println("getCategories:    "+test.getCategories().toString());
		
	}

	public void setBlockString(String _block) {
		this._blockString = _block;
		_pureTermLength = getPureTerm().length();
	}
	/**
	 * 返回block中纯文本字符串长度
	 */
	public int getPureTermLength()
	{
		return _pureTermLength;
	}
	public LinkedList<String> getCategories()
	{
		LinkedList<String> _result = new LinkedList<String>();
		boolean _isBlocked;
		String _categoriesRawString;
		String _categoriesString[];
		
		_isBlocked=((-1 < _blockString.indexOf("[")) 
				&& (_blockString.indexOf("[") < _blockString.lastIndexOf("]")));
		
		//如过不包括分类的话
		if(!_isBlocked)
			return _result;
		
		_categoriesRawString = _blockString.substring(_blockString.indexOf("]")+1);
		_categoriesString = _categoriesRawString.split("-");
		
		for(int i=0; i<_categoriesString.length; i++)
		{
			_result.add(_categoriesString[i]);
		}
		
		return _result;
	}
	/**
	 * 返回block中内容被标注的属性,如 “天才/n” 返回 "n"
	 */
	public String getTermAttribute()
	{
		//记录block中属性的总个数
		boolean _attrCountAboveOne;
		
		_attrCountAboveOne=_blockString.indexOf("/", _blockString.indexOf("/")+1)==-1?false:true;
		
		//当block中含多个属性时，返回外层，如[三千/m 余/n 年/t]SJ返回SJ
		if(_attrCountAboveOne)
			return _blockString.substring(_blockString.indexOf("]")+1);
		
		Pattern pattern = Pattern.compile("/+[a-zA-Z]*");
		Matcher matcher = pattern.matcher(_blockString); 
		matcher.find();
		return matcher.group(0).substring(1);
	}
	
	/**
	 * 返回block中的短语内容
	 * @param block如 “[三千/m 余/n 年/t]SJ ”
	 * @return 如 “ 三千余年 ”
	 */
	public String getPureTerm() throws StringIndexOutOfBoundsException
	{
		try{
			if(_blockString.charAt(0) == '[' && _blockString.indexOf("]") != -1)
			{
				Pattern pattern = Pattern.compile("/+[a-zA-Z]*");
				Matcher matcher = pattern.matcher(_blockString.substring(1,_blockString.indexOf("]")));
				return matcher.replaceAll("").replaceAll(" ", "");
			}
			else
				return _blockString.substring(0, _blockString.indexOf("/"));
		}
		catch(StringIndexOutOfBoundsException e){
			System.err.println(_blockString);
			e.printStackTrace();
			throw e;
		}
	}
	@Override
	public String toString() {
		return _blockString;
	}

}
