package ee.type;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author owwlo
 * @version $Revision: 1.0 $, $Date: 2012/02/12 $
 * 
 *          A data type to deal with TaggedDocument.
 */
public class TaggedDocument {

	// 标注的原始文本
	//private String taggedRawText;
	
	//文档的terms集合
	private ArrayList<AnalyzedSentenceBlock> termBlocks;
	
	/**
	 * test function
	 */
	public static void main(String[] args) {
		try {
			TaggedDocument td = new TaggedDocument("c:\\relationSource\\entity.txt");
			System.out.println(td.getAnalyzedSentenceBlockFromStart(20).getPureTerm());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * 根据start返回包含内容的AnalyzedSentenceBlock
	 * @param start
	 * @return 若未找到返回null
	 */
	public AnalyzedSentenceBlock getAnalyzedSentenceBlockFromStart(int start)
	{
		int totalLength=1;
		Iterator<AnalyzedSentenceBlock> it = termBlocks.iterator();
		while(it.hasNext())
		{
			AnalyzedSentenceBlock currentASB = it.next();
			System.out.println(currentASB.getPureTerm()+" "+totalLength);
			totalLength += currentASB.getPureTermLength();
			if(totalLength > start)
				return currentASB;
		}
		return null;
	}
	/**
	 * 返回index指向的termBlock
	 * @param index 索引
	 * @return index指向的termBlock
	 */
	public AnalyzedSentenceBlock getTermBlockAt(int index)
	{
		return termBlocks.get(index);
	}
	public TaggedDocument(String taggedTextFilePath)
			throws FileNotFoundException {
		try {
			BufferedReader br = new BufferedReader(new FileReader(
					taggedTextFilePath));

			String taggedRawText = "";
			String line;

			while ((line = br.readLine()) != null) {
				taggedRawText += line;
			}
			
			generateTermBlocks(taggedRawText);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void generateTermBlocks(String taggedRawText) 
	{
		//空格split后结果
		String[] _splitedShorts;
		int _blockIndex;
		
		if(termBlocks == null)
			termBlocks=new ArrayList<>();
		
		_splitedShorts = taggedRawText.split(" ");
		_blockIndex = 0;
		
		while(_blockIndex<_splitedShorts.length)
		{
			//用来记录“[]”配对情况
			int _symbolCounter=0;
			for ( ; _blockIndex<_splitedShorts.length; _blockIndex++ )
			{
				//当前处理的字符串
				String 	_currentString;
				_currentString = _splitedShorts[_blockIndex];
				
				//当前处理字符串的ASB类型
				AnalyzedSentenceBlock asb=new AnalyzedSentenceBlock(_currentString);
				
				//将block加入到待处理句子block集合
				termBlocks.add(asb);
			}
		}
	}
}
