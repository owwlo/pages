/**
 * 
 */
package ee.maxent.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.accessibility.internal.resources.accessibility;

import ee.type.AnalyzedSentenceBlock;

/**
 * 	@author owwlo
 *	@version $Revision: 1.0 $, $Date: 2012/02/12 $
 *	
 *	This class transform text analyzed into Vectors for MaxEnt. 
 */
public class VectorMaker {
	
	//所有需要忽略的傅浩
	private static final String SYMBOLS = 
			"，。、；‘【】、-=·！“”@#￥%……&*（）~—+｛｝|：:?><,,./><;'\":[]\\|}{+~!@#$%^&*()_+";
	//标识橘子结束的傅浩
	private static final String SENTENCE_END_SYMBOLS =
			".。？?!！;；";

	/**
	 * test class function
	 */
	public static void main(String[] args) {
		VectorMaker vm =new VectorMaker();
		//System.out.println(vm.getPureTermFromBlock("[三千/m 余/n 年/t]SJ"));
		LinkedList<HashMap> ll = vm.getVectorsListFromAnalyzedText("[安徽省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 接/v 邻省/n 份/q ：/w [浙江省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 、/w [江苏省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 、/w [山东省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 、/w [河南省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 、/w [湖北省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 、/w 江西省/ns 。/w 地质/n 省/n 境地/n 跨/v 三/m 大/a 构造/n 单元/n ，/w 淮北/ns 和/c 沿/p 淮/x 两侧/nl 属于/v 中/nd 朝/p 准/v 地/u 台/n 南部/nd ，/w 地层/n 中/nd 富含/v 前/nd 震旦/ns 纪/n 的/u 沉积/v 变质/v 铁矿/n （/w 如/v 霍/nhf 丘/n ）/w 和/c 二/m 叠/v 纪/n 煤层/n （/w 如/v 淮/x 南/nd 、/w 淮北/ns ）/w ；/w 皖/j 西/nd [大别山/ns]DLST-ZRDLST-LDDX-QL 区/n 和/c 江淮/ns 地区/n 部分/n 为/vl [秦岭/ns]DLST-ZRDLST-LDDX-QL 褶皱/n 系/n 的/u 东端/nd ，/w 分布/v 有/v 前/nd 震旦/ns 纪/n 沉积/v 变质/v 磷矿/n 层/q （/w 如/v 宿/v 松/n 、/w 肥/a 东/nd ）/w ；/w 沿江/n 和/c 皖南/ns 属于/v 扬/v 子/n 准/v 地/u 台/n 的/u 东北/nl 部分/n ，/w 古生代/nt 和/c 三/m 叠/v 纪/n 为/vl 海水/n 淹没/v ，/w 广泛/a 沉积/v 了/u 层/q 厚/a 、/w 质/n 纯/a 的/u 白云/n 岩/n 和/c 灰/n 岩/n ，/w [燕山/ns]DLST-ZRDLST-LDDX-QL 运动/n 期间/nt 沿江/n 一带/n 岩浆/n 活动/v 普遍/a 、/w 频繁/a ，/w 形成/v 了/u 具有/v 工业/n 意义/n 的/u 铁/n 、/w 铜/n 、/w 硫/n 、/w 钒/n 、/w 铅/n 、/w 锌/n 、/w 明矾/n 石/n 等/u 矿藏/n 和/c 石油/n 资源/n 。/w 在/p 淮北/ns 地区/n 近年/nt 又/d 发现/v 了/u 金矿/n 。/w 气候/n 、/w 土壤/n 、/w 植被/n 与/c 地貌/n 季风气候/n 显著/a ，/w 四季/nt 分明/a ，/w 终年/nt 温和/a 湿润/a ，/w 并/c 有/v 明显/a 的/u 南北/nd 过渡/v 特征/n 。/w 其中/nd [淮河/ns]DLST-ZRDLST-SX-HL 以北/nd 为/vl 暖/a 温带/n 半/m 湿润/a 季风气候/n ；/w [淮河/ns]DLST-ZRDLST-SX-HL 以南/nd 、/w [黄山/ns]DLST-ZRDLST-LDDX-QL 山脉/n 以北/nd 为/vl 北/nd 亚热带/nl 湿润/a 季风气候/n ；/w [黄山/ns]DLST-ZRDLST-LDDX-QL 山脉/n 以南/nd 为/vl 中/nd 亚热带/nl 湿润/a 季风气候/n 。/w 自然/a 植被/n 和/c 土壤/n 亦/d 因此/c 自/p 北/nd 而/c 南/nd 更迭/v ，/w 即/d 落叶/n 阔叶林/n -/w 棕/n 壤/n ；/w 落叶/n 阔叶/n 、/w 常绿/a 阔叶/n 混交/v 林/n -/w 黄/a 棕/n 壤/n 和/c 常绿/a 阔叶林/n -/w 黄/a 、/w 红/a 壤/n 。/w 在/p 主要/a 栽培/v 作物/n 方面/n ，/w 也/d 依次/d 有/v 小麦/n 、/w 杂粮/n 、/w 麦/n 稻/n 过渡/v 和/c 水稻/n 占优势/v 的/u 差异/n 。/w [安徽省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX 地貌/n 以/p 平原/n 、/w 丘陵/n 和/c 低/a 山/n 为主/v 。/w 平原/n 面积/n 占/v 全省/n 总面积/n 的/u 31/m ./w 3/m ％/w （/w 包括/v 5/m ./w 8/m ％/w 的/u 圩/n 区/n ）/w ，/w 丘陵/n 占/v 29/m ./w 5/m ％/w ，/w 山区/n 占/v 31/m ./w 2/m ％/w ，/w 湖沼/n 洼地/n 占/v 8/m ./w 0/m ％/w 。/w 平原/n 与/c 丘陵/n 、/w 低/a 山/n 相间/v 排列/v 。/w 自然地理/n 区/n 在/p [中国/ns]DLST-RWDLST-XZQY-GJ 综合/v 自然/a 区划/n 中/nd ，/w 全省/n 分/v 属于/v 4/m 个/q 自然地理/n 区/n 。/w [华北平原/ns]DLST-ZRDLST-LDDX-QL 半/m 旱/a 生/v 落叶/n 阔叶林/n 区/n 省境/n [淮河/ns]DLST-ZRDLST-SX-HL 以北/nd 及/c [淮河/ns]DLST-ZRDLST-SX-HL 南岸/nl 河/n 漫/v 滩地/n 带/v 的/u 皖/j [北平/ns]DLST-RWDLST-XZQY-YJXZQY-YJXZQYCSX 原/a ，/w 属/v 此/r 区/n 的/u 淮北/ns 平原/n 亚/a 区/n ，/w 地势/n 坦荡/a 辽阔/a ，/w 为/vl [华北平原/ns]DLST-ZRDLST-LDDX-QL 的/u 南部/nd 。/w 海拔/n 多/a 在/p 20/m ～/w 50/m 米/q ，/w 自/p 西北/nd 向/p 东南/nd 微倾/v 。/w [淮河/ns]DLST-ZRDLST-SX-HL 北侧/nd 的/u 支流/n 向/p 东南/nd 流入/v [淮河/ns]DLST-ZRDLST-SX-HL 和/c 洪/nhf 泽/n 湖/n 。/w 平原/n 北部/nd 深受/v [黄河/ns]DLST-ZRDLST-SX-HL 泛滥/v 影响/v ，/w 近代/nt 沉积物/n 覆盖/v 深厚/a 。/w 在/p 排水/v 不畅/a 的/u 低洼/a 和/c 微/a 凹/a 地区/n 有/v 盐碱/n 土/n 和/c 砂/n 姜/nhf 土/n 分布/v 。/w 农垦/n 历史/n 悠久/a ，/w 自然/a 植被/n 多/a 已/d 无存/v ，/w 现/v 为/vl 人工/n 栽培/v 的/u 侧柏/n 、/w 杨/nhf 、/w 柳/n 、/w 泡桐/n 、/w 刺槐/n 、/w 榆/x 等/u 。/w 20/m 世纪/nt 50/m 年代/nt 以来/nt ，/w 结合/v 治淮/v ，/w 兴建/v 了/u 多项/mq 综合利用/v 水利工程/n ，/w 并/c 开辟/v 了/u 新/a [汴河/ns]DLST-ZRDLST-SX-HL 、/w 茨/n 淮/x 新/a 河/n 等/u ，/w 在/p 防洪/v 、/w 灌溉/v 、/w 航运/v 等/u 方面/n 发挥/v 了/u 显著/a 作用/n 。/w 北/nd 亚热带/nl [长江/ns]DLST-ZRDLST-SX-HL 中下游/n 平原/n 混交/v 林区/n 省境/n [淮河/ns]DLST-ZRDLST-SX-HL 南岸/nl 河/n 漫/v 滩地/n 带/v 以南/nd 的/u 皖/j 中/nd 丘陵/n 及/c [长江/ns]DLST-ZRDLST-SX-HL 沿江/n 平原/n 属/v 此/r 区/n 的/u [长江/ns]DLST-ZRDLST-SX-HL 下游/n 平原/n 丘陵/n 亚/a 区/n 。/w 由/p 河谷/n 平原/n 、/w 湖/n 盆/n 平原/n （/w [巢湖/ns]DLST-ZRDLST-SX-HB 盆地/n 最大/a ）/w 以及/c 与/c 这些/r 平原/n 相/d 毗连/v 的/u 低/a 山/n 、/w 丘陵/n 、/w 岗/n 地/u 等/u 多种/mq 地貌/n 类型/n 组成/v 。/w 平原/n 地区/n 农业/n 发达/a 。/w 丘陵/n 地势/n 起伏/v ，/w 大部/n 已/d 垦/v 为/vl 农田/n ，/w 其中/nd 西部/nd 的/u 淠/x 史/n 杭/ns 灌溉/v 区/n 水源/n 较/d 丰/a ，/w 东部/nd 则/c 水源/n 缺乏/v ，/w 旱灾/n 突出/a 。/w 年均/j 温/a 14/m ～/w 16/m ℃/w ，/w 1/m 月均/v 温/a －/w 0/m ./w 0/m ～/w 4/m ℃/w ，/w 7/m 月/nt 27/m ～/w 29/m ℃/w ，/w 10/m ℃/w 以上/nd 活动/v 积/v 温/a 为/vl 4620/m ～/w 5300/m ℃/w 。/w 当/p 强大/a 寒潮/n 过境/v 时/nt ，/w 往往/d 气温/n 骤降/v ，/w 甚至/d 冻/v 害/v 越冬/v 作物/n 。/w 无/v 霜期/nt 约/d 为/vl 200/m ～/w 250/m 天/nt 。/w 年/nt 降水量/n 750/m ～/w 1700/m 毫米/q ，/w 地区/n 分布/v 一般/a 南部/nd 多于/v 北部/nd ，/w 山地/n 多于/v 平原/n 。/w 皖/j 北约/j 750/m ～/w 800/m 毫米/q ，/w 皖/j 中/nd 约/d 800/m ～/w 1000/m 毫米/q ，/w 沿江/n 一带/n 约/d 1100/m ～/w 1400/m 毫米/q ，/w 皖南/ns 约/d 1600/m 毫米/q ，/w [黄山/ns]DLST-ZRDLST-LDDX-QL 光明/n 顶/n 为/vl 2373/m 毫米/q ，/w 是/vl 全省/n 降水量/n 最多/a 之/u 地/u 。/w 由于/c 季风/n 和/c 梅雨/n 的/u 不稳定性/n ，/w 各地/nl 历年/nt 最大/a 和/c 最小/a 降水量/n 可/vu 相差/v 1/m ～/w 3/m 倍/n 以上/nd ，/w 夏季/nt 各/r 月/nt 降水量/n 的/u 逐年/d 变化/v 更/d 大/a ，/w 往往/d 引起/v 旱涝/n 灾害/n 。/w 旱灾/n 在/p 皖/j 北/nd 以/p 春旱/a 或/c 春夏/nt 连/p 旱/a 居多/v ，/w [淮河/ns]DLST-ZRDLST-SX-HL 以南/nd 多/a 为/vl 夏/nt 旱/a 或/c 秋/nt 旱/a 。/w 涝灾/n 则/c 以/p [淮河/ns]DLST-ZRDLST-SX-HL 流域/n 较/d 多/a ，/w 主要/a 出现/v 在/p 7/m ～/w 8/m 月/nt ；/w 次/q 为/vl [长江/ns]DLST-ZRDLST-SX-HL 流域/n ，/w 多出/v 现在/nt 6/m ～/w 7/m 月/nt 。/w [安徽省/ns]DLST-RWDLST-XZQY-EJXZQY-YJXZQYPTX ，/w 简称/n “/w 皖/j ”/w ，/w 为/vl [中国/ns]DLST-RWDLST-XZQY-GJ 内陆/n [中国/ns]DLST-RWDLST-XZQY-GJ 行政区/n ，/w [中国/ns]DLST-RWDLST-XZQY-GJ 地理/n 上/nd 属于/v 华东/nl 地区/n ，/w 经济/n 上/nd 属于/v [中国/ns]DLST-RWDLST-XZQY-GJ 中部/nd 经济区/n ；/w 兼/v 跨/v [长江/ns]DLST-ZRDLST-SX-HL 、/w [淮河/ns]DLST-ZRDLST-SX-HL 。/w 省会/n [合肥市/ns]DLST-RWDLST-XZQY-EJXZQY-EJXZQYCSX ，/w 清朝/nt 后期/nt 和/c 中华民国/n [安庆/ns]DLST-RWDLST-XZQY-EJXZQY-EJXZQYCSX 市/n 曾/d 为/vl 省会/n 。/w ");
		System.out.println(ll.size());
		try {
			vm.saveVectorsToFileFromVectorsMapList(ll, "c:\\vectors.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 注意：自动按句子级别处理
	 * @param 分词后的原始语料
	 * @return 生成的向量链表
	 * @throws IOException 
	 */
	public void saveVectorsToFileFromVectorsMapList(LinkedList<HashMap>	ll,String filePath) throws IOException
	{
		String _strToWrite = "";
		
		for(int i=0; i< ll.size(); i++)
		{
			String _sentenceAttrStr="";
			boolean _hasCategory = false;
			HashMap _hm = ll.get(i);
			Iterator iter = _hm.entrySet().iterator();
			while (iter.hasNext()) {
			    
				Entry entry = (Entry) iter.next();
			    String key = (String) entry.getKey();
			    String val = (String) entry.getValue();
			    
			    if(key.equals("categories"))
			    	{_hasCategory=true;continue;}
			    
			    _sentenceAttrStr+=key+"="+val+" ";
			} 
			String _cate = "";
			if(_hasCategory)
			{
				String _cateTmp =(String) _hm.get("categories");
				String _categories[]=_cateTmp.trim().split(" ");
				//_cate = _categories[0];
				for(int j=0;j<_categories.length;j++)
				{
					_cate += (_cate.length()>1?"-":"") + _categories[j];
					_strToWrite += _sentenceAttrStr + _cate + "\n";
				}
			}
			else
			{
				_strToWrite += _sentenceAttrStr + "\n";
			}
		}
		
		FileWriter out=new FileWriter(filePath);
		out.write(_strToWrite);
		out.close();
	}
	/**
	 * 注意：自动按句子级别处理
	 * @param 分词后的原始语料
	 * @return 生成的向量链表
	 */
	public LinkedList<HashMap> getVectorsListFromAnalyzedText(String rawText)
	{
		//结果返回向量集链表
		LinkedList<HashMap>	_result;
		//空格split后结果
		String[] _splitedShorts;
		//一个句子blocks的链表
		LinkedList<String> _setenceBlocks;
		int _blockIndex;
		
		_result = new LinkedList<HashMap>();
		_splitedShorts = rawText.split(" ");
		_blockIndex = 0;
		
		while(_blockIndex<_splitedShorts.length)
		{
			_setenceBlocks = new LinkedList<String>();
			//用来记录“[]”配对情况
			int _symbolCounter=0;
			for ( ; _blockIndex<_splitedShorts.length; _blockIndex++ )
			{
				//当前处理的字符串
				String 	_currentString;
				_currentString = _splitedShorts[_blockIndex];
				
				//当前处理字符串的ASB类型
				AnalyzedSentenceBlock asb=new AnalyzedSentenceBlock(_currentString);
				
				//当发现表示橘子结束的标点
				if(SENTENCE_END_SYMBOLS.indexOf(asb.getPureTerm()) != -1)
					{_setenceBlocks.add(_currentString);_blockIndex++;break;}
				
				//将block加入到待处理句子block集合
				_setenceBlocks.add(_currentString);
			}
			
			if(_setenceBlocks.size() > 0)
				_result.addAll(getVectorMapFromSentence( _setenceBlocks ));
		}
		
		return _result;
	}
	/**
	 * 从句子中提出那一坨向量
	 */
	private LinkedList<HashMap> getVectorMapFromSentence(LinkedList<String> rawSentence) 
	{
		//用来存储句子对应的asb
		LinkedList<AnalyzedSentenceBlock> _asbList=new LinkedList<AnalyzedSentenceBlock>();
		LinkedList<HashMap> _result = new LinkedList<HashMap>();
		Iterator<String> _iterator = rawSentence.iterator();
		
		//System.out.println(rawSentence.toString());
		
		//转化为ASB类型
		while(_iterator.hasNext())
		{
			String _currentBlock = _iterator.next();
			_asbList.add(new AnalyzedSentenceBlock(_currentBlock));
		}
		
		//对每个asb进行处理，生成对应向量
		for(int i=0;i< _asbList.size();i++)
		{
			AnalyzedSentenceBlock asb = _asbList.get(i);
			HashMap _hm = new HashMap();
			
			if(asb.getCategories().size() == 0)
				continue;
			
			//如果放置不成功（因为当前block的内容为符号）
			if(putSingleTermFeatureToMap(_hm, asb, true, "word", "pos") == 1)
				continue;
			
			int offset=-1,count=1;
			while( i+offset>=0 && count<=2)
			{
				AnalyzedSentenceBlock _currentASB = _asbList.get(i+offset);
				if(putSingleTermFeatureToMap(_hm, _currentASB, false, "pWord"+count, "pPos"+count) == 0)
					count++;
				
				offset--;
			}
			
			offset=1;count=1;
			while( i+offset < _asbList.size() && count<=2)
			{
				AnalyzedSentenceBlock _currentASB = _asbList.get(i+offset);
				if(putSingleTermFeatureToMap(_hm, _currentASB, false, "aWord"+count, "aPos"+count) == 0)
					count++;
				
				offset++;
			}
			
			if(_hm.size()>0)
				_result.add(_hm);
		}
		
		return _result;
	}
	private int putSingleTermFeatureToMap(HashMap hm,AnalyzedSentenceBlock asb,boolean isPutClass,String wordAttrStr,String posAttrStr)
	{
		//忽略傅浩
		if(SYMBOLS.indexOf(asb.getPureTerm()) != -1)
				return 1;
		
		//先写入词的“内容”和“标注属性”
		hm.put(wordAttrStr, asb.getPureTerm());
		hm.put(posAttrStr,asb.getTermAttribute());
		
		//明确将categories写入向量文件时
		if(isPutClass)
		{
			LinkedList<String> _categories = asb.getCategories();
			String _categoriesStr = "";
			if(_categories.size()>0)
			{
				Iterator<String> _itr = _categories.iterator();
				while(_itr.hasNext())
				{
					_categoriesStr += _itr.next()+" ";
				}
			}
			if(_categoriesStr.length()>0)
			{
				_categoriesStr = _categoriesStr.substring(0, _categoriesStr.length()-1);
				hm.put("categories", _categoriesStr);
			}
		}
		return 0;
	}
}
