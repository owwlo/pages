package ee.maxent;

import opennlp.maxent.*;
import opennlp.maxent.io.*;
import java.io.*;

public class Predict {
	MaxentModel _model;
	ContextGenerator _cg = new BasicContextGenerator();

	public Predict(MaxentModel m) {
		_model = m;
	}

	private void eval(String predicates) {
		eval(predicates, false);
	}

	private void eval(String predicates, boolean real) {
		String[] contexts = predicates.split(" ");
		double[] ocs;
		if (!real) {
			ocs = _model.eval(contexts);
		} else {
			float[] values = RealValueFileEventStream.parseContexts(contexts);
			ocs = _model.eval(contexts, values);
		}
		System.out.println("For context: " + predicates + "\n"
				+ _model.getAllOutcomes(ocs) + "\n");

	}

	private static void usage() {

	}

	/**
	 * Main method. Call as follows:
	 * <p>
	 * java Predict dataFile (modelFile)
	 */
	public static void predict(String arg) {

		String args[] = arg.split(" ");

		String dataFileName, modelFileName;

		dataFileName = args[0];
		modelFileName = args[1];

		Predict predictor = null;
		try {
			GISModel m = new SuffixSensitiveGISModelReader(new File(
					modelFileName)).getModel();
			predictor = new Predict(m);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

		try {
			DataStream ds = new PlainTextByLineDataStream(new FileReader(
					new File(dataFileName)));

			while (ds.hasNext()) {
				String s = (String) ds.nextToken();
				predictor.eval(s.substring(0, s.lastIndexOf(' ')), false);
			}
			return;
		} catch (Exception e) {
			System.out.println("Unable to read from specified file: "
					+ modelFileName);
			System.out.println();
			e.printStackTrace();
		}
	}

}
