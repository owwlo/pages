package ee.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;

import javax.sql.rowset.Predicate;

import ee.maxent.CreateModel;
import ee.maxent.Predict;
import ee.maxent.io.VectorMaker;

public class MaxentTest {

	public static void main(String[] args) {

		try {
			VectorMaker vm = new VectorMaker();

			FileReader fr = new FileReader("c:\\textSource.txt");

			String text = "";

			BufferedReader br = new BufferedReader(fr);
			String s1 = null;
			while ((s1 = br.readLine()) != null) {
				text += s1;
			}
			br.close();
			fr.close();

			LinkedList<HashMap> ll = vm.getVectorsListFromAnalyzedText(text);

			try {
				vm.saveVectorsToFileFromVectorsMapList(ll, "c:\\vectors.txt");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			CreateModel.create("c:\\vectors.txt");
			Predict.predict("c:\\test.txt c:\\vectorsModel.txt");

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
