package ee.rule;

public class RuleExtractionA {

	
	public static void main(String[] args) {
		

	}

}
