package imManager;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import layerManager.LayerItem;

import coDraft.CoDraft;

import com.CdButton;

import connectionManager.TransObj;

public class ImPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton sndButton;
	private JTextField tfMsg;
	// private JScrollPane pane;
	private JTextPane list;
	private String sm;
	private JScrollPane Scpane;
	private CdButton btnSend=new CdButton(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Comment-Add.png",0.6, true)));
	private CoDraft coDraft;
	
	public ImPanel(CoDraft _codraft) {
		coDraft=_codraft;
		tfMsg = new JTextField();
		// pane = new JScrollPane(area);
		list = new JTextPane();
		sndButton = new JButton("send");
		Scpane = new JScrollPane(list);

		setOpaque(false);
		setSize(150, 350);
		setLayout(null);
		list.setEditable(false);
		Scpane.setOpaque(true);
		Scpane.setBackground(new Color(150,150,150));
		tfMsg.setOpaque(false);
		//tfMsg.setBackground(new Color(200,200,200));
		// list.setLineWrap(true);
		// list.setWrapStyleWord(true);
		list.setOpaque(false);
		//sndButton.setBounds(80, 130, 70, 20);
		tfMsg.setBounds(5, 285, 115, 20);
		Scpane.setBounds(0, 0, 150, 280);
		// list.setLineWrap(true);
		btnSend.setLocation(108,268);
		
		add(btnSend);
		add(tfMsg);
		add(Scpane);

		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPress();
			}
		});
		tfMsg.addKeyListener(new sendBtnKeyPress());
	}

	// Unaccomplished function 'sndMsg(string)'
	public void sendMsg(String tfmm) {
		SendToOthers(TransObj.InstantMessage,tfmm,com.OwnerID.getUserName());
	};

	public void getMsg(String username,String message) {
		list.setText(list.getText() +username+ " : " + message + "\r\n");
	}
	public void SendToOthers(int type,String command,String userName)
    {
    	if(coDraft._layerManager._fatherCoDraft._serverManager!=null)
    		coDraft._layerManager._fatherCoDraft._serverManager.sendData(new TransObj(com.OwnerID.getOwnerID(),type,command,null,userName));
		if(coDraft._layerManager._fatherCoDraft._clientManager!=null)
			coDraft._layerManager._fatherCoDraft._clientManager.sendData(new TransObj(com.OwnerID.getOwnerID(),type,command,null,userName));
    }
	private void btnPress()
	{
		sm = tfMsg.getText();
		if (sm.length() != 0) {
			sendMsg(sm);
			list.setText(list.getText() + com.OwnerID.getUserName() + " : " +sm + "\r\n");
			tfMsg.setText("");
		} 
	}
	class sendBtnKeyPress extends KeyAdapter
	{

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			if(e.getKeyCode() == KeyEvent.VK_ENTER)
			{
				btnPress();
			}
		}
		
	}
}
