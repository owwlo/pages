package connectionManager;

import layerManager.LayerItem;

public class ConnectInfoTrans extends LayerItem
{
	private String _ownerID;
	private String _ownerUserName;
	private String _IP;
	
	public String get_IP() {
		return _IP;
	}
	public void set_IP(String ip) {
		_IP = ip;
	}
	public ConnectInfoTrans( String ownerUserName,String ownerID) {
		super(com.OwnerID.getOwnerID());
		_ownerID = ownerID;
		_ownerUserName = ownerUserName;
	}
	public String get_ownerID() {
		return _ownerID;
	}
	public void set_ownerID(String ownerID) {
		_ownerID = ownerID;
	}
	public String get_ownerUserName() {
		return _ownerUserName;
	}
	public void set_ownerUserName(String ownerUserName) {
		_ownerUserName = ownerUserName;
	}
	
}
