package connectionManager;

import java.io.Serializable;
import java.util.ArrayList;

import layerManager.LayerItem;

public class TransObj implements Serializable
{
	private static final long serialVersionUID = 1123123L;
	
	public static final int DrawPic = 0;
    public static final int TextBox = 1;
    public static final int ImageBox = 2;
    public static final int FileBox = 3;
    public static final int CdCommand = 4;
    public static final int MapBox = 5;
    public static final int ConnectInfoTrans=6;
    public static final int ConnectedUsersSet=7;
    public static final int InstantMessage=8;
	
	public int Type;
	public String Command;
	public ArrayList<LayerItem> container=new ArrayList<LayerItem>();
	public String IP;
	private String userName;
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	private String _ownerID;
	
	public String get_ownerID() {
		return _ownerID;
	}

	public void set_ownerID(String ownerID) {
		_ownerID = ownerID;
	}
	public TransObj(String ownerID,int type,String command,LayerItem layeritem)
	{
		set_ownerID(ownerID);
		Type=type;
		Command=command;
		container.add(layeritem);
	}
	public TransObj(String ownerID,int type,String command,LayerItem layeritem,String name)
	{
		this(ownerID,type,command,layeritem);
		setUserName(name);
	}
}
