package connectionManager;

import infoManager.ConnectionStatePanel;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import coDraft.CoDraft;


public class ConnectionManagerSE {
	
	public static class ServerManager
	{
		ServerSocket serverSocket;
		int clientCount;
		boolean isListening;
		Vector<Socket> vector=new Vector<Socket>();
		String _otherID[]=new String[100];
		CoDraft fatherCoDraft;
		ConnectionStatePanel _connectionStatePanel;
		
		public ServerManager(CoDraft ifather,ConnectionStatePanel _connectionStatePanel)
		{
			for(int i=0;i<100;i++)
				_otherID[i]="";
			fatherCoDraft=ifather;
			serverSocket=null;
			clientCount=0;
			isListening=true;
			this._connectionStatePanel=_connectionStatePanel;
		}
		public void startServer()
		{
			(new WaitForConnectionThread(serverSocket)).start();
			(new WaitForIdentifyingThread()).start();
			
		}
		class WaitForConnectionThread extends Thread
		{
			ServerSocket serverSocket;
			public WaitForConnectionThread(ServerSocket aaa)
			{
				serverSocket=aaa;
			}
			public void run()
			{
				try
				{
					try
					{
						serverSocket=new ServerSocket(26942);
					}catch(Exception e)
					{
						System.out.println(e);
					}
					while(isListening)
					{
						System.out.println("server");
						_connectionStatePanel.setLED("green");
						Socket socket=serverSocket.accept();
						vector.addElement(socket);
						Thread clientConnectAction=new ReadThread(socket,fatherCoDraft,clientCount);
						clientConnectAction.start();
						clientCount++;
						_connectionStatePanel.setNumOfClient(clientCount);
						sendData(new TransObj(com.OwnerID.getOwnerID(),TransObj.ConnectInfoTrans, "", new ConnectInfoTrans(com.OwnerID.getUserName(), com.OwnerID.getOwnerID())));
					}
					serverSocket.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
		class WaitForIdentifyingThread extends Thread
		{
			ServerSocket identifySocket;
			public WaitForIdentifyingThread()
			{
				
			}
			public void run()
			{
				try
				{
					try
					{
						identifySocket=new ServerSocket(28269);
					}catch(Exception e)
					{
						System.out.println(e);
					}
					while(isListening)
					{
						Socket socket=identifySocket.accept();
						try
						{
							PrintWriter os=new PrintWriter(socket.getOutputStream());
							os.println("I'm a lovely server.");
							os.flush();
							os.close();
						}catch(Exception e)
							{
								System.out.println(e);
							}
					}
					serverSocket.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
		class ReadThread extends Thread
		{
			private Socket socket=null;
			CoDraft fatherCoDraft;
			ObjectInputStream s;
			int thisIndex;
			
			public ReadThread(Socket _socket,CoDraft ifather,int _thisIndex)
			{
				this.socket=_socket;
				fatherCoDraft=ifather;
				thisIndex=_thisIndex;
			}
			public void run()
			{
				try
				{
					//String inLine="";
					//BufferedReader is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
					//inLine=is.readLine();
					//while(inLine!=null && !inLine.equals("THE_END"))
					//{
					//	System.out.println("server receive:"+inLine);
					//	fatherCoDraft.processGetedData(inLine);
					//	//(new ServerSendThread(inLine)).start();
					//	inLine=is.readLine();
					//}
					//is.close();
					//socket.close();
					
					s = new ObjectInputStream(socket.getInputStream());
					boolean flag=true;
					while(flag)
					{
						Object o=s.readObject();
						if(o!=null)
						{
							TransObj oo=(TransObj)o;
							oo.IP=socket.getInetAddress().toString();
							//System.out.println(oo.IP);
							fatherCoDraft.transObjDealer.DealIt(oo,_otherID[thisIndex]);
							//System.out.println(_otherID[0]);
						}
						s=new ObjectInputStream(socket.getInputStream());
					}
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
		public void sendData(String strTal)
		{
			Vector<PrintWriter> oosVector=null;
			oosVector=new Vector<PrintWriter>();
			
			try
			{
				if(vector!=null)
				{
					oosVector.clear();
					for(int i=0;i<vector.size();i++)
					{
						try
						{
							Socket s=vector.elementAt(i);
							PrintWriter os=new PrintWriter(s.getOutputStream());
							oosVector.addElement(os);
						}catch(Exception e)
						{
							System.out.println(e);
						}
					}
					for(int i=0;i<oosVector.size();i++)
					{
						PrintWriter oos=oosVector.elementAt(i);
						oos.println(strTal);
						oos.flush();
					}
				}
			}catch(Exception e)
				{
					System.out.println(e);
				}
		}
		public void sendData(TransObj myObject)
		{
			Vector<ObjectOutputStream> oosVector=null;
			oosVector=new Vector<ObjectOutputStream>();
			
			try
			{
				if(vector!=null)
				{
					oosVector.clear();
					for(int i=0;i<vector.size();i++)
					{
						if(_otherID[i].equalsIgnoreCase(myObject.get_ownerID()))
							continue;
						try
						{
							Socket s=vector.elementAt(i);
							ObjectOutputStream  os=new ObjectOutputStream (s.getOutputStream());
							oosVector.addElement(os);
						}catch(Exception e)
						{
							System.out.println(e);
						}
					}
					for(int i=0;i<oosVector.size();i++)
					{
						ObjectOutputStream  oos=oosVector.elementAt(i);
						oos.writeObject(myObject);
						oos.flush();
						
						//ObjectOutputStream oos = new ObjectOutputStream(new ZipOutputStream(new FileOutputStream(outputFile)));
						//oos.writeObject(obj);
						//oos.close();
					}
				}
			}catch(Exception e)
				{
					System.out.println(e);
				}
		}
		public String getIpAddress()
		{
			
			return null;
		}
	}
	
	public static class ClientManager
	{
		private Socket socket;
		private String ipAddress;
		CoDraft fatherCoDraft;
		ConnectionStatePanel _connectionStatePanel;
		String _otherID="";
		
		public ClientManager(CoDraft ifather,ConnectionStatePanel _connectionStatePanel)
		{
			fatherCoDraft=ifather;
			this._connectionStatePanel=_connectionStatePanel;
		}
		public void setServerIpAddress(String ip)
		{
			ipAddress=ip;
		}
		public void sendData(String s_data)
		{
			try
			{
				PrintWriter os=new PrintWriter(socket.getOutputStream());
				os.println(s_data);
				os.flush();
			}catch(Exception e)
				{
					System.out.println(e);
				}
		}
		public void sendData(TransObj myObject)
		{
			try
			{
				ObjectOutputStream  os=new ObjectOutputStream (socket.getOutputStream());
				os.writeObject(myObject);
				os.flush();
			}catch(Exception e)
				{
					System.out.println(e);
				}
		}
		public void start()
		{
			try {
				socket = new Socket(ipAddress,26942);
				Thread clientConnectAction=new ReadThread(socket,fatherCoDraft);
				clientConnectAction.start();
				_connectionStatePanel.setState(ipAddress);
				sendData(new TransObj(com.OwnerID.getOwnerID(),TransObj.ConnectInfoTrans, "", new ConnectInfoTrans(com.OwnerID.getUserName(), com.OwnerID.getOwnerID())));
				_connectionStatePanel.setLED("green");
				//sendData("send success");
				
			}catch (Exception e){
				return;
			}
		}

		class ReadThread extends Thread
		{
			private Socket socket=null;
			CoDraft fatherCoDraft;
			ObjectInputStream s;
			
			public ReadThread(Socket _socket,CoDraft ifather)
			{
				this.socket=_socket;
				fatherCoDraft=ifather;
			}
			public void run()
			{
				try
				{
					s = new ObjectInputStream(socket.getInputStream());
					boolean flag=true;
					while(flag)
					{
						Object o=s.readObject();
						if(o!=null)
						{
							TransObj oo=(TransObj)o;
							oo.IP=socket.getInetAddress().toString();
							if(!oo.get_ownerID().equalsIgnoreCase(com.OwnerID.getOwnerID()))
								fatherCoDraft.transObjDealer.DealIt(oo,_otherID);
						}
						s=new ObjectInputStream(socket.getInputStream());
					}
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
	}
}
