package connectionManager;

import coDraft.CoDraft;

public class TransObjDealer {

	private CoDraft coDraftFather;
	
	public TransObjDealer(CoDraft ifather)
	{
		coDraftFather=ifather;
	}
	public void DealIt(TransObj obj,String otherID)
	{
		//System.out.println(obj.Type);
		boolean isSendToOther=true;
		
		switch(obj.Type)
		{
			case TransObj.DrawPic:
				coDraftFather.processGetedData(obj);
				break;
			case TransObj.FileBox:
				
				break;
			case TransObj.ImageBox:
				coDraftFather.processGetedData(obj);
				break;
			case TransObj.TextBox:
				coDraftFather.processGetedData(obj);
				break;
			case TransObj.CdCommand:
				
				break;
			case TransObj.MapBox:
				coDraftFather.processGetedData(obj);
				break;
			case TransObj.ConnectInfoTrans:
				ConnectInfoTrans oobj=(ConnectInfoTrans)obj.container.get(0);
				oobj.set_IP(obj.IP);
				System.out.println("receive contact");
				otherID=oobj.get_ownerID();
				coDraftFather.addConnectInfo(oobj);
				break;
			case TransObj.InstantMessage:
				coDraftFather.processIMData(obj.getUserName(),obj.Command);
				break;
		}
		
		if(coDraftFather._serverManager!=null && isSendToOther)
		{
			coDraftFather._serverManager.sendData(obj);
		}
	}
}
