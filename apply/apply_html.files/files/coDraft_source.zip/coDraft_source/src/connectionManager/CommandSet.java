package connectionManager;

public class CommandSet
{
	public static final int SEND_ME_USERS_LIST = 0;
	
}
