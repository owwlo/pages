package connectionManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Queue;
import java.util.Vector;
import java.util.zip.GZIPInputStream;

import com.ServerSelector;

import coDraft.CoDraft;

public class ServerIdentifier 
{
	private String iIP;
	private boolean runningFlag=false;
	private ServerSelector ss;
	
	public ServerIdentifier(ServerSelector _ss) throws UnknownHostException
	{
		ss=_ss;
		InetAddress inet = InetAddress.getLocalHost();
		iIP=inet.getHostAddress();
	}
	public void startIdentify()
	{
		runningFlag=true;
		(new managerThread()).start();
	}
	public void stopIdentify()
	{
		runningFlag=false;
	}
	private void addServerToList(String iiip)
	{
		System.out.println("Get one!");
		ss.addServer(iiip);
	}
	class managerThread extends Thread
	{
		private String subIP;
		private Vector<onceTry> iQueue=new Vector<onceTry>();
		
		public managerThread()
		{
			subIP=iIP.substring(0, iIP.lastIndexOf("."))+".";
			System.out.println(subIP);
		}
		public void run()
		{
			int i=1;
			while(runningFlag)
			{
				if(i==255) i=1;
				if(iQueue.size()<10)
				{
					onceTry t=new onceTry(subIP+String.valueOf(i));
					t.start();
					System.out.println("add try:"+subIP+String.valueOf(i));
					iQueue.addElement(t);
					i++;
				}
				else
				{
					onceTry tt=iQueue.get(0);
					iQueue.remove(0);
					tt.stopTry();
					onceTry t=new onceTry(subIP+String.valueOf(i));
					t.start();
					System.out.println("add try:"+subIP+String.valueOf(i));
					iQueue.addElement(t);
					i++;
				}
				try {
					sleep(25);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	class onceTry extends Thread
	{
		private String iIP;
		private ReadThread rr;
		
		public onceTry(String _ip)
		{
			iIP=_ip;
		}
		public void run()
		{
			Socket socket;
			try {
				socket = new Socket(iIP,28269);
			rr=new ReadThread(socket);
			rr.start();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		public void stopTry()
		{
			try
			{
				rr.flag=false;
			}catch(Exception e)
			{
				
			}
		}
		class ReadThread extends Thread
		{
			private Socket socket=null;
			ObjectInputStream s;
			public boolean flag=true;
			
			public ReadThread(Socket _socket)
			{
				this.socket=_socket;
			}
			public void run()
			{
				try
				{
					//s = new ObjectInputStream(socket.getInputStream());
					BufferedReader is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
					String readLine="";
					while(flag)
					{
						//Object o=s.readObject();
						readLine=is.readLine();
						if(readLine!=null)
						{
							//String oo=(String)o;
							if(readLine.equalsIgnoreCase("I'm a lovely server."))
								addServerToList(socket.getInetAddress().toString().substring(1));
						}
						//s=new ObjectInputStream(socket.getInputStream());
						readLine=is.readLine();
					}
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
	}
}
