package coDraft;

import hysun.draw.DrawingBoard;
import infoManager.InfoManager;
import javax.swing.*;
import com.AppServerOrClientSE;
import com.CdButton;
import connectionManager.ConnectInfoTrans;
import connectionManager.TransObj;
import connectionManager.TransObjDealer;
import connectionManager.ConnectionManagerSE.ClientManager;
import connectionManager.ConnectionManagerSE.ServerManager;
import dialogManager.DialogManager;
import dr.File.FileDrop;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import layerManager.ImageBox;
import layerManager.LayerItem;
import layerManager.LayerManager;

public class CoDraft{
	
	final int DefaultAppWidth=1152;
	final int DefaultAppHeight=720;
	
	private JLabel backImage;
	public JFrame iFather;
	private Dimension screenSolution;
	public double iGlobalScale;
	public LayerManager _layerManager;
	public InfoManager _infoManager;
	public ServerManager _serverManager;
	public ClientManager _clientManager;
	//private JButton connectBtn;
	//private CdButton connectBtn;
	private AppServerOrClientSE connectMode;
	private CoDraft me=this;
	public TransObjDealer transObjDealer=new TransObjDealer(this);
	private DialogManager _dialogManager;
	//private MapBox owwlo=new MapBox("owwlo",0,0,0, 0,600,400);
	
	public CoDraft(JFrame _father,Dimension _screenSolution)
	{
		iFather=_father;
		screenSolution=_screenSolution;
		JLayeredPane layeredPane=iFather.getLayeredPane();
		layeredPane.setLayout(null);
		
		iGlobalScale=getGlobalScale(screenSolution);
		com.GlobalScale.setGlobalScale(iGlobalScale);
		
		iFather.setSize((int)(DefaultAppWidth*iGlobalScale),(int)( DefaultAppHeight*iGlobalScale));
		layeredPane.setSize((int)(DefaultAppWidth*iGlobalScale),(int)( DefaultAppHeight*iGlobalScale));
		
		ImageIcon bg=new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("bg.jpg", iGlobalScale/2));
		backImage=new JLabel(bg);
		backImage.setBounds(0, 0, iFather.getWidth(), iFather.getHeight());
		
		_layerManager=new LayerManager(this);
		_layerManager.setBounds(0,0,iFather.getWidth(), iFather.getHeight());
		
		_infoManager=new InfoManager(this);
		_infoManager.setBounds(40, 32,1073, 637);
		
		//connectBtn=new JButton("connect");
		//connectBtn.setOpaque(false);
		//connectBtn.setBounds(300, 46, 80, 20);
		//connectBtn=new CdButton(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("conn.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/5.1,true)));
		//connectBtn.setLocation(1065,28);
		
		
		//ButtonListener bl=new ButtonListener();
		//connectBtn.addActionListener(bl);
		
		new FileDrop( null,backImage, /*dragBorder,*/ new FileDrop.Listener()
        {   public void filesDropped( java.io.File[] files )
            {
        			for( int i = 0; i < files.length; i++ )
        			{   try
        				{
        					dealDrop(files[i].getCanonicalPath());
        				}
        				catch( java.io.IOException e ) {}
        			}
            }
        });
		
		//_layerManager.add(owwlo);
		iFather.setFocusable(true);
		iFather.addKeyListener(new KeyListener());
		
		try {
			_dialogManager=new DialogManager(this);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		layeredPane.add(_dialogManager,500);
		//layeredPane.add(connectBtn,400);
		layeredPane.add(_infoManager,300);
		layeredPane.add(_layerManager, 200);
		layeredPane.add(backImage,100);
		
	}
	private double getGlobalScale(Dimension _screenSolution)
	{
		double presentSolutionRatio=_screenSolution.getWidth()/_screenSolution.getHeight();
		if(presentSolutionRatio>1.6)      //represent the solution of 1280x800
		{
			return _screenSolution.getHeight()*0.9/DefaultAppHeight;
		}
		else
		{
			return _screenSolution.getWidth()*0.9/DefaultAppWidth;
		}
	}
	public void processGetedData(String in_data)
	{
		
	}
	public void processGetedData(TransObj aaa)
	{
		_layerManager.addLayer((aaa.container.get(0)));
		//System.out.println(aaa.container.get(0).ownerID);
	}
	public void processIMData(String username,String message)
	{
		_infoManager.processIMData(username,message);
	}
	private class ButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			connectMode=new AppServerOrClientSE(iFather,"Connection Mode",com.OwnerID.getUserName(), _infoManager._connectionStatePanel.getState(),_infoManager._connectionStatePanel.getIP());
			if(connectMode.isYes)
			{
				com.OwnerID.setUserName(connectMode.getUserName());
				com.OwnerID.setOwnerIDFromUserName(connectMode.getUserName());
				_infoManager._mainUser.setUserName(com.OwnerID.getUserName());
				if(connectMode.getInfo()=="offline")
				{
					_infoManager._connectionStatePanel.setState("offline");
				}
				else if(connectMode.getInfo()=="server")
				{
					_serverManager=new ServerManager(me,_infoManager._connectionStatePanel);
					_serverManager.startServer();
					_infoManager._connectionStatePanel.setState("server");
				}
				else
				{
					_clientManager=new ClientManager(me,_infoManager._connectionStatePanel);
					_clientManager.setServerIpAddress(connectMode.getInfo());
					_clientManager.start();
					_infoManager._connectionStatePanel.setState(connectMode.getInfo());
				}
				//System.out.println(com.OwnerID.getOwnerID());
			}
		}
	}
	private void dealDrop(String _path)
	{
		//if(_layerManager.drawBoard.getTool()==DrawingBoard.ImageBox);
		{
			_infoManager._toolPanel.setTool(DrawingBoard.ImageBox+1);
			String path=_path.toLowerCase();
			String extendName;
			int dotIndex=path.lastIndexOf(".");
			if(dotIndex<0)
				return;
			extendName=path.substring(dotIndex+1);
			//System.out.println(extendName);
			if(extendName.equalsIgnoreCase("jpg")||extendName.equalsIgnoreCase("gif")||extendName.equalsIgnoreCase("bmp")||extendName.equalsIgnoreCase("png"))
			{
				ImageIcon iconImg=com.DragImageImporter.fromFile(path,(int)(_layerManager.getWidth()*0.6),(int)(_layerManager.getHeight()*0.6),false);
				//System.out.println(bufImg.getWidth());
				ImageBox imgB=new ImageBox("owwloImg",iconImg,iconImg.getIconWidth(),iconImg.getIconHeight(),MouseInfo.getPointerInfo().getLocation().x-iFather.getLocationOnScreen().x-40,MouseInfo.getPointerInfo().getLocation().y-iFather.getLocationOnScreen().y-70);
				_layerManager.addLayer(imgB);
				_layerManager.drawBoard.SendToOthers(TransObj.ImageBox,"",imgB);
			}
		}
	}
	public void addConnectInfo(ConnectInfoTrans a)
	{
		//_infoManager.addConnectUser(a);
		_infoManager._infoDockPanel.addConnectUser(a);
		//System.out.println(a.get_IP());
	}
	private class KeyListener extends KeyAdapter
	{
		public void keyTyped(KeyEvent e)
		{
			switch(e.getKeyChar())
			{
				case '1':
					_infoManager._toolPanel.setTool(0);
					break;
				case '2':
					_infoManager._toolPanel.setTool(1);
					break;
				case '3':
					_infoManager._toolPanel.setTool(2);
					break;
				case '4':
					_infoManager._toolPanel.setTool(3);
					break;
				case '5':
					_infoManager._toolPanel.setTool(4);
					break;
				default:
					break;
			}
		}
	}
}
