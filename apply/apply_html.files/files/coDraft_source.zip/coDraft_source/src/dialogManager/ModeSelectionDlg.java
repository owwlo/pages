package dialogManager;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.ITween;
import com.RichJLabel;

import connectionManager.ConnectionManagerSE.ClientManager;
import connectionManager.ConnectionManagerSE.ServerManager;

public class ModeSelectionDlg extends JPanel implements ITween{
	
	private RichJLabel titleText=new RichJLabel("Mode Selection",0);
	private JButton btnServer=new JButton("Server");
	private JButton btnClient=new JButton("Client");
	private JButton btnOffline=new JButton("Offline");
	private DialogManager _dialogmgr;
	private ModeSelectionButtonAction btnListener=new ModeSelectionButtonAction();
	private RichJLabel usernameText=new RichJLabel("User : ",0);
	private JTextField userNameTF=new JTextField(System.getProperty("user.name"));
	private JButton colorBtn=new JButton(" ");
	
	public ModeSelectionDlg(DialogManager dialogmgr)
	{
		_dialogmgr=dialogmgr;
		
		this.setSize(600,200);
		this.setOpaque(false);
		
		btnServer.setBackground(new Color(230,230,230));
		btnClient.setBackground(new Color(230,230,230));
		btnOffline.setBackground(new Color(230,230,230));
		
		GridBagLayout gb=new GridBagLayout();
		this.setLayout(gb);
		
		GridBagConstraints gBC = new GridBagConstraints();
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.CENTER;
		gBC.weightx=0.5;
        gBC.gridx = 0;
        gBC.gridy = 0;
        gBC.gridheight=1;
        gBC.gridwidth=3;
        titleText.setShadow(0, -1, new Color(0,0,0,200));
        titleText.setFont(new Font("Segoe UI",1,60));
        titleText.setForeground(new Color(220,220,220));
		this.add(titleText,gBC);
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.EAST;
		gBC.weightx=0.5;
        gBC.gridx =0;
        gBC.gridy = 1;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        btnServer.setFont(new Font("Segoe UI",1,20));
        btnServer.setForeground(new Color(50,50,50));
        btnServer.addActionListener(btnListener);
		this.add(btnServer,gBC);
		
		gBC.fill = GridBagConstraints.BOTH;
		gBC.anchor=GridBagConstraints.CENTER;
		gBC.weightx=0.5;
        gBC.gridx = 1;
        gBC.gridy = 1;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        btnOffline.setFont(new Font("Segoe UI",1,20));
        btnOffline.setForeground(new Color(50,50,50));
        btnOffline.addActionListener(btnListener);
		this.add(btnOffline,gBC);
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.WEST;
		gBC.weightx=0.5;
        gBC.gridx = 2;
        gBC.gridy = 1;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        btnClient.setFont(new Font("Segoe UI",1,20));
        btnClient.setForeground(new Color(50,50,50));
        btnClient.addActionListener(btnListener);
		this.add(btnClient,gBC);
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.EAST;
		gBC.weightx=0.5;
        gBC.gridx = 0;
        gBC.gridy = 2;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        gBC.insets=new Insets(10, 0, 0, 0);
        usernameText.setShadow(0, -1, new Color(0,0,0,200));
        usernameText.setFont(new Font("Segoe UI",1,20));
        usernameText.setForeground(new Color(220,220,220));
		this.add(usernameText,gBC);
		
		gBC.fill = GridBagConstraints.BOTH;
		gBC.anchor=GridBagConstraints.WEST;
		gBC.weightx=0.5;
        gBC.gridx = 1;
        gBC.gridy = 2;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        gBC.insets=new Insets(10, 0, 0, 0);
        //userNameTF.setAutoscrolls(false);
        userNameTF.setFont(new Font("΢���ź�",1,20));
        userNameTF.setForeground(new Color(200,200,200,255));
        //userNameTF.setOpaque(false);
        userNameTF.setBackground(new Color(100,100,100,255));
        userNameTF.setBorder(BorderFactory.createLineBorder(new Color(255,255,255,100),1));
        userNameTF.setHorizontalAlignment(JTextField.CENTER);
        //userNameTF.setSize(200, userNameTF.getHeight());
		this.add(userNameTF,gBC);
		
		com.OwnerID.setUserColor(com.OwnerID.getRandomColor());
		colorBtn.setBackground(com.OwnerID.getUserColor());
        colorBtn.setFocusPainted(false);
        colorBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	colorSelectPress(evt);
            }
        });
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.WEST;
		gBC.weightx=0.5;
        gBC.gridx = 2;
        gBC.gridy = 2;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        gBC.insets=new Insets(10, 10, 0, 0);
		this.add(colorBtn,gBC);
	}
	private class ModeSelectionButtonAction implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			String str=e.getActionCommand();
			if(str.equalsIgnoreCase("server"))
			{
				_dialogmgr.get_coDraft()._serverManager=new ServerManager(_dialogmgr.get_coDraft(),_dialogmgr.get_coDraft()._infoManager._connectionStatePanel);
				_dialogmgr.get_coDraft()._serverManager.startServer();
				_dialogmgr.get_coDraft()._infoManager._connectionStatePanel.setState("server");
				btnServer.setBackground(new Color(100,100,100));
			}
			else if(str.equalsIgnoreCase("offline"))
			{
				_dialogmgr.get_coDraft()._infoManager._connectionStatePanel.setState("offline");
				btnOffline.setBackground(new Color(100,100,100));
			}
			else if(str.equalsIgnoreCase("client"))
			{
				btnClient.setBackground(new Color(100,100,100));
			}
			btnServer.setEnabled(false);
			btnOffline.setEnabled(false);
			btnClient.setEnabled(false);
			userNameTF.setEditable(false);
			userNameTF.setEnabled(false);
			
			com.OwnerID.setUserName(userNameTF.getText());
			com.OwnerID.setOwnerIDFromUserName(userNameTF.getText());
			_dialogmgr.get_coDraft()._infoManager._mainUser.setUserName(userNameTF.getText());

			
				//_dialogmgr.get_coDraft()._clientManager=new ClientManager(_dialogmgr.get_coDraft(),_dialogmgr.get_coDraft()._infoManager._connectionStatePanel);
				//_dialogmgr.get_coDraft()._clientManager.setServerIpAddress(connectMode.getInfo());
				//_dialogmgr.get_coDraft()._clientManager.start();
				//_dialogmgr.get_coDraft()._infoManager._connectionStatePanel.setState(connectMode.getInfo());
			
			
			_dialogmgr.selectedMode(str);
		}
	}
	@Override
	public void finishTweenChange() {
		// TODO Auto-generated method stub
		
	}
	private void colorSelectPress(ActionEvent e)
	{
		java.awt.Color color = javax.swing.JColorChooser.showDialog(this, 
                "Change Drawing Color",com.OwnerID.getUserColor());
		com.OwnerID.setUserColor(color);
		colorBtn.setBackground(color);
	}
}
