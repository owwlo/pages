package dialogManager;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.IAlphaChange;
import com.IAlphaChangeFinish;
import com.ITween;
import com.ServerSelector;

import connectionManager.ServerIdentifier;

import coDraft.CoDraft;

public class DialogManager extends JPanel implements IAlphaChange,ITween,IAlphaChangeFinish{

	private CoDraft _coDraft;
	public CoDraft get_coDraft() {
		return _coDraft;
	}

	private ModeSelectionDlg modeSelectionDlg=new ModeSelectionDlg(this);
	public int _alpha=0;
	private ServerSelector serverSelector;
	
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		((Graphics2D) g).setColor(new Color(0,0,0,_alpha));
		((Graphics2D) g).fillRect(0, 0, this.getWidth(), this.getHeight());
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DialogManager(CoDraft fatherCoDraft) throws InterruptedException
	{
		super();
		_coDraft=fatherCoDraft;
		serverSelector=new ServerSelector(_coDraft,this);
		this.setSize(1152, 720);
		this.setOpaque(false);
		this.setLayout(null);
		
		modeSelectionDlg.setLocation(this.getWidth()/2-modeSelectionDlg.getWidth()/2, this.getHeight()/2-modeSelectionDlg.getHeight()/2-50-400);
		
		this.add(modeSelectionDlg);
		
		serverSelector.setLocation(this.getWidth()/2-serverSelector.getWidth()/2, this.getHeight()/2-serverSelector.getHeight()/2+550);
		this.add(serverSelector);
		
		com.ComponentAlphaChanger.dealIt(this, this, 0.8, 0, 200);
		
		//java.awt.Color color = javax.swing.JColorChooser.showDialog(this, 
          //      "Select your paint color", Color.black);
	}

	@Override
	public void changeAlpha(int a) {
		_alpha=a;
		this.repaint();
	}

	@Override
	public void finishAlphaChange() {
		com.TweenOw.dealIt(modeSelectionDlg,modeSelectionDlg, 1.5, modeSelectionDlg.getX(), modeSelectionDlg.getY()+400);
	}
	
	public void selectedMode(String _mode)
	{
		if(_mode.equals("Server"))
		{
			com.TweenOw.dealIt(modeSelectionDlg,new SorOreact(this), 1, modeSelectionDlg.getX(), modeSelectionDlg.getY()-450);
		}
		else if(_mode.equals("Offline"))
		{
			com.TweenOw.dealIt(modeSelectionDlg,new SorOreact(this), 1, modeSelectionDlg.getX(), modeSelectionDlg.getY()-450);
		}
		else if(_mode.equals("Client"))
		{
			com.TweenOw.dealIt(modeSelectionDlg,this, 1, modeSelectionDlg.getX(), modeSelectionDlg.getY()-200);
			serverSelector.startTry();
		}
	}
	class SorOreact implements ITween
	{
		DialogManager a;
		
		public SorOreact(DialogManager _a)
		{
			a=_a;
		}
		public void finishTweenChange() {
			//com.TweenOw.dealIt(modeSelectionDlg,this, 1.5, modeSelectionDlg.getX(), modeSelectionDlg.getY()-450);
			com.ComponentAlphaChanger.dealIt(a,new EndAlphaChangeFinish(),0.8, 200, 0);
		}
		
	}
	class EndAlphaChangeFinish implements IAlphaChangeFinish
	{

		@Override
		public void finishAlphaChange() {
			// TODO Auto-generated method stub
			
		}
		
	}
	class ClientTweenEndFirst implements ITween
	{
		public void finishTweenChange() {
			
		}
		
	}
	@Override
	public void finishTweenChange() {
		//serverSelector.setLocation(this.getWidth()/2-serverSelector.getWidth()/2, this.getHeight()/2-serverSelector.getHeight()/2+550);
		//this.add(serverSelector);
		com.TweenOw.dealIt(serverSelector,new ClientTweenEndFirst(), 1, serverSelector.getX(), serverSelector.getY()-500);
	}
	public void finishServerSelect()
	{
		com.TweenOw.dealIt(modeSelectionDlg,new ClientTweenEndFirst(), 1, modeSelectionDlg.getX(), modeSelectionDlg.getY()-200);
		com.TweenOw.dealIt(serverSelector,new ClientTweenEndFirst(), 1, serverSelector.getX(), serverSelector.getY()+500);
	}
}
