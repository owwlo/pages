package layerManager;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.io.Serializable;

import javax.swing.JPanel;

public class LayerItem extends JPanel implements ComSprite,Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public String ownerID;
	public int x,y;
	public int width,height;
	
	//public ArrayList<Point> pointList=new ArrayList<Point>();
	//public int left=32767,right=0,up=32767,bottom=0;
	/*
	public LayerItem(String ownerID,ArrayList<PolyLine> shapes) {
		LayerItem(ownerID);
		//this.setBackground(Color.BLACK);
		getWholeLeftRightUpBottom(shapes);
		update();
		//System.out.println(up);
		for(int i=0;i<shapes.size();i++)
		{
			PolyLine aaa=shapes.get(i);
			int bbb[][]=aaa.getPoints();
			for(int j=0;j<bbb[0].length;j++)
			{
				addPoint(new Point(bbb[0][j]-left,bbb[1][j]-up));
			}
		}
	}*/
	
	public LayerItem(String _ownerID)
	{
		ownerID=_ownerID;
	}
	//protected void setPosition(int _x,int _y)
	//{
	//	x=_x;
	//	y=_y;
	//}
	public void setLayerSize(int width,int height)
	{
		this.width=width;
		this.height=height;
		this.setSize(width, height);
		//this.draw();
	}
	public int getLayerWidth()
	{
		return width;
	}
	public int getLayerHeight()
	{
		return height;
	}
	public Point getPosition()
	{
		return (new Point(x,y));
	}
	public int getLayerX()
	{
		return x;
	}
	public int getLayerY()
	{
		return y;
	}
	public String getOwnerID()
	{
		return ownerID;
	}
	@Override
	public void processCursorEvent(MouseEvent evt, int type) {
		// TODO Auto-generated method stub

	}
	/*
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }
	public void draw(Graphics g) 
	{
		Graphics2D g2d = (Graphics2D)g;
		int points[][]=getPoints();
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.drawPolyline(points[0], points[1], points[0].length);
		//this.setPosition(this.getLayerX(), this.getLayerY());
	}
	public int[][] getPoints() {
        int size = pointList.size();
        if (size == 0)
            return null;
        int[][] result = new int[2][size];
        for (int i=0; i<size; i++) {
            Point p = (Point) pointList.get(i);
            result[0][i] = p.x;
            //System.out.println(p.y);
            result[1][i] = p.y;
        }
        return result;
    }
	public void addPoint(Point aaa)
	{
		pointList.add(aaa);
	}
	public void getWholeLeftRightUpBottom(ArrayList<PolyLine> shapes)
	{
		for(int k=0;k<shapes.size();k++)
		{
			if(shapes.get(k).left<left) left=shapes.get(k).left;
			if(shapes.get(k).right>right) right=shapes.get(k).right;
			if(shapes.get(k).up<up) up=shapes.get(k).up;
			if(shapes.get(k).bottom>bottom) bottom=shapes.get(k).bottom;
		}
		up-=20;
		right+=20;
		left-=20;
		bottom+=20;
		
		this.width=right-left;
		this.height=bottom-up;
		this.x=left;
		this.y=up;
	}*/
	
	public void update()
	{
		//this.setLayout(null);
		this.setOpaque(false);
		this.setLayerSize(width, height);
		this.repaint();
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		
	}
}
