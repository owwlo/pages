package layerManager;

import java.util.ArrayList;
import hysun.draw.DrawingBoard;
import javax.swing.*;
import coDraft.CoDraft;

public class LayerManager extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	public CoDraft _fatherCoDraft;
	public JLabel mainPage;
	public DrawingBoard drawBoard=new DrawingBoard(this);
	private ArrayList<LayerItem> itemList=new ArrayList<LayerItem>();
	private JPanel layerContainer=new JPanel();
	//private ToolPanel _toolPanel;
	
	public LayerManager(CoDraft _father)
	{
		_fatherCoDraft=_father;
		
		//_toolPanel=new ToolPanel(this);
		
		this.setLayout(null);
		this.setOpaque(false);
		
		ImageIcon mp=new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("mainPage.png", _fatherCoDraft.iGlobalScale/2));
		mainPage=new JLabel(mp);
		mainPage.setOpaque(false);
		mainPage.setBounds(0,-10, _fatherCoDraft.iFather.getWidth(), _fatherCoDraft.iFather.getHeight());
		
		drawBoard.setBounds(40, 32, 1073, 637);
		
		layerContainer.setBounds(40, 32, 1073, 637);
		layerContainer.setLayout(null);
		layerContainer.setOpaque(false);
		
		//_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Paint.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),0);
		//_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("text.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),1);
		//_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("pic.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),2);
		//_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Word-Processor.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),3);
		//_toolPanel.setTool(1);
		//_toolPanel.setLocation(800, 635);
		
		//this.add(_toolPanel);
		this.add(drawBoard);
		this.add(layerContainer);	
		this.add(mainPage);
	}
	public void addLayer(LayerItem aaa)
	{
		aaa.update();
		aaa.setLocation(aaa.x, aaa.y);
		itemList.add(aaa);
		layerContainer.add(aaa, 0);
		repaint();
	}

}
