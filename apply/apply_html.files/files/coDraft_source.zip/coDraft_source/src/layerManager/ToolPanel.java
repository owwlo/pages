package layerManager;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.ITween;

import coDraft.CoDraft;

public class ToolPanel extends JPanel implements com.ITween
{

	private static final long serialVersionUID = 1L;
	
	private ArrayList<JLabel> toolList=new ArrayList<JLabel>();
	private LayerManager layerManager;
	private GridBagConstraints gBC = new GridBagConstraints();
	private JPanel btnPanel=new JPanel();
	private JPanel rectPanel=new JPanel();
	private JLabel rect=new JLabel(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("blackRoundRectBack.png",  com.GlobalScale.getGlobalScaleResult.getGlobalScale()/3.5, true)));
	private ButtonAction ba=new ButtonAction();
	
	public ToolPanel(LayerManager _layerManager)
	{
		super();
		layerManager=_layerManager;
		this.setOpaque(false);
		//this.setLayout(new GridBagLayout());
		//gBC.fill = GridBagConstraints.NONE;
        //gBC.gridx = 0;
        //gBC.gridy = 0;
		btnPanel.setOpaque(false);
		rectPanel.setOpaque(false);
		rectPanel.setLayout(null);
		rect.setSize(30, 30);
		//rect.setLocation(0, 0);
		rectPanel.add(rect);
		this.setLayout(null);
		
		this.add(btnPanel);
		this.add(rectPanel);
	}
	public void addTool(ImageIcon newBtnIcon,int ToolIndex)
	{
		JLabel btn=new JLabel(newBtnIcon);
		btn.setName(String.valueOf(ToolIndex));
		btn.addMouseListener(ba);
		toolList.add(btn);
		//gBC.weightx=1.0/toolList.size();
		//gBC.gridx = toolList.size();
		this.setSize((int)(newBtnIcon.getIconWidth()*1.5*(toolList.size())),(int)( newBtnIcon.getIconHeight()*1.5));
		//System.out.println(newBtnIcon.getIconWidth()*1.5);
		btnPanel.setSize(this.getSize());
		rectPanel.setSize(this.getSize());
		//this.add(btn,gBC);
		btnPanel.add(btn);
	}
	public void setTool(int _i)
	{
		com.TweenOw.dealIt(rect,this, 0.5, (int)(30*_i+19), 4);
		repaint();
		layerManager.drawBoard.setTool(Integer.parseInt(toolList.get(_i).getName())-1);
	}
	private class ButtonAction extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{
			String btnName=((JLabel)e.getSource()).getName();
			int toolIndex=Integer.parseInt(btnName);
			setTool(toolIndex);
		}
	}
	@Override
	public void finishTweenChange() {
		// TODO Auto-generated method stub
		
	}
}
