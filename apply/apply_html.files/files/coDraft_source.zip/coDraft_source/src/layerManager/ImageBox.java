package layerManager;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class ImageBox extends LayerItem {

	private static final long serialVersionUID = 1L;
	
	private JLabel imgLabel;
	//private ArrayList<ImageIcon > box=new ArrayList<ImageIcon>();
	
	public ImageBox(String ownerID,ImageIcon _img,int tfWidth,int tfHeight,int _x,int _y)
	{
		super(ownerID);
		
		this.width=tfWidth;
		this.height=tfHeight;
		this.x=_x;
		this.y=_y;
		
		imgLabel=new JLabel(_img);
		
		this.setLayerSize(width, height);
		this.setOpaque(false);
		
		this.add(imgLabel);
	}
}
