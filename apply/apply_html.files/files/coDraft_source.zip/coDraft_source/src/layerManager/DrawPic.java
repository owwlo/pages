package layerManager;

import hysun.draw.PolyLine;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.util.ArrayList;

public class DrawPic extends LayerItem{

	private static final long serialVersionUID = 1L;
	
	public ArrayList<Point> pointList=new ArrayList<Point>();
	public int left=32767,right=0,up=32767,bottom=0;
	private Color myColor;
	
	public DrawPic(String ownerID,Color icolor) {
		super(ownerID);
		myColor=icolor;
	}
	public DrawPic(String ownerID,ArrayList<PolyLine> shapes,Color icolor) {
		super(ownerID);
		myColor=icolor;
		//this.setBackground(Color.BLACK);
		getWholeLeftRightUpBottom(shapes);
		this.setLayerSize(width, height);
		//System.out.println(up);
		for(int i=0;i<shapes.size();i++)
		{
			PolyLine aaa=shapes.get(i);
			int bbb[][]=aaa.getPoints();
			for(int j=0;j<bbb[0].length;j++)
			{
				addPoint(new Point(bbb[0][j]-left,bbb[1][j]-up));
			}
		}
	}
	@SuppressWarnings("unchecked")
	public DrawPic(DrawPic aaa)
	{
		super(aaa.getOwnerID());
		pointList=(ArrayList<Point>) aaa.pointList.clone();
		left=aaa.left;
		right=aaa.right;
		up=aaa.up;
		bottom=aaa.bottom;
		this.width=aaa.width;
		this.height=aaa.height;
		this.x=aaa.x;
		this.y=aaa.y;
		this.setLayerSize(aaa.width, aaa.height);
	}
	@Override
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }
	public void draw(Graphics g) 
	{
		Graphics2D g2d = (Graphics2D)g;
		int points[][]=getPoints();
		g2d.setColor(myColor);
		g2d.setStroke(new BasicStroke(2.0f));
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.drawPolyline(points[0], points[1], points[0].length);
		//this.setPosition(this.getLayerX(), this.getLayerY());
	}
	public int[][] getPoints() {
        int size = pointList.size();
        if (size == 0)
            return null;
        int[][] result = new int[2][size];
        for (int i=0; i<size; i++) {
            Point p = (Point) pointList.get(i);
            result[0][i] = p.x;
            //System.out.println(p.y);
            result[1][i] = p.y;
        }
        return result;
    }
	public void addPoint(Point aaa)
	{
		pointList.add(aaa);
	}
	public void getWholeLeftRightUpBottom(ArrayList<PolyLine> shapes)
	{
		for(int k=0;k<shapes.size();k++)
		{
			if(shapes.get(k).left<left) left=shapes.get(k).left;
			if(shapes.get(k).right>right) right=shapes.get(k).right;
			if(shapes.get(k).up<up) up=shapes.get(k).up;
			if(shapes.get(k).bottom>bottom) bottom=shapes.get(k).bottom;
		}
		up-=20;
		right+=20;
		left-=20;
		bottom+=20;
		
		this.width=right-left;
		this.height=bottom-up;
		this.x=left;
		this.y=up;
	}

}
