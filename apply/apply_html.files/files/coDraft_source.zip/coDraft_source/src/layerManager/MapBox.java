package layerManager;
/*
public class MapBox extends LayerItem {

	private static final long serialVersionUID = 1L;
	
	private double lat,lon;
	private JXMapKit mapBox;
	
	public MapBox(String ownerID,double _lat,double _lon,int _x,int _y,int _width,int _height)
	{
		super(ownerID);
		
		lat=_lat;
		lon=_lon;
		this.width=_width;
		this.height=_height;
		this.x=_x;
		this.y=_y;
		
		update();
		mapBox=new JXMapKit();
		
		initComponent();
	}
	private void initComponent()
	{
		mapBox.setSize(width, height);
		mapBox.setDefaultProvider(JXMapKit.DefaultProviders.OpenStreetMaps);
		mapBox.setAddressLocation(new GeoPosition(lat,lon));
		
		this.repaint();
		
		this.add(mapBox);
	}
}
*/
