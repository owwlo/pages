package layerManager;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TextBox extends LayerItem {

	private static final long serialVersionUID = 1L;
	
	private String textString;
	private int textSize;
	private Color textColor;
	private JTextArea ta=new JTextArea();
	
	public TextBox(String ownerID,String tS,int tSize,Color tC,int tfWidth,int tfHeight,int _x,int _y)
	{
		super(ownerID);
		
		textString=tS;
		textSize=tSize;
		textColor=tC;
		this.width=tfWidth;
		this.height=tfHeight;
		this.x=_x;
		this.y=_y;
		
		this.setLayerSize(width, height);
		this.setOpaque(false);
		
		initComponent();
	}
	@Override
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //g.setColor(new Color(0,0,0));
        //g.drawRect(0, 0, this.getPreferredSize().width, this.getPreferredSize().height);
        ta.setSize(ta.getPreferredSize());
        this.width=(int)(ta.getWidth()*1.1);
        this.height=(int)(ta.getHeight()*1.1);
        this.setLayerSize(this.width,this.height);
        //draw(g);
    }
	public void draw(Graphics g) 
	{
		Graphics2D g2d = (Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
	}
	private void initComponent()
	{
		ta.setSize(width, height);
		ta.setFont(new Font("΢���ź�", 1, textSize));
		ta.setOpaque(false);
		ta.setText(textString);
		ta.setForeground(textColor);
		ta.setEditable(true);
		ta.setAlignmentX(0.5f);
		
		this.add(ta);
	}
	
}
