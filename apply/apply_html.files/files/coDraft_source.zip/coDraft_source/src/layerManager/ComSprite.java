package layerManager;

import java.awt.Graphics;
import java.awt.event.MouseEvent;

public interface ComSprite
{
	public static final int RIGHT_PRESSED = 0;
	public static final int LEFT_RELEASED = 1;
	public static final int CURSOR_DRAGGED = 2;
	
	public void processCursorEvent(MouseEvent evt, int type);
	
	public void draw(Graphics g);
}
