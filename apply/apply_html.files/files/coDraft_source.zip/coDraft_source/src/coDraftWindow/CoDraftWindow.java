package coDraftWindow;

import javax.swing.*;
import java.awt.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import coDraft.*;

public class CoDraftWindow extends JFrame{
	
	private static final long serialVersionUID = 269428269;
	public CoDraftWindow(Dimension screenSolution)
	{
		super("coDraft_Demo");
		//this.(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.setSize(900, 600);
		//this.setUndecorated(true);
        //com.sun.awt.AWTUtilities.setWindowOpaque(this,false);
		new CoDraft(this,new Dimension(1280,800)/*screenSolution*/);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public static void main(String[] args)
	{
		new CoDraftWindow(Toolkit.getDefaultToolkit().getScreenSize());
	}

}
