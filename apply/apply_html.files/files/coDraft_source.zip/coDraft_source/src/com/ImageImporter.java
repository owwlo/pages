package com;

import java.awt.Image;  
import java.awt.image.BufferedImage;  
import java.io.File;  
import java.io.IOException;  
import javax.imageio.ImageIO;  

public class ImageImporter 
{
	public static class GetAndReturn
	{
		
		public static BufferedImage FromFile(String fileSrc,double scaleRatio,boolean smooth)
		{
			File src=new File(fileSrc);
			BufferedImage tmpImg=null;
			try {
				//Image img=ImageIO.read(src);
				
				Image img;
				java.net.URL imgURL = ImageImporter.class.getResource("/image/"+fileSrc);
				
				img=ImageIO.read(imgURL);
				
				tmpImg=new BufferedImage((int)(img.getWidth(null)*scaleRatio),(int)(img.getHeight(null)*scaleRatio),BufferedImage.TYPE_INT_ARGB);
				tmpImg.getGraphics().drawImage(  
	                    img.getScaledInstance((int)(img.getWidth(null)*scaleRatio),(int) (img.getHeight(null)*scaleRatio),  
	                            smooth?Image.SCALE_SMOOTH:Image.SCALE_FAST), 0, 0, null);  
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return tmpImg;
		}
		public static BufferedImage FromFile(String fileSrc,double scaleRatio)
		{
			return FromFile(fileSrc,scaleRatio,false);
		}
	}
}
