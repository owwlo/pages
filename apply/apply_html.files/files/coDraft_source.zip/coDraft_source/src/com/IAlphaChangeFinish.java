package com;

public interface IAlphaChangeFinish
{
	public void finishAlphaChange();
}
