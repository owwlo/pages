package com;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.GridLayout;
import javax.swing.JRadioButton;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.ComponentOrientation;

public class AppServerOrClientSE extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JRadioButton rbOffline = null;
	private JRadioButton rbServer = null;
	private JRadioButton rbClient = null;
	private JPanel jPanel = null;
	private JLabel jLabel = null;
	private JTextField tfIP = null;
	private JPanel jPanel1 = null;
	private JButton btnOK = null;
	private String strInfo;
	private ButtonGroup radioButtonGroup=new ButtonGroup();
	private JPanel jPanel2 = null;
	private JLabel jLabel1 = null;
	private JTextField jTextField = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel3 = null;
	
	public boolean isYes=false;
	
	public AppServerOrClientSE(Frame owner,String title,String _username,infoManager.ConnectionStatePanel.CONNECT_MODE _connectmode,String _ipaddress) {
		super(owner,title,true);
		initialize();
		
		btnOK.addActionListener(new ActionListener(){  
            public void actionPerformed(ActionEvent e){  
                strInfo=getType();  
                dispose();  
                }  
            });

		radioButtonGroup.add(rbClient);
		radioButtonGroup.add(rbOffline);
		radioButtonGroup.add(rbServer);
		setDefaultValue( _username, _connectmode, _ipaddress);

		this.setVisible(true);
	}

	private void initialize() {
		this.setSize(276, 264);
		this.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		this.setResizable(false);
		this.setModal(true);
		this.setContentPane(getJContentPane());
		this.setLocationRelativeTo(null);
	}

	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("coDraft_Mode");
			jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel2 = new JLabel();
			jLabel2.setText(" UserInfo");
			jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(8);
			gridLayout.setHgap(5);
			gridLayout.setVgap(5);
			gridLayout.setColumns(5);
			jContentPane = new JPanel();
			jContentPane.setLayout(gridLayout);
			jContentPane.add(jLabel2, null);
			jContentPane.add(getJPanel2(), null);
			jContentPane.add(jLabel3, null);
			jContentPane.add(getRbOffline(), getRbOffline().getName());
			jContentPane.add(getRbServer(), getRbServer().getName());
			jContentPane.add(getRbClient(), null);
			jContentPane.add(getJPanel(), null);
			jContentPane.add(getJPanel1(), null);
		}
		return jContentPane;
	}

	private JRadioButton getRbOffline() {
		if (rbOffline == null) {
			rbOffline = new JRadioButton();
			rbOffline.setName("jRadioButton");
			rbOffline.setText("Offline");
			rbOffline.setSelected(true);
		}
		return rbOffline;
	}

	private JRadioButton getRbServer() {
		if (rbServer == null) {
			rbServer = new JRadioButton();
			rbServer.setName("jRadioButton1");
			rbServer.setText("Server");
		}
		return rbServer;
	}

	private JRadioButton getRbClient() {
		if (rbClient == null) {
			rbClient = new JRadioButton();
			rbClient.setText("Client");
		}
		return rbClient;
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = GridBagConstraints.NONE;
			gridBagConstraints1.gridx = 1;
			gridBagConstraints1.gridy = 0;
			gridBagConstraints1.ipadx = 150;
			gridBagConstraints1.ipady = 18;
			gridBagConstraints1.weightx = 1.0;
			gridBagConstraints1.insets = new Insets(0, 0, 0, 0);
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.anchor = GridBagConstraints.EAST;
			gridBagConstraints.gridwidth = 1;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.ipadx = 60;
			gridBagConstraints.ipady = 12;
			gridBagConstraints.fill = GridBagConstraints.NONE;
			jLabel = new JLabel();
			jLabel.setName("");
			jLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			jLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel.setText("IP :");
			jLabel.setPreferredSize(new Dimension(1, 1));
			jPanel = new JPanel();
			jPanel.setLayout(new GridBagLayout());
			jPanel.add(jLabel, gridBagConstraints);
			jPanel.add(getTfIP(), gridBagConstraints1);
		}
		return jPanel;
	}

	private JTextField getTfIP() {
		if (tfIP == null) {
			tfIP = new JTextField();
			tfIP.setPreferredSize(new Dimension(1, 1));
		}
		return tfIP;
	}


	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.fill = GridBagConstraints.BOTH;
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.gridy = 0;
			gridBagConstraints2.ipadx = 60;
			gridBagConstraints2.ipady = 20;
			gridBagConstraints2.insets = new Insets(0, 0, 0, 0);
			jPanel1 = new JPanel();
			jPanel1.setLayout(new GridBagLayout());
			jPanel1.add(getBtnOK(), gridBagConstraints2);
		}
		return jPanel1;
	}

	private JButton getBtnOK() {
		if (btnOK == null) {
			btnOK = new JButton("OK");
			btnOK.setPreferredSize(new Dimension(1, 1));
			btnOK.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					isYes=true;
				}
			});
		}
		return btnOK;
	}
	private String getType()
	{
		if(rbOffline.isSelected())
			return "offline";
		if(rbServer.isSelected())
			return "server";
		if(rbClient.isSelected())
			return tfIP.getText();
		return null;
	}
	public String getInfo()
	{  
        return strInfo;  
    }

	/**
	 * This method initializes jPanel2	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.fill = GridBagConstraints.BOTH;
			gridBagConstraints4.gridx = 1;
			gridBagConstraints4.gridy = 0;
			gridBagConstraints4.weightx = 1.0;
			gridBagConstraints4.insets = new Insets(2, 2, 2, 2);
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.insets = new Insets(0, 0, 0, 0);
			gridBagConstraints3.gridy = 0;
			gridBagConstraints3.fill = GridBagConstraints.BOTH;
			gridBagConstraints3.weightx = 0.3D;
			gridBagConstraints3.anchor = GridBagConstraints.EAST;
			gridBagConstraints3.gridx = 0;
			jLabel1 = new JLabel();
			jLabel1.setText("UserName :");
			jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			jPanel2 = new JPanel();
			jPanel2.setLayout(new GridBagLayout());
			jPanel2.add(jLabel1, gridBagConstraints3);
			jPanel2.add(getJTextField(), gridBagConstraints4);
		}
		return jPanel2;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setColumns(1);
		}
		return jTextField;
	}
	public void setDefaultValue(String _username,infoManager.ConnectionStatePanel.CONNECT_MODE _connectmode,String _ipaddress)
	{
		jTextField.setText(_username);
		if(_connectmode==infoManager.ConnectionStatePanel.CONNECT_MODE.OFFLINE)
		{
			rbOffline.setSelected(true);
		}
		else if(_connectmode==infoManager.ConnectionStatePanel.CONNECT_MODE.SERVER)
		{
			rbServer.setSelected(true);
		}
		else
		{
			rbClient.setSelected(true);
			tfIP.setText(_ipaddress);
		}
		
	}
	public String getUserName()
	{
		return jTextField.getText();
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
