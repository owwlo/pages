package com;

import javax.swing.JComponent;

import dialogManager.DialogManager;

public class ComponentAlphaChanger 
{
	public static void dealIt(IAlphaChange src,IAlphaChangeFinish fsrc,double time,int startValue,int endValue)
	{
		(new to(src,fsrc,time,startValue,endValue)).start();
	}
	
	static class to extends Thread
	{
		long startTime;
		long endTime;
		long dur;
		
		int startValue;
		int endValue;
		
		IAlphaChange isrc;
		IAlphaChangeFinish ifsrc;
		
		public to(IAlphaChange src,IAlphaChangeFinish fsrc,double time,int _startValue,int _endValue)
		{
			startTime =System.currentTimeMillis();
			endTime=startTime+(int)(time*1000);
			dur=(int)(time*1000);
			
			startValue=_startValue;
			endValue=_endValue;
			
			isrc=src;
			ifsrc=fsrc;
			
			isrc.changeAlpha(startValue);
		}
		public void run()
		{
			long newTime=System.currentTimeMillis();
			
			while(newTime<endTime)
			{
				isrc.changeAlpha(startValue+(int)((newTime-startTime)/(double)dur*(endValue-startValue)));
				
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//System.out.println(((DialogManager)isrc).a);
				newTime=System.currentTimeMillis();
			}
			ifsrc.finishAlphaChange();
		}
	}

}
