package com;

import javax.swing.JComponent;

public class TweenOw 
{
	public static void dealIt(JComponent src,ITween src_i,double time,int aimX,int aimY)
	{
		(new to(src,src_i,time,aimX,aimY)).start();
	}
	
	static class to extends Thread
	{
		long startTime;
		long endTime;
		long dur;
		
		int startX;
		int startY;
		
		double scaleX;
		double scaleY;
		
		JComponent isrc;
		ITween isrc_i;
		
		public to(JComponent src,ITween src_i,double time,int aimX,int aimY)
		{
			startTime =System.currentTimeMillis();
			endTime=startTime+(int)(time*1000);
			dur=(int)(time*1000);
			
			startX=src.getX();
			startY=src.getY();
			
			scaleX=(aimX-startX)/1;
			scaleY=(aimY-startY)/1;
			
			isrc=src;
			try {
				isrc_i=src_i;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		public void run()
		{
			long newTime=System.currentTimeMillis();
			
			while(newTime<endTime)
			{
				int newX,newY;
				newX=startX+getDertaPow(newTime-startTime,dur,scaleX);
				newY=startY+getDertaPow(newTime-startTime,dur,scaleY);
				
				isrc.setLocation(newX, newY);
				
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				newTime=System.currentTimeMillis();
			}
			try {
				isrc_i.finishTweenChange();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		private static int getDertaSin(double t,long duation,double scale)
		{
			double derta=(Math.sin(t/duation*Math.PI-Math.PI/2)+1)/2*scale;
			return (int)derta;
		}
		private static int getDertaPow(double t,long duation,double scale)
		{
			double derta=(Math.sin(t/duation*Math.PI-Math.PI/2)+1)/2*scale;
			if(t/duation<0.5)
			{
				derta=Math.pow((t/duation*2),3.0)/2*scale;
			}
			else
			{
				derta=(Math.pow((t/duation*2-2),3.0)+2)/2*scale;
			}
			return (int)derta;
		}
	}

}
