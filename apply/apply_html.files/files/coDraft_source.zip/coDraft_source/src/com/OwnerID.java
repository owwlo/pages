package com;

import java.awt.Color;

public class OwnerID {
	
	private static String ID="r";
	private static String userName;
	private static Color userColor;
	
	public static Color getUserColor() {
		return userColor;
	}
	public static void setUserColor(Color userColor) {
		OwnerID.userColor = userColor;
	}
	public OwnerID()
	{
		
	}
	public static void setOwnerIDFromUserName(String _username)
	{
		java.util.Random r=new java.util.Random();
		ID=_username+r.nextInt();
	}
	public static void setOwnerID(String id)
	{
		ID=id;
	}
	public static String getOwnerID()
	{
		return ID;
	}
	public static String getUserName()
	{
		return userName;
	}
	public static void setUserName(String a)
	{
		userName=a;
	}
	public static Color getRandomColor()
	{
		return new Color((int)(Math.random()*220),(int)(Math.random()*220),(int)(Math.random()*220));
	}
}
