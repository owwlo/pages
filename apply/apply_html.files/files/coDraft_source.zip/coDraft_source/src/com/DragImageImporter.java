package com;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class DragImageImporter 
{
	public static ImageIcon fromFile(String _path,int _MaxWidth,int _MaxHeight)
	{
		return fromFile( _path, _MaxWidth, _MaxHeight,true);
	}
	public static ImageIcon fromFile(String _path,int _MaxWidth,int _MaxHeight,boolean isAutoEnlarge)
	{
		File path=new File(_path);
		BufferedImage tmp=null;
		try
		{
			Image img=ImageIO.read(path);
			double needRatio=_MaxWidth/_MaxHeight;
			double ratio;
			if(img.getWidth(null)/img.getHeight(null)>needRatio)
			{
				ratio=(double)_MaxWidth/(double)img.getWidth(null);
			}
			else
			{
				ratio=(double)_MaxHeight/(double)img.getHeight(null);
				//System.out.println(img.getHeight(null));
			}
			if(!isAutoEnlarge && ratio>1)
			{
				tmp=new BufferedImage((int)(img.getWidth(null)),(int)(img.getHeight(null)),BufferedImage.TYPE_INT_ARGB);
			}
			else
			{
				tmp=new BufferedImage((int)(img.getWidth(null)*ratio),(int)(img.getHeight(null)*ratio),BufferedImage.TYPE_INT_ARGB);
			}
			tmp.getGraphics().drawImage(img.getScaledInstance(tmp.getWidth(),tmp.getHeight(),Image.SCALE_SMOOTH), 0, 0, null); 
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (new ImageIcon(tmp));
	}
}
