package com;

public interface ITween
{
	public void finishTweenChange();
}
