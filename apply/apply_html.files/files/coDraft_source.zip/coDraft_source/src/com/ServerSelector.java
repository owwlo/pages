package com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.UnknownHostException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import coDraft.CoDraft;

import connectionManager.ServerIdentifier;
import connectionManager.ConnectionManagerSE.ClientManager;

import dialogManager.DialogManager;

public class ServerSelector extends JPanel implements ITween{

	String[] headers = {"Server_Address", "ping"};
	Object[][] cellData = {{"192.168.1.101", "72"},{"192.168.1.102", "90"}};
	private DefaultTableModel model = new DefaultTableModel(null, headers) {
		  public boolean isCellEditable(int row, int column) {
		    return false;
		  }
		};
	private JTable serverTable=new JTable(model);
	private JScrollPane jsp=new JScrollPane(serverTable,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	private CoDraft coDraft;
	private ServerIdentifier aaa;
	private DialogManager dlgMgr;
	private JTextField manualIP=new JTextField();
	private RichJLabel manualIPTitle=new RichJLabel("Input Server IP : ",0);
	private JPanel manualInputPanel=new JPanel();
	
	public ServerSelector(CoDraft _codraft,DialogManager _dlgMgr)
	{
		dlgMgr=_dlgMgr;
		coDraft=_codraft;
		this.setSize(600,400);
		this.setOpaque(false);
		jsp.setOpaque(false);
		
		serverTable.setFont(new Font("Segoe UI",0,20));
		serverTable.setRowHeight(28);
		serverTable.setOpaque(false);
		//serverTable.setBackground(Color.GRAY);
		
		TableColumn firsetColumn = serverTable.getColumnModel().getColumn(1);
		firsetColumn.setMaxWidth(150);
		
		DefaultTableCellRenderer   r   =   new   DefaultTableCellRenderer();   
		r.setHorizontalAlignment(JLabel.CENTER);
		serverTable.setDefaultRenderer(Object.class,r);
		serverTable.addMouseListener(new TableMouseEvent());
		
		this.setLayout(new BorderLayout());
		
		manualIPTitle.setOpaque(false);
		manualInputPanel.setOpaque(false);
		
		GridBagLayout gb=new GridBagLayout();
		manualInputPanel.setLayout(gb);
		GridBagConstraints gBC = new GridBagConstraints();
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.EAST;
		gBC.weightx=0.4;
		//gBC.ipadx=50;
        gBC.gridx = 0;
        gBC.gridy = 0;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        manualIPTitle.setShadow(0, -1, new Color(0,0,0,200));
        manualIPTitle.setFont(new Font("Segoe UI",1,20));
        manualIPTitle.setForeground(new Color(220,220,220));
        manualInputPanel.add(manualIPTitle,gBC);
        
        gBC.fill = GridBagConstraints.BOTH;
		gBC.anchor=GridBagConstraints.WEST;
		gBC.weightx=0.5;
		gBC.insets=new Insets(10,0,0,100);
		gBC.ipadx=80;
        gBC.gridy = 0;
        gBC.gridx = 1;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        manualIP.setFont(new Font("΢���ź�",1,16));
        manualIP.setForeground(new Color(200,200,200,255));
        manualIP.setBackground(new Color(100,100,100,255));
        manualIP.setBorder(BorderFactory.createLineBorder(new Color(255,255,255,100),1));
        manualIP.setHorizontalAlignment(JTextField.CENTER);
        manualIP.addKeyListener(new PressEnterOnTextField());
        manualInputPanel.add(manualIP,gBC);
		
		this.add(jsp,BorderLayout.CENTER);
		this.add(manualInputPanel,BorderLayout.SOUTH);
	}
	public void startTry()
	{
		try {
			aaa=new ServerIdentifier(this);
			aaa.startIdentify();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void addServer(String _ip)
	{
		//Object[] cellData = {_ip, "null"};
		//System.out.println(_ip);
		model.addRow(new Object[]{_ip, "null"});
	}
	@Override
	public void finishTweenChange() {
		// TODO Auto-generated method stub
		
	}
	class TableMouseEvent extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e) 
		{
		    int clickTimes = e.getClickCount();
		    if (clickTimes == 2)
		    {
		    	//System.out.println(serverTable.getSelectedRow());
		    	String serverIP=serverTable.getModel().getValueAt(serverTable.getSelectedRow(), 0).toString();
		    	//System.out.println(serverIP);
		    	aaa.stopIdentify();
		    	coDraft._clientManager=new ClientManager(coDraft,coDraft._infoManager._connectionStatePanel);
		    	coDraft._clientManager.setServerIpAddress(serverIP);
		    	coDraft._clientManager.start();
		    	coDraft._infoManager._connectionStatePanel.setState(serverIP);
		    	dlgMgr.finishServerSelect();
		    	com.ComponentAlphaChanger.dealIt(dlgMgr,new EndAlphaChangeFinish(),0.8, 200, 0);
		    }
		}
	}
	class EndAlphaChangeFinish implements IAlphaChangeFinish
	{

		@Override
		public void finishAlphaChange() {
			// TODO Auto-generated method stub
			
		}
		
	}
	class PressEnterOnTextField extends KeyAdapter
	{

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			if(e.getKeyCode() == KeyEvent.VK_ENTER)
			{
				String serverIP=manualIP.getText();
		    	aaa.stopIdentify();
		    	coDraft._clientManager=new ClientManager(coDraft,coDraft._infoManager._connectionStatePanel);
		    	coDraft._clientManager.setServerIpAddress(serverIP);
		    	coDraft._clientManager.start();
		    	coDraft._infoManager._connectionStatePanel.setState(serverIP);
		    	dlgMgr.finishServerSelect();
		    	com.ComponentAlphaChanger.dealIt(dlgMgr,new EndAlphaChangeFinish(),0.8, 200, 0);
			}
		}
		
	}
}
