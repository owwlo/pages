package com;

public class GlobalScale {
	
	private static double globalScale=0;
	
	public static class getGlobalScaleResult{
		public static int getIntResult(int in)
		{
			return (int)(in*globalScale);
		}
		public static double getGlobalScale()
		{
			return globalScale;
		}
	}
	public static void setGlobalScale(double in)
	{
		globalScale=in;
	}

}
