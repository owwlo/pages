package com;

public interface IAlphaChange
{
	public void changeAlpha(int a);
	
}
