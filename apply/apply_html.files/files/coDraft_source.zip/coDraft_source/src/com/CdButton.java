package com;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class CdButton extends JButton implements ITween{

	private static final long serialVersionUID = 269428269L;
	private ImageIcon _bg=new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("btnBG.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/2.4,true));
	
	public CdButton(ImageIcon btnImg)
	{
		super(btnImg);
		int WH=(int)(Math.max(this.getPreferredSize().width,this.getPreferredSize().height));
		this.setSize(WH,WH);
		//bg=getBG();
		this.setOpaque(false);
		this.setContentAreaFilled(false);
		this.setBorderPainted(false);
		this.setFocusPainted(false);
	}
	protected void paintComponent(Graphics g)
	{
		BufferedImage buf = new BufferedImage(getWidth(), getHeight(),BufferedImage.TYPE_INT_ARGB);  
		super.paintComponent(buf.getGraphics());
		if(this.getModel().isArmed())
		{
			g.drawImage(buf, 1, 1, null);
		}
		else if(this.getModel().isRollover())
		{
			g.drawImage(_bg.getImage(), (int)((this.getWidth()/2-_bg.getIconWidth()/2)*0.9), (int)((this.getHeight()/2-_bg.getIconHeight()/2)*0.9),null);
			g.drawImage(buf, -1, -1, null);
		}
		else
		{
			g.drawImage(buf, 0, 0, null);
		}
	}
	@Override
	public void finishTweenChange() {
		// TODO Auto-generated method stub
		
	}
}
