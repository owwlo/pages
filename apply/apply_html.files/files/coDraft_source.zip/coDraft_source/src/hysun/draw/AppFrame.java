/*
 * AppFrame.java
 *
 * Created on April 29, 2005, 7:19 PM
 */

package hysun.draw;

/**
 *
 * @author  hysun
 */
public class AppFrame extends javax.swing.JFrame {
    
    public AppFrame() {
        initComponents();
    }

    private void initComponents() {//GEN-BEGIN:initComponents
        java.awt.GridBagConstraints gridBagConstraints;

        toolsGroup = new javax.swing.ButtonGroup();
        ctrlPanel = new javax.swing.JPanel();
        mediumPanel1 = new javax.swing.JPanel();
        toolsPanel = new javax.swing.JPanel();
        mediumPanel2 = new javax.swing.JPanel();
        pencilButton = new javax.swing.JToggleButton();
        colorPanel = new javax.swing.JPanel();
        fgButton = new javax.swing.JButton();
        sizePanel = new javax.swing.JPanel();
        mediumPanel3 = new javax.swing.JPanel();
        weightCombo = new javax.swing.JComboBox();
        copyleft = new javax.swing.JLabel();
        //board = new hysun.draw.DrawingBoard();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Java Drawing Board Application");
        ctrlPanel.setLayout(new java.awt.GridBagLayout());

        mediumPanel1.setLayout(new javax.swing.BoxLayout(mediumPanel1, javax.swing.BoxLayout.Y_AXIS));

        toolsPanel.setBorder(new javax.swing.border.TitledBorder("Drawing Tools"));
        mediumPanel2.setLayout(new java.awt.GridLayout(4, 2, 5, 5));

        
        
        
        
        toolsGroup.add(pencilButton);
        pencilButton.setFont(new java.awt.Font("Dialog", 0, 10));
        pencilButton.setText("Pencil");
        pencilButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pencilButtonActionPerformed(evt);
            }
        });

        mediumPanel2.add(pencilButton);
        toolsPanel.add(mediumPanel2);
        mediumPanel1.add(toolsPanel);

        
        colorPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 10));

        colorPanel.setBorder(new javax.swing.border.TitledBorder("Color Settings"));
        fgButton.setBackground(board.getForeground());
        fgButton.setToolTipText("Change Drawing Color");
        fgButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0)));
        fgButton.setPreferredSize(new java.awt.Dimension(50, 50));
        fgButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fgButtonActionPerformed(evt);
            }
        });

        colorPanel.add(fgButton);
        mediumPanel1.add(colorPanel);

        sizePanel.setBorder(new javax.swing.border.TitledBorder("Size Setttings"));
        mediumPanel3.setLayout(new java.awt.BorderLayout(0, 3));

        weightCombo.setFont(new java.awt.Font("Dialog", 0, 10));
        weightCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Stroke Weight 1.0px", "Stroke Weight 2.0px", "Stroke Weight 5.0px", "Stroke Weight 7.5px", "Stroke Weight 10.0px" }));
        weightCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weightComboActionPerformed(evt);
            }
        });

        mediumPanel3.add(weightCombo, java.awt.BorderLayout.NORTH);
        sizePanel.add(mediumPanel3);
        mediumPanel1.add(sizePanel);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(10, 5, 5, 5);
        ctrlPanel.add(mediumPanel1, gridBagConstraints);

        copyleft.setFont(new java.awt.Font("Verdana", 0, 10));
        copyleft.setForeground(new java.awt.Color(255, 153, 0));
        copyleft.setText("CopyLeft 2005 hysun");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.SOUTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 15, 5);
        ctrlPanel.add(copyleft, gridBagConstraints);

        //getContentPane().add(ctrlPanel, java.awt.BorderLayout.WEST);
        
        board.setBorder(new javax.swing.border.EtchedBorder());
        getContentPane().add(board, java.awt.BorderLayout.CENTER);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-786)/2, (screenSize.height-578)/2, 786, 578);
    }//GEN-END:initComponents

    private void fgButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fgButtonActionPerformed
        java.awt.Color color = javax.swing.JColorChooser.showDialog(this, 
                "Change Drawing Color", board.getForeground());
        if (color != null) {
            board.setForeground(color);
            fgButton.setBackground(color);
        }
    }//GEN-LAST:event_fgButtonActionPerformed

    private void weightComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weightComboActionPerformed
        board.setStrokeIndex(weightCombo.getSelectedIndex());
    }//GEN-LAST:event_weightComboActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        board.clearBoard();
    }//GEN-LAST:event_clearButtonActionPerformed


    private void pencilButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pencilButtonActionPerformed
        board.setTool(DrawingBoard.DrawPic);
    }//GEN-LAST:event_pencilButtonActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.util.Locale.setDefault(java.util.Locale.US);
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppFrame().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private hysun.draw.DrawingBoard board;
    private javax.swing.JPanel colorPanel;
    private javax.swing.JLabel copyleft;
    private javax.swing.JPanel ctrlPanel;
    private javax.swing.JButton fgButton;
    private javax.swing.JPanel mediumPanel1;
    private javax.swing.JPanel mediumPanel2;
    private javax.swing.JPanel mediumPanel3;
    private javax.swing.JToggleButton pencilButton;
    private javax.swing.JPanel sizePanel;
    private javax.swing.ButtonGroup toolsGroup;
    private javax.swing.JPanel toolsPanel;
    private javax.swing.JComboBox weightCombo;
    // End of variables declaration//GEN-END:variables
    
}
