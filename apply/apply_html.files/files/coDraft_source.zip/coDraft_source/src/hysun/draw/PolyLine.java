/*
 * PolyLine.java
 *
 * Created on April 29, 2005, 6:38 PM
 */

package hysun.draw;

import java.awt.*;

/**
 *
 * @author hysun
 */
public class PolyLine extends FreeShape {
    
    public PolyLine(Color c, Stroke s, int x, int y) {
        super(c, s, x, y);
    }
    
    public void draw(Graphics2D g) {
        g.setColor(color);
        g.setStroke(stroke);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int[][] points = pointsSet.getPoints();
        int s = points[0].length;
        if (s == 1) {
            int x = points[0][0];
            int y = points[1][0];
            g.drawLine(x, y, x, y);
        } else {
            g.drawPolyline(points[0], points[1], s);
        }
    }
    public int[][] getPoints()
    {
    	return pointsSet.getPoints();
    }
    
}
