/*
 * DrawingBoard.java
 *
 * Created on April 29, 2005, 7:13 PM
 */

package hysun.draw;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import connectionManager.TransObj;
import java.util.ArrayList;
import layerManager.DrawPic;
import layerManager.LayerItem;
import layerManager.LayerManager;
import layerManager.TextBox;

public class DrawingBoard extends JPanel implements 
                                MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	
	public static final int DrawPic = 0;
    public static final int TextBox = 1;
    public static final int ImageBox = 2;
    public static final int FileBox = 3;
    public static final int CdCommand = 4;
    public static final int MapBox = 5;
    
    public static final Stroke[] STROKES = new Stroke[] {
        new BasicStroke(1.0f),
        new BasicStroke(2.0f),
        new BasicStroke(5.0f),
        new BasicStroke(7.5f),
        new BasicStroke(10.0f)
    };
    
    public static final Stroke[] ERASER_STROKES = new Stroke[] {
        new BasicStroke(15.0f),
        new BasicStroke(20.0f),
        new BasicStroke(30.0f),
        new BasicStroke(50.0f),
        new BasicStroke(100.0f)
    };
    
    private ArrayList<PolyLine> shapes;
    
    private PolyLine currentShape;
    private TextBox tBox;
    //private MapBox mBox;
    
    private int tool;
    
    private int strokeIndex, eraserIndex;
    
    private LayerManager layerManager;
    
    private Boolean isDrawed=false;
    
    public DrawingBoard(LayerManager father) {
    	layerManager=father;
    	
        shapes = new ArrayList();
        tool = this.DrawPic;
        currentShape = null;
        strokeIndex = 0;
        eraserIndex = 0;
        
        setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        setOpaque(false);
        this.setLayout(null);
        setForeground(Color.black);
        //setBackground(Color.green);
        
        addMouseListener(this);
        addMouseMotionListener(this);
    }
    
    public void setTool(int t) {
        tool = t;
    }
    
    public void setStrokeIndex(int i) {
        if (i < 0 || i > 4)
            throw new IllegalArgumentException("Invaild Weight Specified!");
        strokeIndex = i;
    }
    
    public void setEraserIndex(int i) {
        if (i < 0 || i > 4)
            throw new IllegalArgumentException("Invaild Size Specified!");
        eraserIndex = i;
    }
    
    public void clearBoard() {
        shapes.clear();
        repaint();
    }
    
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int size = shapes.size();
        Graphics2D g2d = (Graphics2D) g;
        for (int i=0; i<size; i++) {
        	if(shapes.get(i)!=null)
        		((IShape) shapes.get(i)).draw(g2d);
        }
    }
    
    public void mousePressed(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            switch (tool) {
                case DrawPic:
                    currentShape = new PolyLine(com.OwnerID.getUserColor(), 
                                STROKES[1], e.getX(), e.getY());
                    shapes.add(currentShape);
                    break;
                case TextBox:
                	if(isDrawed) break;
                	tBox=new TextBox("userIDTB", "TextBox", 20,com.OwnerID.getUserColor(), 300, 50,e.getX(), e.getY());
                	tBox.setLocation(e.getX(), e.getY());
                	this.add(tBox);
                	isDrawed=true;
                    break;
                //case MapBox:
                	//mBox=new MapBox("owwlo",0,0,0, 0,600,400);
                	//mBox.setLocation(e.getX(), e.getY());
                	//this.add(mBox);
                	//isDrawed=true;
                    //break;
            }
            repaint();
        } else if (e.getButton() == MouseEvent.BUTTON3 && currentShape != null) {
            currentShape.processCursorEvent(e, IShape.RIGHT_PRESSED);
            repaint();
        }
        else if(e.getButton() == MouseEvent.BUTTON3 )
        {
        	if(currentShape == null && shapes.size()>0)
        	{
	        	//layerManager.addLayer(new LayerItem(com.OwnerID.getOwnerID(),shapes));
	        	DrawPic tmpItem=new DrawPic(com.OwnerID.getOwnerID(),shapes,com.OwnerID.getUserColor());
	        	SendToOthers(TransObj.DrawPic,"",tmpItem);
	    		layerManager.addLayer(tmpItem);
	        	shapes.clear();
	        	repaint();
        	}
        	if(tool==TextBox && isDrawed)
        	{
        		SendToOthers(TransObj.TextBox,"",tBox);
        		layerManager.addLayer(tBox);
        		this.remove(tBox);
        	}
        	//if(tool==MapBox && isDrawed)
        	//{
        	//	SendToOthers(TransObj.MapBox,"",mBox);
        	//	layerManager.addLayer(mBox);
        	//	this.remove(mBox);
        	//}
        	isDrawed=false;
        }
    }
    
    public void mouseDragged(MouseEvent e) {
        if (currentShape != null) {
            currentShape.processCursorEvent(e, IShape.CURSOR_DRAGGED);
            repaint();
        }
    }
    
    public void mouseReleased(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1 && currentShape != null) {
            currentShape.processCursorEvent(e, IShape.LEFT_RELEASED);
            currentShape = null;
            repaint();
        }
        if(currentShape == null && shapes.size()>0)
    	{
        	//layerManager.addLayer(new LayerItem(com.OwnerID.getOwnerID(),shapes));
        	DrawPic tmpItem=new DrawPic(com.OwnerID.getOwnerID(),shapes,com.OwnerID.getUserColor());
        	SendToOthers(TransObj.DrawPic,"",tmpItem);
    		layerManager.addLayer(tmpItem);
        	shapes.clear();
        	repaint();
    	}
    	//if(tool==TextBox && isDrawed)
    	//{
    	//	SendToOthers(TransObj.TextBox,"",tBox);
    	//	layerManager.addLayer(tBox);
    	//	this.remove(tBox);
    	//}
    	//if(tool==MapBox && isDrawed)
    	//{
    	//	SendToOthers(TransObj.MapBox,"",mBox);
    	//	layerManager.addLayer(mBox);
    	//	this.remove(mBox);
    	//}
    	//isDrawed=false;
        
    }
    
    public void SendToOthers(int type,String command,LayerItem li)
    {
    	if(layerManager._fatherCoDraft._serverManager!=null)
    		layerManager._fatherCoDraft._serverManager.sendData(new TransObj(com.OwnerID.getOwnerID(),type,command,li));
		if(layerManager._fatherCoDraft._clientManager!=null)
			layerManager._fatherCoDraft._clientManager.sendData(new TransObj(com.OwnerID.getOwnerID(),type,command,li));
    }
    
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseMoved(MouseEvent e) {}
    
    public int getTool()
    {
    	return tool;
    }
}
