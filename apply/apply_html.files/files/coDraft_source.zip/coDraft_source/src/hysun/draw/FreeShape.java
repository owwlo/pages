/*
 * FreeShape.java
 *
 * Created on April 29, 2005, 5:28 PM
 */

package hysun.draw;

import java.awt.*;
import java.awt.event.MouseEvent;

/**
 *
 * @author hysun
 */
public abstract class FreeShape implements IShape {
    
    protected Color color;
    
    protected Stroke stroke;
    
    protected PointsSet pointsSet;
    
    public int left=32767,right=0,bottom=0,up=32767;
    
    protected FreeShape(Color c, Stroke s, int x, int y) {
        pointsSet = new PointsSet(50);
        color = c;
        stroke = s;
        pointsSet.addPoint(x, y);
    }
    
    public void processCursorEvent(MouseEvent e, int t) {
        if (t != IShape.CURSOR_DRAGGED)
            return;
        if(e.getX()>1113 || e.getX()<0 ||e.getY()>669 ||e.getY()<0)
        	return;
        pointsSet.addPoint(e.getX(), e.getY());
        if(e.getX()>=0 && e.getX()<=1113)
        {
        	if(e.getX()<left) left=e.getX();
        	if(e.getX()>right) right=e.getX();
        }
        if(e.getY()>=0 && e.getY()<=669)
        {
        	if(e.getY()<up) up=e.getY();
        	if(e.getY()>bottom) bottom=e.getY();
        }
    }
}
