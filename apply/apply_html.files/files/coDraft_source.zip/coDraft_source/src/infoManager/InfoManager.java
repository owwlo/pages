package infoManager;

//import com.CdButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import com.CdButton;

import connectionManager.ConnectInfoTrans;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import layerManager.ToolPanel;
import coDraft.CoDraft;
import dialogManager.DialogManager;

public class InfoManager extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private CoDraft _fatherCoDraft;
	//private JLabel _connectionStateLabel=new JLabel();
	//private JLabel _connectionStateLED;
	//private JLabel _dock;
	public UserPanel _mainUser;
	//private UserPanel test2;
	public ConnectionStatePanel _connectionStatePanel=new ConnectionStatePanel();
	//private CdButton conBtn=new CdButton(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("conn.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/2.5,true)));
	public ToolPanel _toolPanel;
	public InfoDockPanel _infoDockPanel;
	private CdButton panelSwitcher=new CdButton(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("panelSwitcher.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/6,true)));
	private boolean isDockShown=true;
	private ArrayList<ConnectInfoTrans> ConnectUserInfoList=new ArrayList<ConnectInfoTrans>(); 
	
	public InfoManager(CoDraft _father)
	{
		_fatherCoDraft=_father;
		
		_toolPanel=new ToolPanel(_fatherCoDraft._layerManager);
		_infoDockPanel=new InfoDockPanel(_father);
		
		this.setOpaque(false);
		this.setLayout(null);
		
		initControlers();

		//showDock(false);
		//com.TweenOw.dealIt(test, 2, test.getX()-100, test.getY()+100);
	}
	private void initControlers()
	{
		//_connectionStateLabel.setAutoscrolls(true);
		//_connectionStateLabel.setText("No server or client to connect .");
		//_connectionStateLabel.setFont(new Font("Arial",3,(int)(15*_fatherCoDraft.iGlobalScale)));
		//_connectionStateLabel.setForeground(new Color(200,200,200));
		//_connectionStateLabel.setBounds((int)(80*_fatherCoDraft.iGlobalScale),(int)( 46*_fatherCoDraft.iGlobalScale),(int)( 250*_fatherCoDraft.iGlobalScale),(int)(20*_fatherCoDraft.iGlobalScale));
		//System.out.println(_connectionStateLabel.getHeight());
		
		//_connectionStateLED=new JLabel(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("redLED.png", _fatherCoDraft.iGlobalScale/5,true)));
		//_connectionStateLED.setBounds(GlobalScale.getGlobalScaleResult.getIntResult(40),GlobalScale.getGlobalScaleResult.getIntResult(30),GlobalScale.getGlobalScaleResult.getIntResult(50),GlobalScale.getGlobalScaleResult.getIntResult(50));
		
		_connectionStatePanel.setLocation(15,13);
		
		//_dock=new JLabel(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("dock.png", _fatherCoDraft.iGlobalScale/2,true)));
		//_dock.setBounds(GlobalScale.getGlobalScaleResult.getIntResult(912),GlobalScale.getGlobalScaleResult.getIntResult(25),GlobalScale.getGlobalScaleResult.getIntResult(220),GlobalScale.getGlobalScaleResult.getIntResult(650));
		
		_mainUser=new UserPanel("cd.User","127.0.0.1",true);
		
		_mainUser.setLocation(920, 18);
		
		//test2=new UserPanel("MAOMAO","111.111.111.111",false);
		//test2.setLocation(960, 130);
		
		_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Mouse.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),0);
		_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Paint.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),1);
		_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("text.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),2);
		_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("pic.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),3);
		_toolPanel.addTool(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("Word-Processor.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/4, true)),4);
		_toolPanel.setTool(0);
		_toolPanel.setLocation(760, 603);
		
		_infoDockPanel.setLocation(872, -7);
		
		panelSwitcher.setLocation(1027, 588);
		panelSwitcher.addMouseListener(new DockSwitcherListener());
		
		this.add(panelSwitcher);
		this.add(_mainUser);
		this.add(_infoDockPanel);
		this.add(_toolPanel);
		//this.add(test2);
		//this.add(_dock);
		this.add(_connectionStatePanel);
		//this.add(_connectionStateLED);
		//this.add(_connectionStateLabel);
		
	}
	public void showDock(boolean bool)
	{
		if(bool && !isDockShown)
		{
			com.TweenOw.dealIt(_infoDockPanel,_infoDockPanel, 1,872, -7);
			com.TweenOw.dealIt(_toolPanel,_toolPanel, 1, 760, 603);
			com.TweenOw.dealIt(panelSwitcher,panelSwitcher, 1, 1027, 588);
			isDockShown=true;
		}
		else if(!bool && isDockShown)
		{
			com.TweenOw.dealIt(_infoDockPanel,_infoDockPanel, 1, 912+200-40, 25-32);
			com.TweenOw.dealIt(_toolPanel,_toolPanel,1, 800+142-40, 635-32);
			com.TweenOw.dealIt(panelSwitcher,panelSwitcher,1, 1067-40, 595-32);
			isDockShown=false;
		}
		repaint();
	}
	public void addConnectUser(ConnectInfoTrans a)
	{
		ConnectUserInfoList.add(a);
		
		//System.out.println(a.get_IP()+" "+a.get_ownerUserName());
	}
	private class DockSwitcherListener extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{
			showDock(!isDockShown);
		}
	}
	public void processIMData(String username,String message)
	{
		_infoDockPanel.processIMData(username,message);
	}
}
