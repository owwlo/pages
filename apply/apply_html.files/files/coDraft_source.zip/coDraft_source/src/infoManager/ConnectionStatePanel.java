package infoManager;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ConnectionStatePanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private final String SERVER_MODE_CONST="Server Mode. Connected Clients: ";
	private final String OFFLINE_MODE_CONST="Offline Mode. ";
	private final String CLIENT_MODE_CONST="Connected to: ";
	private String IPAddress="";
	private int numOfClient=0;
	private ImageIcon redLED=new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("redLED.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/18,true));
	private ImageIcon greenLED=new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("greenLED.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/18,true));
	private JLabel LED=new JLabel(redLED);
	private JLabel stateText=new JLabel("sssssssssssssssssssssss");
	public static enum CONNECT_MODE {OFFLINE, SERVER,CLIENT }
	private CONNECT_MODE connectMode=CONNECT_MODE.OFFLINE;
	
	public ConnectionStatePanel()
	{
		this.setOpaque(false);
		stateText.setFont(new Font("Verdana",3,(int)(14*com.GlobalScale.getGlobalScaleResult.getGlobalScale())));
		stateText.setForeground(new Color(200,200,200));
		initUI();
	}
	private void initUI()
	{
		this.setBounds(0, 0, 300,20);

		GridBagLayout gb=new GridBagLayout();
		this.setLayout(gb);
		
		GridBagConstraints gBC = new GridBagConstraints();
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.CENTER;
		gBC.weightx=0;
		gBC.ipadx=10;
        gBC.gridx = 0;
        gBC.gridy = 0;
        gBC.gridheight=1;
        gBC.gridwidth=1;
		this.add(LED,gBC);
		
		gBC.fill = GridBagConstraints.BOTH;
		gBC.anchor=GridBagConstraints.WEST;
		gBC.weightx=1;
		//gBC.weighty=0.8;
		gBC.ipadx=0;
        gBC.gridx = 1;
        gBC.gridy = 0;
        gBC.gridheight=1;
        gBC.gridwidth=1;
		this.add(stateText,gBC);
		
		refresh();
	}
	private void refresh()
	{
		switch(connectMode)
		{
			case OFFLINE:
				stateText.setText(OFFLINE_MODE_CONST);
				LED.setIcon(redLED);
				break;
			case SERVER:
				stateText.setText(SERVER_MODE_CONST + numOfClient);
				LED.setIcon(redLED);
				break;
			case CLIENT:
				stateText.setText(CLIENT_MODE_CONST + IPAddress);
				LED.setIcon(redLED);
				break;
		}
	}
	public void setLED(String aaa)
	{
		if(aaa.equalsIgnoreCase("red"))
		{
			LED.setIcon(redLED);
		}
		else
		{
			LED.setIcon(greenLED);
		}
	}
	public int getNumOfClient()
	{
		return numOfClient;
	}
	public void setNumOfClient(int a)
	{
		numOfClient=a;
		refresh();
	}
	public void setState(String aaa)
	{
		if(aaa.equalsIgnoreCase("server"))
			connectMode=CONNECT_MODE.SERVER;
		else if(aaa.equalsIgnoreCase("offline"))
			connectMode=CONNECT_MODE.OFFLINE;
		else
		{
			connectMode=CONNECT_MODE.CLIENT;
			IPAddress=aaa;
		}
		refresh();
	}
	public CONNECT_MODE getState()
	{
		return connectMode;
	}
	public String getIP()
	{
		return IPAddress;
	}
}
