package infoManager;

import imManager.ImPanel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.ITween;

import connectionManager.ConnectInfoTrans;

import coDraft.CoDraft;

public class InfoDockPanel extends JPanel implements ITween{

	private static final long serialVersionUID = 1L;
	
	private JLabel _dock=new JLabel(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("dock.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()/2,true)));;
	private CoDraft _coDraftFather;
	//private UserPanel test2;
	private UsersPane _usersPane=new UsersPane(150,170);
	private ImPanel imPanel;
	
	public InfoDockPanel(CoDraft coDraftFather)
	{
		super();
		this.setLayout(null);
		this.setOpaque(false);
		_coDraftFather=coDraftFather;
		imPanel=new ImPanel(coDraftFather);
		_dock.setSize(220, 650);
		this.setSize(_dock.getSize());
		
		//System.out.println(this.getSize());
		
		addControls();
	}
	private void addControls()
	{
		_usersPane.setLocation(45, 90);
		this.add(_usersPane);
		
		imPanel.setLocation(45,265);
		this.add(imPanel);
		this.add(new JButton("asdasd"));
		this.add(_dock);
	}
	public void addConnectUser(ConnectInfoTrans a)
	{
		_usersPane.addUserControl(a);
	}
	@Override
	public void finishTweenChange() {
		// TODO Auto-generated method stub
		
	}
	public void processIMData(String username,String message)
	{
		imPanel.getMsg(username,message);
	}

}
