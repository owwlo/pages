package infoManager;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.RichJLabel;

public class UserPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private String _userName;
	private String _ipStress;
	private JLabel userPic;
	private RichJLabel userName;
	private RichJLabel userIP;
	
	public UserPanel(String userName,String ipStress,boolean isServer)
	{
		_userName=userName;
		_ipStress=ipStress;
		
		this.setOpaque(false);
		
		initUI(isServer);
	}
	private void initUI(boolean isServer)
	{
		this.setBounds(0, 0, isServer?150:100,(isServer?48:30));
		//this.setLayout(new BorderLayout());
		
		GridBagLayout gb=new GridBagLayout();
		this.setLayout(gb);
		
		GridBagConstraints gBC = new GridBagConstraints();
		
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.CENTER;
		//gBC.ipadx=isServer?30:30;
		gBC.weightx=0.1;
        gBC.gridx = 0;
        gBC.gridy = 0;
        gBC.gridheight=2;
        gBC.gridwidth=1;
		userPic=new JLabel(new ImageIcon(com.ImageImporter.GetAndReturn.FromFile("userPic.png", com.GlobalScale.getGlobalScaleResult.getGlobalScale()*(isServer?1:0.5),true)));
		//userPic.setAlignmentX(0);
		this.add(userPic,gBC);
		
		userName=new RichJLabel(_userName,0);
		gBC.fill = GridBagConstraints.NONE;
		gBC.anchor=GridBagConstraints.SOUTHWEST;
		//gBC.weightx=0.3;
		gBC.weighty=0.8;
        gBC.gridx = 1;
        gBC.gridy = 0;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        userName.setAlignmentX(0);
        userName.setShadow(0, -1, new Color(255,255,255,150));
		this.add(userName,gBC);
		
		userIP=new RichJLabel(_ipStress,0);
		gBC.anchor=GridBagConstraints.SOUTHWEST;
		gBC.weighty=0;
        gBC.gridx = 1;
        gBC.gridy = 1;
        gBC.gridheight=1;
        gBC.gridwidth=1;
        userIP.setAlignmentX(0);
        userIP.setShadow(0, -1, new Color(255,255,255,150));
        this.add(userIP,gBC);
		
	}
	public void setUserName(String a)
	{
		_userName=a;
		userName.setText(a);
	}
	public void setIPAddress(String a)
	{
		_ipStress=a;
		userIP.setText(a);
	}

}
