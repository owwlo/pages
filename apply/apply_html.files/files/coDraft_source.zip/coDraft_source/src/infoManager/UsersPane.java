package infoManager;

import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import connectionManager.CommandSet;
import connectionManager.ConnectInfoTrans;
import connectionManager.TransObj;

public class UsersPane extends JScrollPane
{
	private ArrayList<ConnectInfoTrans> _controlsList=new ArrayList<ConnectInfoTrans>();
	private JPanel _panel=new JPanel();
	//private JTextArea aaa=new JTextArea();
	
	public UsersPane(int width,int height) {
		super();
		//this.setBackground(new Color(150,150,150));
		BoxLayout layout =new BoxLayout(_panel, BoxLayout.Y_AXIS);
		_panel.setSize(width, height);
		_panel.setLayout(layout);
		_panel.setAlignmentX(0);
		_panel.setAlignmentY(0);
		_panel.setAutoscrolls(true);
		this.setSize(width, height);
		this.setHorizontalScrollBarPolicy(HORIZONTAL_SCROLLBAR_NEVER);
		this.setVerticalScrollBarPolicy(VERTICAL_SCROLLBAR_AS_NEEDED);
		//this.setViewportView(aaa);
		this.setViewportView(_panel);
	}
	public void addUserControl(ConnectInfoTrans a)
	{
		System.out.println("add contract "+"\""+a.get_ownerUserName()+"\"\n");
		//aaa.append(a.get_ownerUserName()+"+++"+a.get_IP());
		_panel.add(new UserPanel(a.get_ownerUserName(), a.get_IP(), false));
		_panel.repaint();
		this.repaint();
		_controlsList.add(a);
		//_panel.repaint();
	}
	public TransObj getUsersListTransObj()
	{
		TransObj aaa=new TransObj(com.OwnerID.getOwnerID(), TransObj.ConnectedUsersSet, "", null);
		return aaa;
	}
}
